/* -*- Mode: C++; tab-width: 2; indent-tabs-mode: nil; c-basic-offset: 2 -*- */
/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

#ifndef GMPServiceChild_h_
#define GMPServiceChild_h_

#include "GMPService.h"
#include "MediaResult.h"
#include "base/process.h"
#include "mozilla/dom/PContent.h"
#include "mozilla/gmp/PGMPServiceChild.h"
#include "mozilla/ipc/Transport.h"
#include "nsRefPtrHashtable.h"

namespace mozilla {
namespace gmp {

class GMPContentParent;
class GMPServiceChild;

class GeckoMediaPluginServiceChild : public GeckoMediaPluginService {
  friend class GMPServiceChild;

 public:
  static already_AddRefed GetSingleton();

  NS_IMETHOD HasPluginForAPI(const nsACString& aAPI, nsTArray* aTags,
                             bool* aRetVal) override;
  NS_IMETHOD GetNodeId(const nsAString& aOrigin,
                       const nsAString& aTopLevelOrigin,
                       const nsAString& aGMPName,
                       UniquePtr&& aCallback) override;

  NS_DECL_NSIOBSERVER

  void SetServiceChild(UniquePtr&& aServiceChild);

  void RemoveGMPContentParent(GMPContentParent* aGMPContentParent);

  static void UpdateGMPCapabilities(
      nsTArray&& aCapabilities);

  void BeginShutdown();

 protected:
  void InitializePlugins(nsISerialEventTarget*) override {
    // Nothing to do here.
  }

  RefPtr GetContentParent(
      GMPCrashHelper* aHelper, const nsACString& aNodeIdString,
      const nsCString& aAPI, const nsTArray& aTags) override;

  RefPtr GetContentParent(
      GMPCrashHelper* aHelper, const NodeId& aNodeId, const nsCString& aAPI,
      const nsTArray& aTags) override;

 private:
  friend class OpenPGMPServiceChild;

  typedef MozPromise
      GetServiceChildPromise;
  RefPtr GetServiceChild();

  nsTArray> mGetServiceChildPromises;
  UniquePtr mServiceChild;
};

class GMPServiceChild : public PGMPServiceChild {
 public:
  explicit GMPServiceChild();
  virtual ~GMPServiceChild();

  already_AddRefed GetBridgedGMPContentParent(
      ProcessId aOtherPid, ipc::Endpoint&& endpoint);

  void RemoveGMPContentParent(GMPContentParent* aGMPContentParent);

  void GetAlreadyBridgedTo(nsTArray& aAlreadyBridgedTo);

  static bool Create(Endpoint&& aGMPService);

  ipc::IPCResult RecvBeginShutdown() override;

  bool HaveContentParents() const;

 private:
  nsRefPtrHashtable mContentParents;
};

}  // namespace gmp
}  // namespace mozilla

#endif  // GMPServiceChild_h_
