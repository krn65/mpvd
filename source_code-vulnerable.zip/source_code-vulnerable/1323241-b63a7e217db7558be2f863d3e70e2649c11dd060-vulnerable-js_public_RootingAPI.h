/* -*- Mode: C++; tab-width: 8; indent-tabs-mode: nil; c-basic-offset: 4 -*-
 * vim: set ts=8 sts=4 et sw=4 tw=99:
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

#ifndef js_RootingAPI_h
#define js_RootingAPI_h

#include "mozilla/Attributes.h"
#include "mozilla/DebugOnly.h"
#include "mozilla/GuardObjects.h"
#include "mozilla/LinkedList.h"
#include "mozilla/Move.h"
#include "mozilla/TypeTraits.h"

#include 

#include "jspubtd.h"

#include "js/GCAnnotations.h"
#include "js/GCAPI.h"
#include "js/GCPolicyAPI.h"
#include "js/HeapAPI.h"
#include "js/TypeDecls.h"
#include "js/UniquePtr.h"
#include "js/Utility.h"

/*
 * Moving GC Stack Rooting
 *
 * A moving GC may change the physical location of GC allocated things, even
 * when they are rooted, updating all pointers to the thing to refer to its new
 * location. The GC must therefore know about all live pointers to a thing,
 * not just one of them, in order to behave correctly.
 *
 * The |Rooted| and |Handle| classes below are used to root stack locations
 * whose value may be held live across a call that can trigger GC. For a
 * code fragment such as:
 *
 * JSObject* obj = NewObject(cx);
 * DoSomething(cx);
 * ... = obj->lastProperty();
 *
 * If |DoSomething()| can trigger a GC, the stack location of |obj| must be
 * rooted to ensure that the GC does not move the JSObject referred to by
 * |obj| without updating |obj|'s location itself. This rooting must happen
 * regardless of whether there are other roots which ensure that the object
 * itself will not be collected.
 *
 * If |DoSomething()| cannot trigger a GC, and the same holds for all other
 * calls made between |obj|'s definitions and its last uses, then no rooting
 * is required.
 *
 * SpiderMonkey can trigger a GC at almost any time and in ways that are not
 * always clear. For example, the following innocuous-looking actions can
 * cause a GC: allocation of any new GC thing; JSObject::hasProperty;
 * JS_ReportError and friends; and ToNumber, among many others. The following
 * dangerous-looking actions cannot trigger a GC: js_malloc, cx->malloc_,
 * rt->malloc_, and friends and JS_ReportOutOfMemory.
 *
 * The following family of three classes will exactly root a stack location.
 * Incorrect usage of these classes will result in a compile error in almost
 * all cases. Therefore, it is very hard to be incorrectly rooted if you use
 * these classes exclusively. These classes are all templated on the type T of
 * the value being rooted.
 *
 * - Rooted declares a variable of type T, whose value is always rooted.
 *   Rooted may be automatically coerced to a Handle, below. Rooted
 *   should be used whenever a local variable's value may be held live across a
 *   call which can trigger a GC.
 *
 * - Handle is a const reference to a Rooted. Functions which take GC
 *   things or values as arguments and need to root those arguments should
 *   generally use handles for those arguments and avoid any explicit rooting.
 *   This has two benefits. First, when several such functions call each other
 *   then redundant rooting of multiple copies of the GC thing can be avoided.
 *   Second, if the caller does not pass a rooted value a compile error will be
 *   generated, which is quicker and easier to fix than when relying on a
 *   separate rooting analysis.
 *
 * - MutableHandle is a non-const reference to Rooted. It is used in the
 *   same way as Handle and includes a |set(const T& v)| method to allow
 *   updating the value of the referenced Rooted. A MutableHandle can be
 *   created with an implicit cast from a Rooted*.
 *
 * In some cases the small performance overhead of exact rooting (measured to
 * be a few nanoseconds on desktop) is too much. In these cases, try the
 * following:
 *
 * - Move all Rooted above inner loops: this allows you to re-use the root
 *   on each iteration of the loop.
 *
 * - Pass Handle through your hot call stack to avoid re-rooting costs at
 *   every invocation.
 *
 * The following diagram explains the list of supported, implicit type
 * conversions between classes of this family:
 *
 *  Rooted ----> Handle
 *     |               ^
 *     |               |
 *     |               |
 *     +---> MutableHandle
 *     (via &)
 *
 * All of these types have an implicit conversion to raw pointers.
 */

namespace js {

template 
struct BarrierMethods {
};

template 
class RootedBase {};

template 
class HandleBase {};

template 
class MutableHandleBase {};

template 
class HeapBase {};

// Cannot use FOR_EACH_HEAP_ABLE_GC_POINTER_TYPE, as this would import too many macros into scope
template  struct IsHeapConstructibleType    { static constexpr bool value = false; };
#define DECLARE_IS_HEAP_CONSTRUCTIBLE_TYPE(T) \
    template <> struct IsHeapConstructibleType { static constexpr bool value = true; };
FOR_EACH_PUBLIC_GC_POINTER_TYPE(DECLARE_IS_HEAP_CONSTRUCTIBLE_TYPE)
FOR_EACH_PUBLIC_TAGGED_GC_POINTER_TYPE(DECLARE_IS_HEAP_CONSTRUCTIBLE_TYPE)
#undef DECLARE_IS_HEAP_CONSTRUCTIBLE_TYPE

template 
class PersistentRootedBase {};

static void* const ConstNullValue = nullptr;

namespace gc {
struct Cell;
template
struct PersistentRootedMarker;
} /* namespace gc */

// Important: Return a reference so passing a Rooted, etc. to
// something that takes a |const T&| is not a GC hazard.
#define DECLARE_POINTER_CONSTREF_OPS(T)                                                           \
    operator const T&() const { return get(); }                                                   \
    const T& operator->() const { return get(); }

// Assignment operators on a base class are hidden by the implicitly defined
// operator= on the derived class. Thus, define the operator= directly on the
// class as we would need to manually pass it through anyway.
#define DECLARE_POINTER_ASSIGN_OPS(Wrapper, T)                                                    \
    Wrapper& operator=(const T& p) {                                                           \
        set(p);                                                                                   \
        return *this;                                                                             \
    }                                                                                             \
    Wrapper& operator=(const Wrapper& other) {                                              \
        set(other.get());                                                                         \
        return *this;                                                                             \
    }                                                                                             \

#define DELETE_ASSIGNMENT_OPS(Wrapper, T)                                                         \
    template  Wrapper& operator=(S) = delete;                                      \
    Wrapper& operator=(const Wrapper&) = delete;

#define DECLARE_NONPOINTER_ACCESSOR_METHODS(ptr)                                                  \
    const T* address() const { return &(ptr); }                                                   \
    const T& get() const { return (ptr); }                                                        \

#define DECLARE_NONPOINTER_MUTABLE_ACCESSOR_METHODS(ptr)                                          \
    T* address() { return &(ptr); }                                                               \
    T& get() { return (ptr); }                                                                    \

} /* namespace js */

namespace JS {

template  class Rooted;
template  class PersistentRooted;

/* This is exposing internal state of the GC for inlining purposes. */
JS_FRIEND_API(bool) isGCEnabled();

JS_FRIEND_API(void) HeapObjectPostBarrier(JSObject** objp, JSObject* prev, JSObject* next);

#ifdef JS_DEBUG
/**
 * For generational GC, assert that an object is in the tenured generation as
 * opposed to being in the nursery.
 */
extern JS_FRIEND_API(void)
AssertGCThingMustBeTenured(JSObject* obj);
extern JS_FRIEND_API(void)
AssertGCThingIsNotAnObjectSubclass(js::gc::Cell* cell);
#else
inline void
AssertGCThingMustBeTenured(JSObject* obj) {}
inline void
AssertGCThingIsNotAnObjectSubclass(js::gc::Cell* cell) {}
#endif

/**
 * The Heap class is a heap-stored reference to a JS GC thing. All members of
 * heap classes that refer to GC things should use Heap (or possibly
 * TenuredHeap, described below).
 *
 * Heap is an abstraction that hides some of the complexity required to
 * maintain GC invariants for the contained reference. It uses operator
 * overloading to provide a normal pointer interface, but notifies the GC every
 * time the value it contains is updated. This is necessary for generational GC,
 * which keeps track of all pointers into the nursery.
 *
 * Heap instances must be traced when their containing object is traced to
 * keep the pointed-to GC thing alive.
 *
 * Heap objects should only be used on the heap. GC references stored on the
 * C/C++ stack must use Rooted/Handle/MutableHandle instead.
 *
 * Type T must be a public GC pointer type.
 */
template 
class Heap : public js::HeapBase
{
    // Please note: this can actually also be used by nsXBLMaybeCompiled, for legacy reasons.
    static_assert(js::IsHeapConstructibleType::value,
                  "Type T must be a public GC pointer type");
  public:
    using ElementType = T;

    Heap() {
        static_assert(sizeof(T) == sizeof(Heap),
                      "Heap must be binary compatible with T.");
        init(GCPolicy::initial());
    }
    explicit Heap(const T& p) { init(p); }

    /*
     * For Heap, move semantics are equivalent to copy semantics. In C++, a
     * copy constructor taking const-ref is the way to get a single function
     * that will be used for both lvalue and rvalue copies, so we can simply
     * omit the rvalue variant.
     */
    explicit Heap(const Heap& p) { init(p.ptr); }

    ~Heap() {
        post(ptr, GCPolicy::initial());
    }

    DECLARE_POINTER_CONSTREF_OPS(T);
    DECLARE_POINTER_ASSIGN_OPS(Heap, T);

    const T* address() const { return &ptr; }

    void exposeToActiveJS() const {
        js::BarrierMethods::exposeToJS(ptr);
    }
    const T& get() const {
        exposeToActiveJS();
        return ptr;
    }
    const T& unbarrieredGet() const {
        return ptr;
    }

    T* unsafeGet() { return &ptr; }

    explicit operator bool() const {
        return bool(js::BarrierMethods::asGCThingOrNull(ptr));
    }
    explicit operator bool() {
        return bool(js::BarrierMethods::asGCThingOrNull(ptr));
    }

  private:
    void init(const T& newPtr) {
        ptr = newPtr;
        post(GCPolicy::initial(), ptr);
    }

    void set(const T& newPtr) {
        T tmp = ptr;
        ptr = newPtr;
        post(tmp, ptr);
    }

    void post(const T& prev, const T& next) {
        js::BarrierMethods::postBarrier(&ptr, prev, next);
    }

    T ptr;
};

static MOZ_ALWAYS_INLINE bool
ObjectIsTenured(JSObject* obj)
{
    return !js::gc::IsInsideNursery(reinterpret_cast(obj));
}

static MOZ_ALWAYS_INLINE bool
ObjectIsTenured(const Heap& obj)
{
    return ObjectIsTenured(obj.unbarrieredGet());
}

static MOZ_ALWAYS_INLINE bool
ObjectIsMarkedGray(JSObject* obj)
{
    /*
     * GC things residing in the nursery cannot be gray: they have no mark bits.
     * All live objects in the nursery are moved to tenured at the beginning of
     * each GC slice, so the gray marker never sees nursery things.
     */
    if (js::gc::IsInsideNursery(reinterpret_cast(obj)))
        return false;
    return js::gc::detail::CellIsMarkedGray(reinterpret_cast(obj));
}

static MOZ_ALWAYS_INLINE bool
ObjectIsMarkedGray(const JS::Heap& obj)
{
    return ObjectIsMarkedGray(obj.unbarrieredGet());
}

static MOZ_ALWAYS_INLINE bool
ScriptIsMarkedGray(JSScript* script)
{
    return js::gc::detail::CellIsMarkedGray(reinterpret_cast(script));
}

static MOZ_ALWAYS_INLINE bool
ScriptIsMarkedGray(const Heap& script)
{
    return ScriptIsMarkedGray(script.unbarrieredGet());
}

/**
 * The TenuredHeap class is similar to the Heap class above in that it
 * encapsulates the GC concerns of an on-heap reference to a JS object. However,
 * it has two important differences:
 *
 *  1) Pointers which are statically known to only reference "tenured" objects
 *     can avoid the extra overhead of SpiderMonkey's write barriers.
 *
 *  2) Objects in the "tenured" heap have stronger alignment restrictions than
 *     those in the "nursery", so it is possible to store flags in the lower
 *     bits of pointers known to be tenured. TenuredHeap wraps a normal tagged
 *     pointer with a nice API for accessing the flag bits and adds various
 *     assertions to ensure that it is not mis-used.
 *
 * GC things are said to be "tenured" when they are located in the long-lived
 * heap: e.g. they have gained tenure as an object by surviving past at least
 * one GC. For performance, SpiderMonkey allocates some things which are known
 * to normally be long lived directly into the tenured generation; for example,
 * global objects. Additionally, SpiderMonkey does not visit individual objects
 * when deleting non-tenured objects, so object with finalizers are also always
 * tenured; for instance, this includes most DOM objects.
 *
 * The considerations to keep in mind when using a TenuredHeap vs a normal
 * Heap are:
 *
 *  - It is invalid for a TenuredHeap to refer to a non-tenured thing.
 *  - It is however valid for a Heap to refer to a tenured thing.
 *  - It is not possible to store flag bits in a Heap.
 */
template 
class TenuredHeap : public js::HeapBase
{
  public:
    using ElementType = T;

    TenuredHeap() : bits(0) {
        static_assert(sizeof(T) == sizeof(TenuredHeap),
                      "TenuredHeap must be binary compatible with T.");
    }
    explicit TenuredHeap(T p) : bits(0) { setPtr(p); }
    explicit TenuredHeap(const TenuredHeap& p) : bits(0) { setPtr(p.getPtr()); }

    void setPtr(T newPtr) {
        MOZ_ASSERT((reinterpret_cast(newPtr) & flagsMask) == 0);
        if (newPtr)
            AssertGCThingMustBeTenured(newPtr);
        bits = (bits & flagsMask) | reinterpret_cast(newPtr);
    }

    void setFlags(uintptr_t flagsToSet) {
        MOZ_ASSERT((flagsToSet & ~flagsMask) == 0);
        bits |= flagsToSet;
    }

    void unsetFlags(uintptr_t flagsToUnset) {
        MOZ_ASSERT((flagsToUnset & ~flagsMask) == 0);
        bits &= ~flagsToUnset;
    }

    bool hasFlag(uintptr_t flag) const {
        MOZ_ASSERT((flag & ~flagsMask) == 0);
        return (bits & flag) != 0;
    }

    T unbarrieredGetPtr() const { return reinterpret_cast(bits & ~flagsMask); }
    uintptr_t getFlags() const { return bits & flagsMask; }

    void exposeToActiveJS() const {
        js::BarrierMethods::exposeToJS(unbarrieredGetPtr());
    }
    T getPtr() const {
        exposeToActiveJS();
        return unbarrieredGetPtr();
    }

    operator T() const { return getPtr(); }
    T operator->() const { return getPtr(); }

    explicit operator bool() const {
        return bool(js::BarrierMethods::asGCThingOrNull(unbarrieredGetPtr()));
    }
    explicit operator bool() {
        return bool(js::BarrierMethods::asGCThingOrNull(unbarrieredGetPtr()));
    }

    TenuredHeap& operator=(T p) {
        setPtr(p);
        return *this;
    }

    TenuredHeap& operator=(const TenuredHeap& other) {
        bits = other.bits;
        return *this;
    }

  private:
    enum {
        maskBits = 3,
        flagsMask = (1 << maskBits) - 1,
    };

    uintptr_t bits;
};

/**
 * Reference to a T that has been rooted elsewhere. This is most useful
 * as a parameter type, which guarantees that the T lvalue is properly
 * rooted. See "Move GC Stack Rooting" above.
 *
 * If you want to add additional methods to Handle for a specific
 * specialization, define a HandleBase specialization containing them.
 */
template 
class MOZ_NONHEAP_CLASS Handle : public js::HandleBase
{
    friend class JS::MutableHandle;

  public:
    using ElementType = T;

    /* Creates a handle from a handle of a type convertible to T. */
    template 
    MOZ_IMPLICIT Handle(Handle handle,
                        typename mozilla::EnableIf::value, int>::Type dummy = 0)
    {
        static_assert(sizeof(Handle) == sizeof(T*),
                      "Handle must be binary compatible with T*.");
        ptr = reinterpret_cast(handle.address());
    }

    MOZ_IMPLICIT Handle(decltype(nullptr)) {
        static_assert(mozilla::IsPointer::value,
                      "nullptr_t overload not valid for non-pointer types");
        ptr = reinterpret_cast(&js::ConstNullValue);
    }

    MOZ_IMPLICIT Handle(MutableHandle handle) {
        ptr = handle.address();
    }

    /*
     * Take care when calling this method!
     *
     * This creates a Handle from the raw location of a T.
     *
     * It should be called only if the following conditions hold:
     *
     *  1) the location of the T is guaranteed to be marked (for some reason
     *     other than being a Rooted), e.g., if it is guaranteed to be reachable
     *     from an implicit root.
     *
     *  2) the contents of the location are immutable, or at least cannot change
     *     for the lifetime of the handle, as its users may not expect its value
     *     to change underneath them.
     */
    static constexpr Handle fromMarkedLocation(const T* p) {
        return Handle(p, DeliberatelyChoosingThisOverload,
                      ImUsingThisOnlyInFromFromMarkedLocation);
    }

    /*
     * Construct a handle from an explicitly rooted location. This is the
     * normal way to create a handle, and normally happens implicitly.
     */
    template 
    inline
    MOZ_IMPLICIT Handle(const Rooted& root,
                        typename mozilla::EnableIf::value, int>::Type dummy = 0);

    template 
    inline
    MOZ_IMPLICIT Handle(const PersistentRooted& root,
                        typename mozilla::EnableIf::value, int>::Type dummy = 0);

    /* Construct a read only handle from a mutable handle. */
    template 
    inline
    MOZ_IMPLICIT Handle(MutableHandle& root,
                        typename mozilla::EnableIf::value, int>::Type dummy = 0);

    DECLARE_POINTER_CONSTREF_OPS(T);
    DECLARE_NONPOINTER_ACCESSOR_METHODS(*ptr);

  private:
    Handle() {}
    DELETE_ASSIGNMENT_OPS(Handle, T);

    enum Disambiguator { DeliberatelyChoosingThisOverload = 42 };
    enum CallerIdentity { ImUsingThisOnlyInFromFromMarkedLocation = 17 };
    constexpr Handle(const T* p, Disambiguator, CallerIdentity) : ptr(p) {}

    const T* ptr;
};

/**
 * Similar to a handle, but the underlying storage can be changed. This is
 * useful for outparams.
 *
 * If you want to add additional methods to MutableHandle for a specific
 * specialization, define a MutableHandleBase specialization containing
 * them.
 */
template 
class MOZ_STACK_CLASS MutableHandle : public js::MutableHandleBase
{
  public:
    using ElementType = T;

    inline MOZ_IMPLICIT MutableHandle(Rooted* root);
    inline MOZ_IMPLICIT MutableHandle(PersistentRooted* root);

  private:
    // Disallow nullptr for overloading purposes.
    MutableHandle(decltype(nullptr)) = delete;

  public:
    void set(const T& v) {
        *ptr = v;
    }

    /*
     * This may be called only if the location of the T is guaranteed
     * to be marked (for some reason other than being a Rooted),
     * e.g., if it is guaranteed to be reachable from an implicit root.
     *
     * Create a MutableHandle from a raw location of a T.
     */
    static MutableHandle fromMarkedLocation(T* p) {
        MutableHandle h;
        h.ptr = p;
        return h;
    }

    DECLARE_POINTER_CONSTREF_OPS(T);
    DECLARE_NONPOINTER_ACCESSOR_METHODS(*ptr);
    DECLARE_NONPOINTER_MUTABLE_ACCESSOR_METHODS(*ptr);

  private:
    MutableHandle() {}
    DELETE_ASSIGNMENT_OPS(MutableHandle, T);

    T* ptr;
};

} /* namespace JS */

namespace js {

template 
struct BarrierMethods
{
    static T* initial() { return nullptr; }
    static gc::Cell* asGCThingOrNull(T* v) {
        if (!v)
            return nullptr;
        MOZ_ASSERT(uintptr_t(v) > 32);
        return reinterpret_cast(v);
    }
    static void postBarrier(T** vp, T* prev, T* next) {
        if (next)
            JS::AssertGCThingIsNotAnObjectSubclass(reinterpret_cast(next));
    }
    static void exposeToJS(T* t) {
        if (t)
            js::gc::ExposeGCThingToActiveJS(JS::GCCellPtr(t));
    }
};

template <>
struct BarrierMethods
{
    static JSObject* initial() { return nullptr; }
    static gc::Cell* asGCThingOrNull(JSObject* v) {
        if (!v)
            return nullptr;
        MOZ_ASSERT(uintptr_t(v) > 32);
        return reinterpret_cast(v);
    }
    static void postBarrier(JSObject** vp, JSObject* prev, JSObject* next) {
        JS::HeapObjectPostBarrier(vp, prev, next);
    }
    static void exposeToJS(JSObject* obj) {
        if (obj)
            JS::ExposeObjectToActiveJS(obj);
    }
};

template <>
struct BarrierMethods
{
    static JSFunction* initial() { return nullptr; }
    static gc::Cell* asGCThingOrNull(JSFunction* v) {
        if (!v)
            return nullptr;
        MOZ_ASSERT(uintptr_t(v) > 32);
        return reinterpret_cast(v);
    }
    static void postBarrier(JSFunction** vp, JSFunction* prev, JSFunction* next) {
        JS::HeapObjectPostBarrier(reinterpret_cast(vp),
                                  reinterpret_cast(prev),
                                  reinterpret_cast(next));
    }
    static void exposeToJS(JSFunction* fun) {
        if (fun)
            JS::ExposeObjectToActiveJS(reinterpret_cast(fun));
    }
};

// Provide hash codes for Cell kinds that may be relocated and, thus, not have
// a stable address to use as the base for a hash code. Instead of the address,
// this hasher uses Cell::getUniqueId to provide exact matches and as a base
// for generating hash codes.
//
// Note: this hasher, like PointerHasher can "hash" a nullptr. While a nullptr
// would not likely be a useful key, there are some cases where being able to
// hash a nullptr is useful, either on purpose or because of bugs:
// (1) existence checks where the key may happen to be null and (2) some
// aggregate Lookup kinds embed a JSObject* that is frequently null and do not
// null test before dispatching to the hasher.
template 
struct JS_PUBLIC_API(MovableCellHasher)
{
    using Key = T;
    using Lookup = T;

    static bool hasHash(const Lookup& l);
    static bool ensureHash(const Lookup& l);
    static HashNumber hash(const Lookup& l);
    static bool match(const Key& k, const Lookup& l);
    static void rekey(Key& k, const Key& newKey) { k = newKey; }
};

template 
struct JS_PUBLIC_API(MovableCellHasher>)
{
    using Key = JS::Heap;
    using Lookup = T;

    static bool hasHash(const Lookup& l) { return MovableCellHasher::hasHash(l); }
    static bool ensureHash(const Lookup& l) { return MovableCellHasher::ensureHash(l); }
    static HashNumber hash(const Lookup& l) { return MovableCellHasher::hash(l); }
    static bool match(const Key& k, const Lookup& l) {
        return MovableCellHasher::match(k.unbarrieredGet(), l);
    }
    static void rekey(Key& k, const Key& newKey) { k.unsafeSet(newKey); }
};

template 
struct FallibleHashMethods>
{
    template  static bool hasHash(Lookup&& l) {
        return MovableCellHasher::hasHash(mozilla::Forward(l));
    }
    template  static bool ensureHash(Lookup&& l) {
        return MovableCellHasher::ensureHash(mozilla::Forward(l));
    }
};

} /* namespace js */

namespace js {

// The alignment must be set because the Rooted and PersistentRooted ptr fields
// may be accessed through reinterpret_cast*>, and
// the compiler may choose a different alignment for the ptr field when it
// knows the actual type stored in DispatchWrapper.
//
// It would make more sense to align only those specific fields of type
// DispatchWrapper, rather than DispatchWrapper itself, but that causes MSVC to
// fail when Rooted is used in an IsConvertible test.
template 
class alignas(8) DispatchWrapper
{
    static_assert(JS::MapTypeToRootKind::kind == JS::RootKind::Traceable,
                  "DispatchWrapper is intended only for usage with a Traceable");

    using TraceFn = void (*)(JSTracer*, T*, const char*);
    TraceFn tracer;
    alignas(gc::CellSize) T storage;

  public:
    template 
    MOZ_IMPLICIT DispatchWrapper(U&& initial)
      : tracer(&JS::GCPolicy::trace),
        storage(mozilla::Forward(initial))
    { }

    // Mimic a pointer type, so that we can drop into Rooted.
    T* operator &() { return &storage; }
    const T* operator &() const { return &storage; }
    operator T&() { return storage; }
    operator const T&() const { return storage; }

    // Trace the contained storage (of unknown type) using the trace function
    // we set aside when we did know the type.
    static void TraceWrapped(JSTracer* trc, T* thingp, const char* name) {
        auto wrapper = reinterpret_cast(
                           uintptr_t(thingp) - offsetof(DispatchWrapper, storage));
        wrapper->tracer(trc, &wrapper->storage, name);
    }
};

} /* namespace js */

namespace JS {

/**
 * Local variable of type T whose value is always rooted. This is typically
 * used for local variables, or for non-rooted values being passed to a
 * function that requires a handle, e.g. Foo(Root(cx, x)).
 *
 * If you want to add additional methods to Rooted for a specific
 * specialization, define a RootedBase specialization containing them.
 */
template 
class MOZ_RAII Rooted : public js::RootedBase
{
    inline void registerWithRootLists(js::RootedListHeads& roots) {
        this->stack = &roots[JS::MapTypeToRootKind::kind];
        this->prev = *stack;
        *stack = reinterpret_cast*>(this);
    }

    inline js::RootedListHeads& rootLists(JS::RootingContext* cx) {
        return rootLists(static_cast(cx));
    }
    inline js::RootedListHeads& rootLists(js::ContextFriendFields* cx) {
        if (JS::Zone* zone = cx->zone_)
            return JS::shadow::Zone::asShadowZone(zone)->stackRoots_;
        MOZ_ASSERT(cx->isJSContext);
        return cx->roots.stackRoots_;
    }
    inline js::RootedListHeads& rootLists(JSContext* cx) {
        return rootLists(js::ContextFriendFields::get(cx));
    }

  public:
    using ElementType = T;

    template 
    explicit Rooted(const RootingContext& cx)
      : ptr(GCPolicy::initial())
    {
        registerWithRootLists(rootLists(cx));
    }

    template 
    Rooted(const RootingContext& cx, S&& initial)
      : ptr(mozilla::Forward(initial))
    {
        registerWithRootLists(rootLists(cx));
    }

    ~Rooted() {
        MOZ_ASSERT(*stack == reinterpret_cast*>(this));
        *stack = prev;
    }

    Rooted* previous() { return reinterpret_cast*>(prev); }

    /*
     * This method is public for Rooted so that Codegen.py can use a Rooted
     * interchangeably with a MutableHandleValue.
     */
    void set(const T& value) {
        ptr = value;
    }

    DECLARE_POINTER_CONSTREF_OPS(T);
    DECLARE_POINTER_ASSIGN_OPS(Rooted, T);
    DECLARE_NONPOINTER_ACCESSOR_METHODS(ptr);
    DECLARE_NONPOINTER_MUTABLE_ACCESSOR_METHODS(ptr);

  private:
    /*
     * These need to be templated on void* to avoid aliasing issues between, for
     * example, Rooted and Rooted, which use the same
     * stack head pointer for different classes.
     */
    Rooted** stack;
    Rooted* prev;

    /*
     * For pointer types, the TraceKind for tracing is based on the list it is
     * in (selected via MapTypeToRootKind), so no additional storage is
     * required here. Non-pointer types, however, share the same list, so the
     * function to call for tracing is stored adjacent to the struct. Since C++
     * cannot templatize on storage class, this is implemented via the wrapper
     * class DispatchWrapper.
     */
    using MaybeWrapped = typename mozilla::Conditional<
        MapTypeToRootKind::kind == JS::RootKind::Traceable,
        js::DispatchWrapper,
        T>::Type;
    MaybeWrapped ptr;

    Rooted(const Rooted&) = delete;
} JS_HAZ_ROOTED;

} /* namespace JS */

namespace js {

/**
 * Augment the generic Rooted interface when T = JSObject* with
 * class-querying and downcasting operations.
 *
 * Given a Rooted obj, one can view
 *   Handle h = obj.as();
 * as an optimization of
 *   Rooted rooted(cx, &obj->as());
 *   Handle h = rooted;
 */
template <>
class RootedBase
{
  public:
    template 
    JS::Handle as() const;
};

/**
 * Augment the generic Handle interface when T = JSObject* with
 * downcasting operations.
 *
 * Given a Handle obj, one can view
 *   Handle h = obj.as();
 * as an optimization of
 *   Rooted rooted(cx, &obj->as());
 *   Handle h = rooted;
 */
template <>
class HandleBase
{
  public:
    template 
    JS::Handle as() const;
};

/** Interface substitute for Rooted which does not root the variable's memory. */
template 
class MOZ_RAII FakeRooted : public RootedBase
{
  public:
    using ElementType = T;

    template 
    explicit FakeRooted(CX* cx) : ptr(JS::GCPolicy::initial()) {}

    template 
    FakeRooted(CX* cx, T initial) : ptr(initial) {}

    DECLARE_POINTER_CONSTREF_OPS(T);
    DECLARE_POINTER_ASSIGN_OPS(FakeRooted, T);
    DECLARE_NONPOINTER_ACCESSOR_METHODS(ptr);
    DECLARE_NONPOINTER_MUTABLE_ACCESSOR_METHODS(ptr);

  private:
    T ptr;

    void set(const T& value) {
        ptr = value;
    }

    FakeRooted(const FakeRooted&) = delete;
};

/** Interface substitute for MutableHandle which is not required to point to rooted memory. */
template 
class FakeMutableHandle : public js::MutableHandleBase
{
  public:
    using ElementType = T;

    MOZ_IMPLICIT FakeMutableHandle(T* t) {
        ptr = t;
    }

    MOZ_IMPLICIT FakeMutableHandle(FakeRooted* root) {
        ptr = root->address();
    }

    void set(const T& v) {
        *ptr = v;
    }

    DECLARE_POINTER_CONSTREF_OPS(T);
    DECLARE_NONPOINTER_ACCESSOR_METHODS(*ptr);
    DECLARE_NONPOINTER_MUTABLE_ACCESSOR_METHODS(*ptr);

  private:
    FakeMutableHandle() {}
    DELETE_ASSIGNMENT_OPS(FakeMutableHandle, T);

    T* ptr;
};

/**
 * Types for a variable that either should or shouldn't be rooted, depending on
 * the template parameter allowGC. Used for implementing functions that can
 * operate on either rooted or unrooted data.
 *
 * The toHandle() and toMutableHandle() functions are for calling functions
 * which require handle types and are only called in the CanGC case. These
 * allow the calling code to type check.
 */
enum AllowGC {
    NoGC = 0,
    CanGC = 1
};
template 
class MaybeRooted
{
};

template  class MaybeRooted
{
  public:
    typedef JS::Handle HandleType;
    typedef JS::Rooted RootType;
    typedef JS::MutableHandle MutableHandleType;

    static inline JS::Handle toHandle(HandleType v) {
        return v;
    }

    static inline JS::MutableHandle toMutableHandle(MutableHandleType v) {
        return v;
    }

    template 
    static inline JS::Handle downcastHandle(HandleType v) {
        return v.template as();
    }
};

template  class MaybeRooted
{
  public:
    typedef const T& HandleType;
    typedef FakeRooted RootType;
    typedef FakeMutableHandle MutableHandleType;

    static JS::Handle toHandle(HandleType v) {
        MOZ_CRASH("Bad conversion");
    }

    static JS::MutableHandle toMutableHandle(MutableHandleType v) {
        MOZ_CRASH("Bad conversion");
    }

    template 
    static inline T2* downcastHandle(HandleType v) {
        return &v->template as();
    }
};

} /* namespace js */

namespace JS {

template  template 
inline
Handle::Handle(const Rooted& root,
                  typename mozilla::EnableIf::value, int>::Type dummy)
{
    ptr = reinterpret_cast(root.address());
}

template  template 
inline
Handle::Handle(const PersistentRooted& root,
                  typename mozilla::EnableIf::value, int>::Type dummy)
{
    ptr = reinterpret_cast(root.address());
}

template  template 
inline
Handle::Handle(MutableHandle& root,
                  typename mozilla::EnableIf::value, int>::Type dummy)
{
    ptr = reinterpret_cast(root.address());
}

template 
inline
MutableHandle::MutableHandle(Rooted* root)
{
    static_assert(sizeof(MutableHandle) == sizeof(T*),
                  "MutableHandle must be binary compatible with T*.");
    ptr = root->address();
}

template 
inline
MutableHandle::MutableHandle(PersistentRooted* root)
{
    static_assert(sizeof(MutableHandle) == sizeof(T*),
                  "MutableHandle must be binary compatible with T*.");
    ptr = root->address();
}

/**
 * A copyable, assignable global GC root type with arbitrary lifetime, an
 * infallible constructor, and automatic unrooting on destruction.
 *
 * These roots can be used in heap-allocated data structures, so they are not
 * associated with any particular JSContext or stack. They are registered with
 * the JSRuntime itself, without locking, so they require a full JSContext to be
 * initialized, not one of its more restricted superclasses. Initialization may
 * take place on construction, or in two phases if the no-argument constructor
 * is called followed by init().
 *
 * Note that you must not use an PersistentRooted in an object owned by a JS
 * object:
 *
 * Whenever one object whose lifetime is decided by the GC refers to another
 * such object, that edge must be traced only if the owning JS object is traced.
 * This applies not only to JS objects (which obviously are managed by the GC)
 * but also to C++ objects owned by JS objects.
 *
 * If you put a PersistentRooted in such a C++ object, that is almost certainly
 * a leak. When a GC begins, the referent of the PersistentRooted is treated as
 * live, unconditionally (because a PersistentRooted is a *root*), even if the
 * JS object that owns it is unreachable. If there is any path from that
 * referent back to the JS object, then the C++ object containing the
 * PersistentRooted will not be destructed, and the whole blob of objects will
 * not be freed, even if there are no references to them from the outside.
 *
 * In the context of Firefox, this is a severe restriction: almost everything in
 * Firefox is owned by some JS object or another, so using PersistentRooted in
 * such objects would introduce leaks. For these kinds of edges, Heap or
 * TenuredHeap would be better types. It's up to the implementor of the type
 * containing Heap or TenuredHeap members to make sure their referents get
 * marked when the object itself is marked.
 */
template
class PersistentRooted : public js::PersistentRootedBase,
                         private mozilla::LinkedListElement>
{
    using ListBase = mozilla::LinkedListElement>;

    friend class mozilla::LinkedList;
    friend class mozilla::LinkedListElement;

    void registerWithRootLists(js::RootLists& roots) {
        MOZ_ASSERT(!initialized());
        JS::RootKind kind = JS::MapTypeToRootKind::kind;
        roots.heapRoots_[kind].insertBack(reinterpret_cast*>(this));
    }

    js::RootLists& rootLists(JSContext* cx) {
        return rootLists(JS::RootingContext::get(cx));
    }
    js::RootLists& rootLists(JS::RootingContext* cx) {
        MOZ_ASSERT(cx->isJSContext);
        return cx->roots;
    }

    // Disallow ExclusiveContext*.
    js::RootLists& rootLists(js::ContextFriendFields* cx) = delete;

  public:
    using ElementType = T;

    PersistentRooted() : ptr(GCPolicy::initial()) {}

    template 
    explicit PersistentRooted(const RootingContext& cx)
      : ptr(GCPolicy::initial())
    {
        registerWithRootLists(rootLists(cx));
    }

    template 
    PersistentRooted(const RootingContext& cx, U&& initial)
      : ptr(mozilla::Forward(initial))
    {
        registerWithRootLists(rootLists(cx));
    }

    PersistentRooted(const PersistentRooted& rhs)
      : mozilla::LinkedListElement>(),
        ptr(rhs.ptr)
    {
        /*
         * Copy construction takes advantage of the fact that the original
         * is already inserted, and simply adds itself to whatever list the
         * original was on - no JSRuntime pointer needed.
         *
         * This requires mutating rhs's links, but those should be 'mutable'
         * anyway. C++ doesn't let us declare mutable base classes.
         */
        const_cast(rhs).setNext(this);
    }

    bool initialized() {
        return ListBase::isInList();
    }

    template 
    void init(const RootingContext& cx) {
        init(cx, GCPolicy::initial());
    }

    template 
    void init(const RootingContext& cx, U&& initial) {
        ptr = mozilla::Forward(initial);
        registerWithRootLists(rootLists(cx));
    }

    void reset() {
        if (initialized()) {
            set(GCPolicy::initial());
            ListBase::remove();
        }
    }

    DECLARE_POINTER_CONSTREF_OPS(T);
    DECLARE_POINTER_ASSIGN_OPS(PersistentRooted, T);
    DECLARE_NONPOINTER_ACCESSOR_METHODS(ptr);

    // These are the same as DECLARE_NONPOINTER_MUTABLE_ACCESSOR_METHODS, except
    // they check that |this| is initialized in case the caller later stores
    // something in |ptr|.
    T* address() {
        MOZ_ASSERT(initialized());
        return &ptr;
    }
    T& get() {
        MOZ_ASSERT(initialized());
        return ptr;
    }

  private:
    template 
    void set(U&& value) {
        MOZ_ASSERT(initialized());
        ptr = mozilla::Forward(value);
    }

    // See the comment above Rooted::ptr.
    using MaybeWrapped = typename mozilla::Conditional<
        MapTypeToRootKind::kind == JS::RootKind::Traceable,
        js::DispatchWrapper,
        T>::Type;
    MaybeWrapped ptr;
} JS_HAZ_ROOTED;

class JS_PUBLIC_API(ObjectPtr)
{
    Heap value;

  public:
    using ElementType = JSObject*;

    ObjectPtr() : value(nullptr) {}

    explicit ObjectPtr(JSObject* obj) : value(obj) {}

    /* Always call finalize before the destructor. */
    ~ObjectPtr() { MOZ_ASSERT(!value); }

    void finalize(JSRuntime* rt);
    void finalize(JSContext* cx);

    void init(JSObject* obj) { value = obj; }

    JSObject* get() const { return value; }
    JSObject* unbarrieredGet() const { return value.unbarrieredGet(); }

    void writeBarrierPre(JSContext* cx) {
        IncrementalObjectBarrier(value);
    }

    void updateWeakPointerAfterGC();

    ObjectPtr& operator=(JSObject* obj) {
        IncrementalObjectBarrier(value);
        value = obj;
        return *this;
    }

    void trace(JSTracer* trc, const char* name);

    JSObject& operator*() const { return *value; }
    JSObject* operator->() const { return value; }
    operator JSObject*() const { return value; }

    explicit operator bool() const { return value.unbarrieredGet(); }
    explicit operator bool() { return value.unbarrieredGet(); }
};

} /* namespace JS */

namespace js {

template 
class UniquePtrOperations
{
    const UniquePtr& uniquePtr() const { return static_cast(this)->get(); }

  public:
    explicit operator bool() const { return !!uniquePtr(); }
};

template 
class MutableUniquePtrOperations : public UniquePtrOperations
{
    UniquePtr& uniquePtr() { return static_cast(this)->get(); }

  public:
    MOZ_MUST_USE typename UniquePtr::Pointer release() { return uniquePtr().release(); }
};

template 
class RootedBase>
  : public MutableUniquePtrOperations>, T, D>
{ };

template 
class MutableHandleBase>
  : public MutableUniquePtrOperations>, T, D>
{ };

template 
class HandleBase>
  : public UniquePtrOperations>, T, D>
{ };

template 
class PersistentRootedBase>
  : public MutableUniquePtrOperations>, T, D>
{ };

namespace gc {

template 
void
CallTraceCallbackOnNonHeap(T* v, const TraceCallbacks& aCallbacks, const char* aName, void* aClosure)
{
    static_assert(sizeof(T) == sizeof(JS::Heap), "T and Heap must be compatible.");
    MOZ_ASSERT(v);
    mozilla::DebugOnly cell = BarrierMethods::asGCThingOrNull(*v);
    MOZ_ASSERT(cell);
    MOZ_ASSERT(!IsInsideNursery(cell));
    JS::Heap* asHeapT = reinterpret_cast*>(v);
    aCallbacks.Trace(asHeapT, aName, aClosure);
}

} /* namespace gc */
} /* namespace js */

// mozilla::Swap uses a stack temporary, which prevents classes like Heap
// from being declared MOZ_HEAP_CLASS.
namespace mozilla {

template 
inline void
Swap(JS::Heap& aX, JS::Heap& aY)
{
    T tmp = aX;
    aX = aY;
    aY = tmp;
}

template 
inline void
Swap(JS::TenuredHeap& aX, JS::TenuredHeap& aY)
{
    T tmp = aX;
    aX = aY;
    aY = tmp;
}

} /* namespace mozilla */

namespace js {
namespace detail {

// DefineComparisonOps is a trait which selects which wrapper classes to define
// operator== and operator!= for. It supplies a getter function to extract the
// value to compare. This is used to avoid triggering the automatic read
// barriers where appropriate.
//
// If DefineComparisonOps is not specialized for a particular wrapper you may
// get errors such as 'invalid operands to binary expression' or 'no match for
// operator==' when trying to compare against instances of the wrapper.

template 
struct DefineComparisonOps : mozilla::FalseType {};

template 
struct DefineComparisonOps> : mozilla::TrueType {
    static const T& get(const JS::Heap& v) { return v.unbarrieredGet(); }
};

template 
struct DefineComparisonOps> : mozilla::TrueType {
    static const T get(const JS::TenuredHeap& v) { return v.unbarrieredGetPtr(); }
};

template <>
struct DefineComparisonOps : mozilla::TrueType {
    static const JSObject* get(const JS::ObjectPtr& v) { return v.unbarrieredGet(); }
};

template 
struct DefineComparisonOps> : mozilla::TrueType {
    static const T& get(const JS::Rooted& v) { return v.get(); }
};

template 
struct DefineComparisonOps> : mozilla::TrueType {
    static const T& get(const JS::Handle& v) { return v.get(); }
};

template 
struct DefineComparisonOps> : mozilla::TrueType {
    static const T& get(const JS::MutableHandle& v) { return v.get(); }
};

template 
struct DefineComparisonOps> : mozilla::TrueType {
    static const T& get(const JS::PersistentRooted& v) { return v.get(); }
};

template 
struct DefineComparisonOps> : mozilla::TrueType {
    static const T& get(const js::FakeRooted& v) { return v.get(); }
};

template 
struct DefineComparisonOps> : mozilla::TrueType {
    static const T& get(const js::FakeMutableHandle& v) { return v.get(); }
};

} /* namespace detail */
} /* namespace js */

// Overload operator== and operator!= for all types with the DefineComparisonOps
// trait using the supplied getter.
//
// There are four cases:

// Case 1: comparison between two wrapper objects.

template 
typename mozilla::EnableIf::value &&
                           js::detail::DefineComparisonOps::value, bool>::Type
operator==(const T& a, const U& b) {
    return js::detail::DefineComparisonOps::get(a) == js::detail::DefineComparisonOps::get(b);
}

template 
typename mozilla::EnableIf::value &&
                           js::detail::DefineComparisonOps::value, bool>::Type
operator!=(const T& a, const U& b) {
    return !(a == b);
}

// Case 2: comparison between a wrapper object and its unwrapped element type.

template 
typename mozilla::EnableIf::value, bool>::Type
operator==(const T& a, const typename T::ElementType& b) {
    return js::detail::DefineComparisonOps::get(a) == b;
}

template 
typename mozilla::EnableIf::value, bool>::Type
operator!=(const T& a, const typename T::ElementType& b) {
    return !(a == b);
}

template 
typename mozilla::EnableIf::value, bool>::Type
operator==(const typename T::ElementType& a, const T& b) {
    return a == js::detail::DefineComparisonOps::get(b);
}

template 
typename mozilla::EnableIf::value, bool>::Type
operator!=(const typename T::ElementType& a, const T& b) {
    return !(a == b);
}

// Case 3: For pointer wrappers, comparison between the wrapper and a const
// element pointer.

template 
typename mozilla::EnableIf::value &&
                           mozilla::IsPointer::value, bool>::Type
operator==(const typename mozilla::RemovePointer::Type* a, const T& b) {
    return a == js::detail::DefineComparisonOps::get(b);
}

template 
typename mozilla::EnableIf::value &&
                           mozilla::IsPointer::value, bool>::Type
operator!=(const typename mozilla::RemovePointer::Type* a, const T& b) {
    return !(a == b);
}

template 
typename mozilla::EnableIf::value &&
                           mozilla::IsPointer::value, bool>::Type
operator==(const T& a, const typename mozilla::RemovePointer::Type* b) {
    return js::detail::DefineComparisonOps::get(a) == b;
}

template 
typename mozilla::EnableIf::value &&
                           mozilla::IsPointer::value, bool>::Type
operator!=(const T& a, const typename mozilla::RemovePointer::Type* b) {
    return !(a == b);
}

// Case 4: For pointer wrappers, comparison between the wrapper and nullptr.

template 
typename mozilla::EnableIf::value &&
                           mozilla::IsPointer::value, bool>::Type
operator==(std::nullptr_t a, const T& b) {
    return a == js::detail::DefineComparisonOps::get(b);
}

template 
typename mozilla::EnableIf::value &&
                           mozilla::IsPointer::value, bool>::Type
operator!=(std::nullptr_t a, const T& b) {
    return !(a == b);
}

template 
typename mozilla::EnableIf::value &&
                           mozilla::IsPointer::value, bool>::Type
operator==(const T& a, std::nullptr_t b) {
    return js::detail::DefineComparisonOps::get(a) == b;
}

template 
typename mozilla::EnableIf::value &&
                           mozilla::IsPointer::value, bool>::Type
operator!=(const T& a, std::nullptr_t b) {
    return !(a == b);
}

#undef DELETE_ASSIGNMENT_OPS

#endif  /* js_RootingAPI_h */
