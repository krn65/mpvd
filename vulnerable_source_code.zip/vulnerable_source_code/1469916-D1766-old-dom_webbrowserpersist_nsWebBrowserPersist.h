[DEFAULT]
prefs = dom.performance.enable_scheduler_timing=true
support-files =
  browser_frame_elements.html
  page_privatestorageevent.html
  page_localstorage_e10s.html
  position.html
  test-console-api.html
  test_bug1004814.html
  worker_bug1004814.js
  geo_leak_test.html
  dummy.html
  ping_worker.html
  test_largeAllocation.html
  test_largeAllocation.html^headers^
  test_largeAllocation2.html
  test_largeAllocation2.html^headers^
  test_largeAllocationFormSubmit.sjs
  helper_largeAllocation.js
  !/dom/tests/mochitest/geolocation/network_geolocation.sjs

[browser_allocateGigabyte.js]
disabled = Does not reliably pass on 32-bit systems - bug 1314098
skip-if = !e10s
[browser_autofocus_background.js]
[browser_autofocus_preference.js]
[browser_beforeunload_between_chrome_content.js]
skip-if = !e10s
[browser_bug396843.js]
[browser_bug1004814.js]
[browser_bug1008941_dismissGeolocationHanger.js]
tags = geolocation
[browser_bug1236512.js]
skip-if = os != "mac"
[browser_bug1238427.js]
[browser_bug1316330.js]
skip-if = !e10s
[browser_cancel_keydown_keypress_event.js]
support-files =
  prevent_return_key.html
[browser_ConsoleAPI_originAttributes.js]
[browser_ConsoleAPITests.js]
skip-if = e10s
[browser_ConsoleStorageAPITests.js]
[browser_ConsoleStoragePBTest_perwindowpb.js]
[browser_focus_steal_from_chrome.js]
[browser_focus_steal_from_chrome_during_mousedown.js]
[browser_frame_elements.js]
[browser_hasbeforeunload.js]
support-files =
  beforeunload_test_page.html
run-if = e10s
[browser_largeAllocation_win32.js]
skip-if = !e10s || os != "win" || processor != "x86" # Large-Allocation requires e10s
[browser_largeAllocation_non_win32.js]
skip-if = !e10s || (os == "win" && processor == "x86") || (verify && debug && (os == 'linux')) # Large-Allocation requires e10s
[browser_localStorage_e10s.js]
skip-if = !e10s || verify # This is a test of e10s functionality.
[browser_localStorage_privatestorageevent.js]
[browser_test_focus_after_modal_state.js]
skip-if = verify
support-files =
  focus_after_prompt.html
[browser_test_new_window_from_content.js]
tags = openwindow
skip-if = toolkit == 'android'  || (os == "linux" && debug) # see bug 1261495 for Linux debug time outs
support-files =
  test_new_window_from_content_child.html
[browser_test_toolbars_visibility.js]
support-files =
  test_new_window_from_content_child.html
[browser_xhr_sandbox.js]
[browser_noopener.js]
(verify && debug && (os == 'linux'))
support-files =
  test_noopener_source.html
  test_noopener_target.html
[browser_noopener_null_uri.js]
[browser_test_performance_metrics.js]
skip-if = verify
