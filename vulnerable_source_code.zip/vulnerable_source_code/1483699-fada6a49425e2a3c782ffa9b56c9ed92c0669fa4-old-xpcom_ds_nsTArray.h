/* -*- Mode: C++; tab-width: 8; indent-tabs-mode: nil; c-basic-offset: 2 -*- */
/* vim: set ts=8 sts=2 et sw=2 tw=80: */
/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

#ifndef nsTArray_h__
#define nsTArray_h__

#include "nsTArrayForwardDeclare.h"
#include "mozilla/Alignment.h"
#include "mozilla/ArrayIterator.h"
#include "mozilla/Assertions.h"
#include "mozilla/Attributes.h"
#include "mozilla/BinarySearch.h"
#include "mozilla/CheckedInt.h"
#include "mozilla/fallible.h"
#include "mozilla/FunctionTypeTraits.h"
#include "mozilla/MathAlgorithms.h"
#include "mozilla/MemoryReporting.h"
#include "mozilla/Move.h"
#include "mozilla/mozalloc.h"
#include "mozilla/ReverseIterator.h"
#include "mozilla/TypeTraits.h"
#include "mozilla/Span.h"

#include 

#include "nsCycleCollectionNoteChild.h"
#include "nsAlgorithm.h"
#include "nscore.h"
#include "nsQuickSort.h"
#include "nsDebug.h"
#include "nsISupportsImpl.h"
#include "nsRegionFwd.h"
#include 
#include 
#include 

namespace JS {
template
class Heap;
class ObjectPtr;
} /* namespace JS */

class nsRegion;
namespace mozilla {
namespace layers {
struct TileClient;
} // namespace layers
} // namespace mozilla

namespace mozilla {
struct SerializedStructuredCloneBuffer;
class SourceBufferTask;
} // namespace mozilla

namespace mozilla {
namespace dom {
namespace ipc {
class StructuredCloneData;
} // namespace ipc
} // namespace dom
} // namespace mozilla

namespace mozilla {
namespace dom {
class ClonedMessageData;
class MessagePortMessage;
namespace indexedDB {
struct StructuredCloneReadInfo;
class SerializedStructuredCloneReadInfo;
class ObjectStoreCursorResponse;
} // namespace indexedDB
} // namespace dom
} // namespace mozilla

class JSStructuredCloneData;

//
// nsTArray is a resizable array class, like std::vector.
//
// Unlike std::vector, which follows C++'s construction/destruction rules,
// nsTArray assumes that your "T" can be memmoved()'ed safely.
//
// The public classes defined in this header are
//
//   nsTArray,
//   FallibleTArray,
//   AutoTArray, and
//
// nsTArray and AutoTArray are infallible by default. To opt-in to fallible
// behaviour, use the `mozilla::fallible` parameter and check the return value.
//
// If you just want to declare the nsTArray types (e.g., if you're in a header
// file and don't need the full nsTArray definitions) consider including
// nsTArrayForwardDeclare.h instead of nsTArray.h.
//
// The template parameter (i.e., T in nsTArray) specifies the type of the
// elements and has the following requirements:
//
//   T MUST be safely memmove()'able.
//   T MUST define a copy-constructor.
//   T MAY define operator< for sorting.
//   T MAY define operator== for searching.
//
// (Note that the memmove requirement may be relaxed for certain types - see
// nsTArray_CopyChooser below.)
//
// For methods taking a Comparator instance, the Comparator must be a class
// defining the following methods:
//
//   class Comparator {
//     public:
//       /** @return True if the elements are equals; false otherwise. */
//       bool Equals(const elem_type& a, const Item& b) const;
//
//       /** @return True if (a < b); false otherwise. */
//       bool LessThan(const elem_type& a, const Item& b) const;
//   };
//
// The Equals method is used for searching, and the LessThan method is used for
// searching and sorting.  The |Item| type above can be arbitrary, but must
// match the Item type passed to the sort or search function.
//


//
// nsTArrayFallibleResult and nsTArrayInfallibleResult types are proxy types
// which are used because you cannot use a templated type which is bound to
// void as an argument to a void function.  In order to work around that, we
// encode either a void or a boolean inside these proxy objects, and pass them
// to the aforementioned function instead, and then use the type information to
// decide what to do in the function.
//
// Note that public nsTArray methods should never return a proxy type.  Such
// types are only meant to be used in the internal nsTArray helper methods.
// Public methods returning non-proxy types cannot be called from other
// nsTArray members.
//
struct nsTArrayFallibleResult
{
  // Note: allows implicit conversions from and to bool
  MOZ_IMPLICIT nsTArrayFallibleResult(bool aResult) : mResult(aResult) {}

  MOZ_IMPLICIT operator bool() { return mResult; }

private:
  bool mResult;
};

struct nsTArrayInfallibleResult
{
};

//
// nsTArray*Allocators must all use the same |free()|, to allow swap()'ing
// between fallible and infallible variants.
//

struct nsTArrayFallibleAllocatorBase
{
  typedef bool ResultType;
  typedef nsTArrayFallibleResult ResultTypeProxy;

  static ResultType Result(ResultTypeProxy aResult) { return aResult; }
  static bool Successful(ResultTypeProxy aResult) { return aResult; }
  static ResultTypeProxy SuccessResult() { return true; }
  static ResultTypeProxy FailureResult() { return false; }
  static ResultType ConvertBoolToResultType(bool aValue) { return aValue; }
};

struct nsTArrayInfallibleAllocatorBase
{
  typedef void ResultType;
  typedef nsTArrayInfallibleResult ResultTypeProxy;

  static ResultType Result(ResultTypeProxy aResult) {}
  static bool Successful(ResultTypeProxy) { return true; }
  static ResultTypeProxy SuccessResult() { return ResultTypeProxy(); }

  static ResultTypeProxy FailureResult()
  {
    MOZ_CRASH("Infallible nsTArray should never fail");
    return ResultTypeProxy();
  }

  static ResultType ConvertBoolToResultType(bool aValue)
  {
    if (!aValue) {
      MOZ_CRASH("infallible nsTArray should never convert false to ResultType");
    }
  }
};

struct nsTArrayFallibleAllocator : nsTArrayFallibleAllocatorBase
{
  static void* Malloc(size_t aSize) { return malloc(aSize); }
  static void* Realloc(void* aPtr, size_t aSize)
  {
    return realloc(aPtr, aSize);
  }

  static void Free(void* aPtr) { free(aPtr); }
  static void SizeTooBig(size_t) {}
};

struct nsTArrayInfallibleAllocator : nsTArrayInfallibleAllocatorBase
{
  static void* Malloc(size_t aSize) { return moz_xmalloc(aSize); }
  static void* Realloc(void* aPtr, size_t aSize)
  {
    return moz_xrealloc(aPtr, aSize);
  }

  static void Free(void* aPtr) { free(aPtr); }
  static void SizeTooBig(size_t aSize) { NS_ABORT_OOM(aSize); }
};

// nsTArray_base stores elements into the space allocated beyond
// sizeof(*this).  This is done to minimize the size of the nsTArray
// object when it is empty.
struct nsTArrayHeader
{
  uint32_t mLength;
  uint32_t mCapacity : 31;
  uint32_t mIsAutoArray : 1;
};

extern "C" {
  extern nsTArrayHeader sEmptyTArrayHeader;
}

// This class provides a SafeElementAt method to nsTArray which does
// not take a second default value parameter.
template
struct nsTArray_SafeElementAtHelper
{
  typedef E*       elem_type;
  typedef size_t   index_type;

  // No implementation is provided for these two methods, and that is on
  // purpose, since we don't support these functions on non-pointer type
  // instantiations.
  elem_type& SafeElementAt(index_type aIndex);
  const elem_type& SafeElementAt(index_type aIndex) const;
};

template
struct nsTArray_SafeElementAtHelper
{
  typedef E*       elem_type;
  //typedef const E* const_elem_type;   XXX: see below
  typedef size_t   index_type;

  elem_type SafeElementAt(index_type aIndex)
  {
    return static_cast(this)->SafeElementAt(aIndex, nullptr);
  }

  // XXX: Probably should return const_elem_type, but callsites must be fixed.
  // Also, the use of const_elem_type for nsTArray in
  // xpcprivate.h causes build failures on Windows because xpcGCCallback is a
  // function pointer and MSVC doesn't like qualifying it with |const|.
  elem_type SafeElementAt(index_type aIndex) const
  {
    return static_cast(this)->SafeElementAt(aIndex, nullptr);
  }
};

// E is the base type that the smart pointer is templated over; the
// smart pointer can act as E*.
template
struct nsTArray_SafeElementAtSmartPtrHelper
{
  typedef E*       elem_type;
  typedef const E* const_elem_type;
  typedef size_t   index_type;

  elem_type SafeElementAt(index_type aIndex)
  {
    return static_cast(this)->SafeElementAt(aIndex, nullptr);
  }

  // XXX: Probably should return const_elem_type, but callsites must be fixed.
  elem_type SafeElementAt(index_type aIndex) const
  {
    return static_cast(this)->SafeElementAt(aIndex, nullptr);
  }
};

template class nsCOMPtr;

template
struct nsTArray_SafeElementAtHelper, Derived>
  : public nsTArray_SafeElementAtSmartPtrHelper
{
};

template
struct nsTArray_SafeElementAtHelper, Derived>
  : public nsTArray_SafeElementAtSmartPtrHelper
{
};

namespace mozilla {
template class OwningNonNull;
} // namespace mozilla

template
struct nsTArray_SafeElementAtHelper, Derived>
{
  typedef E*       elem_type;
  typedef const E* const_elem_type;
  typedef size_t   index_type;

  elem_type SafeElementAt(index_type aIndex)
  {
    if (aIndex < static_cast(this)->Length()) {
      return static_cast(this)->ElementAt(aIndex);
    }
    return nullptr;
  }

  // XXX: Probably should return const_elem_type, but callsites must be fixed.
  elem_type SafeElementAt(index_type aIndex) const
  {
    if (aIndex < static_cast(this)->Length()) {
      return static_cast(this)->ElementAt(aIndex);
    }
    return nullptr;
  }
};

// Servo bindings.
extern "C" void Gecko_EnsureTArrayCapacity(void* aArray,
                                           size_t aCapacity,
                                           size_t aElementSize);
extern "C" void Gecko_ClearPODTArray(void* aArray,
                                     size_t aElementSize,
                                     size_t aElementAlign);

MOZ_NORETURN MOZ_COLD void
InvalidArrayIndex_CRASH(size_t aIndex, size_t aLength);

//
// This class serves as a base class for nsTArray.  It shouldn't be used
// directly.  It holds common implementation code that does not depend on the
// element type of the nsTArray.
//
template
class nsTArray_base
{
  // Allow swapping elements with |nsTArray_base|s created using a
  // different allocator.  This is kosher because all allocators use
  // the same free().
  template
  friend class nsTArray_base;
  friend void Gecko_EnsureTArrayCapacity(void* aArray, size_t aCapacity,
                                         size_t aElemSize);
  friend void Gecko_ClearPODTArray(void* aTArray, size_t aElementSize,
                                   size_t aElementAlign);

protected:
  typedef nsTArrayHeader Header;

public:
  typedef size_t size_type;
  typedef size_t index_type;

  // @return The number of elements in the array.
  size_type Length() const { return mHdr->mLength; }

  // @return True if the array is empty or false otherwise.
  bool IsEmpty() const { return Length() == 0; }

  // @return The number of elements that can fit in the array without forcing
  // the array to be re-allocated.  The length of an array is always less
  // than or equal to its capacity.
  size_type Capacity() const {  return mHdr->mCapacity; }

#ifdef DEBUG
  void* DebugGetHeader() const { return mHdr; }
#endif

protected:
  nsTArray_base();

  ~nsTArray_base();

  // Resize the storage if necessary to achieve the requested capacity.
  // @param aCapacity The requested number of array elements.
  // @param aElemSize The size of an array element.
  // @return False if insufficient memory is available; true otherwise.
  template
  typename ActualAlloc::ResultTypeProxy EnsureCapacity(size_type aCapacity,
                                                       size_type aElemSize);

  // Extend the storage to accommodate aCount extra elements.
  // @param aLength The current size of the array.
  // @param aCount The number of elements to add.
  // @param aElemSize The size of an array element.
  // @return False if insufficient memory is available or the new length
  //   would overflow; true otherwise.
  template
  typename ActualAlloc::ResultTypeProxy ExtendCapacity(size_type aLength,
                                                       size_type aCount,
                                                       size_type aElemSize);

  // Tries to resize the storage to the minimum required amount. If this fails,
  // the array is left as-is.
  // @param aElemSize  The size of an array element.
  // @param aElemAlign The alignment in bytes of an array element.
  void ShrinkCapacity(size_type aElemSize, size_t aElemAlign);

  // This method may be called to resize a "gap" in the array by shifting
  // elements around.  It updates mLength appropriately.  If the resulting
  // array has zero elements, then the array's memory is free'd.
  // @param aStart     The starting index of the gap.
  // @param aOldLen    The current length of the gap.
  // @param aNewLen    The desired length of the gap.
  // @param aElemSize  The size of an array element.
  // @param aElemAlign The alignment in bytes of an array element.
  template
  void ShiftData(index_type aStart, size_type aOldLen, size_type aNewLen,
                 size_type aElemSize, size_t aElemAlign);

  // This method may be called to swap elements from the end of the array to
  // fill a "gap" in the array. If the resulting array has zero elements, then
  // the array's memory is free'd.
  // @param aStart     The starting index of the gap.
  // @param aCount     The length of the gap.
  // @param aElemSize  The size of an array element.
  // @param aElemAlign The alignment in bytes of an array element.
  template
  void SwapFromEnd(index_type aStart, size_type aCount,
                   size_type aElemSize, size_t aElemAlign);

  // This method increments the length member of the array's header.
  // Note that mHdr may actually be sEmptyTArrayHeader in the case where a
  // zero-length array is inserted into our array. But then aNum should
  // always be 0.
  void IncrementLength(size_t aNum)
  {
    if (mHdr == EmptyHdr()) {
      if (MOZ_UNLIKELY(aNum != 0)) {
        // Writing a non-zero length to the empty header would be extremely bad.
        MOZ_CRASH();
      }
    } else {
      mHdr->mLength += aNum;
    }
  }

  // This method inserts blank slots into the array.
  // @param aIndex the place to insert the new elements. This must be no
  //               greater than the current length of the array.
  // @param aCount the number of slots to insert
  // @param aElementSize the size of an array element.
  // @param aElemAlign the alignment in bytes of an array element.
  template
  bool InsertSlotsAt(index_type aIndex, size_type aCount,
                     size_type aElementSize, size_t aElemAlign);

  template
  typename ActualAlloc::ResultTypeProxy
  SwapArrayElements(nsTArray_base& aOther,
                    size_type aElemSize,
                    size_t aElemAlign);

  // This is an RAII class used in SwapArrayElements.
  class IsAutoArrayRestorer
  {
  public:
    IsAutoArrayRestorer(nsTArray_base& aArray, size_t aElemAlign);
    ~IsAutoArrayRestorer();

  private:
    nsTArray_base& mArray;
    size_t mElemAlign;
    bool mIsAuto;
  };

  // Helper function for SwapArrayElements. Ensures that if the array
  // is an AutoTArray that it doesn't use the built-in buffer.
  template
  bool EnsureNotUsingAutoArrayBuffer(size_type aElemSize);

  // Returns true if this nsTArray is an AutoTArray with a built-in buffer.
  bool IsAutoArray() const { return mHdr->mIsAutoArray; }

  // Returns a Header for the built-in buffer of this AutoTArray.
  Header* GetAutoArrayBuffer(size_t aElemAlign)
  {
    MOZ_ASSERT(IsAutoArray(), "Should be an auto array to call this");
    return GetAutoArrayBufferUnsafe(aElemAlign);
  }
  const Header* GetAutoArrayBuffer(size_t aElemAlign) const
  {
    MOZ_ASSERT(IsAutoArray(), "Should be an auto array to call this");
    return GetAutoArrayBufferUnsafe(aElemAlign);
  }

  // Returns a Header for the built-in buffer of this AutoTArray, but doesn't
  // assert that we are an AutoTArray.
  Header* GetAutoArrayBufferUnsafe(size_t aElemAlign)
  {
    return const_cast(static_cast*>(
      this)->GetAutoArrayBufferUnsafe(aElemAlign));
  }
  const Header* GetAutoArrayBufferUnsafe(size_t aElemAlign) const;

  // Returns true if this is an AutoTArray and it currently uses the
  // built-in buffer to store its elements.
  bool UsesAutoArrayBuffer() const;

  // The array's elements (prefixed with a Header).  This pointer is never
  // null.  If the array is empty, then this will point to sEmptyTArrayHeader.
  Header* mHdr;

  Header* Hdr() const { return mHdr; }
  Header** PtrToHdr() { return &mHdr; }
  static Header* EmptyHdr() { return &sEmptyTArrayHeader; }
};

//
// This class defines convenience functions for element specific operations.
// Specialize this template if necessary.
//
template
class nsTArrayElementTraits
{
public:
  // Invoke the default constructor in place.
  static inline void Construct(E* aE)
  {
    // Do NOT call "E()"! That triggers C++ "default initialization"
    // which zeroes out POD ("plain old data") types such as regular
    // ints.  We don't want that because it can be a performance issue
    // and people don't expect it; nsTArray should work like a regular
    // C/C++ array in this respect.
    new (static_cast(aE)) E;
  }
  // Invoke the copy-constructor in place.
  template
  static inline void Construct(E* aE, A&& aArg)
  {
    typedef typename mozilla::RemoveCV::Type E_NoCV;
    typedef typename mozilla::RemoveCV::Type A_NoCV;
    static_assert(!mozilla::IsSame::value,
                  "For safety, we disallow constructing nsTArray elements "
                  "from E* pointers. See bug 960591.");
    new (static_cast(aE)) E(std::forward(aArg));
  }
  // Invoke the destructor in place.
  static inline void Destruct(E* aE) { aE->~E(); }
};

// The default comparator used by nsTArray
template
class nsDefaultComparator
{
public:
  bool Equals(const A& aA, const B& aB) const { return aA == aB; }
  bool LessThan(const A& aA, const B& aB) const { return aA < aB; }
};

template
struct AssignRangeAlgorithm
{
  template
  static void implementation(ElemType* aElements, IndexType aStart,
                             SizeType aCount, const Item* aValues)
  {
    ElemType* iter = aElements + aStart;
    ElemType* end = iter + aCount;
    for (; iter != end; ++iter, ++aValues) {
      nsTArrayElementTraits::Construct(iter, *aValues);
    }
  }
};

template<>
struct AssignRangeAlgorithm
{
  template
  static void implementation(ElemType* aElements, IndexType aStart,
                             SizeType aCount, const Item* aValues)
  {
    memcpy(aElements + aStart, aValues, aCount * sizeof(ElemType));
  }
};

//
// Normally elements are copied with memcpy and memmove, but for some element
// types that is problematic.  The nsTArray_CopyChooser template class can be
// specialized to ensure that copying calls constructors and destructors
// instead, as is done below for JS::Heap elements.
//

//
// A class that defines how to copy elements using memcpy/memmove.
//
struct nsTArray_CopyWithMemutils
{
  const static bool allowRealloc = true;

  static void MoveNonOverlappingRegionWithHeader(void* aDest, const void* aSrc,
                                                 size_t aCount, size_t aElemSize)
  {
    memcpy(aDest, aSrc, sizeof(nsTArrayHeader) + aCount * aElemSize);
  }

  static void MoveOverlappingRegion(void* aDest, void* aSrc, size_t aCount,
                                    size_t aElemSize)
  {
    memmove(aDest, aSrc, aCount * aElemSize);
  }

  static void MoveNonOverlappingRegion(void* aDest, void* aSrc, size_t aCount,
                                       size_t aElemSize)
  {
    memcpy(aDest, aSrc, aCount * aElemSize);
  }
};

//
// A template class that defines how to copy elements calling their constructors
// and destructors appropriately.
//
template
struct nsTArray_CopyWithConstructors
{
  typedef nsTArrayElementTraits traits;

  const static bool allowRealloc = false;

  static void MoveNonOverlappingRegionWithHeader(void* aDest, void* aSrc, size_t aCount,
                                                 size_t aElemSize)
  {
    nsTArrayHeader* destHeader = static_cast(aDest);
    nsTArrayHeader* srcHeader = static_cast(aSrc);
    *destHeader = *srcHeader;
    MoveNonOverlappingRegion(static_cast(aDest) + sizeof(nsTArrayHeader),
                             static_cast(aSrc) + sizeof(nsTArrayHeader),
                             aCount, aElemSize);
  }

  // These functions are defined by analogy with memmove and memcpy.
  // What they actually do is slightly different: MoveOverlappingRegion
  // checks to see which direction the movement needs to take place,
  // whether from back-to-front of the range to be moved or from
  // front-to-back.  MoveNonOverlappingRegion assumes that moving
  // front-to-back is always valid.  So they're really more like
  // std::move{_backward,} in that respect.  We keep these names because
  // we think they read slightly better, and MoveNonOverlappingRegion is
  // only ever called on overlapping regions from MoveOverlappingRegion.
  static void MoveOverlappingRegion(void* aDest, void* aSrc, size_t aCount,
                                    size_t aElemSize)
  {
    ElemType* destElem = static_cast(aDest);
    ElemType* srcElem = static_cast(aSrc);
    ElemType* destElemEnd = destElem + aCount;
    ElemType* srcElemEnd = srcElem + aCount;
    if (destElem == srcElem) {
      return;  // In practice, we don't do this.
    }

    // Figure out whether to copy back-to-front or front-to-back.
    if (srcElemEnd > destElem && srcElemEnd < destElemEnd) {
      while (destElemEnd != destElem) {
        --destElemEnd;
        --srcElemEnd;
        traits::Construct(destElemEnd, std::move(*srcElemEnd));
        traits::Destruct(srcElemEnd);
      }
    } else {
      MoveNonOverlappingRegion(aDest, aSrc, aCount, aElemSize);
    }
  }

  static void MoveNonOverlappingRegion(void* aDest, void* aSrc, size_t aCount,
                                       size_t aElemSize)
  {
    ElemType* destElem = static_cast(aDest);
    ElemType* srcElem = static_cast(aSrc);
    ElemType* destElemEnd = destElem + aCount;
#ifdef DEBUG
    ElemType* srcElemEnd = srcElem + aCount;
    MOZ_ASSERT(srcElemEnd <= destElem || srcElemEnd > destElemEnd);
#endif
    while (destElem != destElemEnd) {
      traits::Construct(destElem, std::move(*srcElem));
      traits::Destruct(srcElem);
      ++destElem;
      ++srcElem;
    }
  }
};

//
// The default behaviour is to use memcpy/memmove for everything.
//
template
struct MOZ_NEEDS_MEMMOVABLE_TYPE nsTArray_CopyChooser
{
  using Type = nsTArray_CopyWithMemutils;
};

//
// Some classes require constructors/destructors to be called, so they are
// specialized here.
//
#define DECLARE_USE_COPY_CONSTRUCTORS(T)                \
  template<>                                            \
  struct nsTArray_CopyChooser                        \
  {                                                     \
    using Type = nsTArray_CopyWithConstructors;      \
  };

#define DECLARE_USE_COPY_CONSTRUCTORS_FOR_TEMPLATE(T)   \
  template                                  \
  struct nsTArray_CopyChooser>                     \
  {                                                     \
    using Type = nsTArray_CopyWithConstructors>;   \
  };

DECLARE_USE_COPY_CONSTRUCTORS_FOR_TEMPLATE(JS::Heap)
DECLARE_USE_COPY_CONSTRUCTORS_FOR_TEMPLATE(std::function)

DECLARE_USE_COPY_CONSTRUCTORS(nsRegion)
DECLARE_USE_COPY_CONSTRUCTORS(nsIntRegion)
DECLARE_USE_COPY_CONSTRUCTORS(mozilla::layers::TileClient)
DECLARE_USE_COPY_CONSTRUCTORS(mozilla::SerializedStructuredCloneBuffer)
DECLARE_USE_COPY_CONSTRUCTORS(mozilla::dom::ipc::StructuredCloneData)
DECLARE_USE_COPY_CONSTRUCTORS(mozilla::dom::ClonedMessageData)
DECLARE_USE_COPY_CONSTRUCTORS(mozilla::dom::indexedDB::StructuredCloneReadInfo);
DECLARE_USE_COPY_CONSTRUCTORS(mozilla::dom::indexedDB::ObjectStoreCursorResponse)
DECLARE_USE_COPY_CONSTRUCTORS(mozilla::dom::indexedDB::SerializedStructuredCloneReadInfo);
DECLARE_USE_COPY_CONSTRUCTORS(JSStructuredCloneData)
DECLARE_USE_COPY_CONSTRUCTORS(mozilla::dom::MessagePortMessage)
DECLARE_USE_COPY_CONSTRUCTORS(mozilla::SourceBufferTask)
DECLARE_USE_COPY_CONSTRUCTORS(JS::ObjectPtr)

//
// Base class for nsTArray_Impl that is templated on element type and derived
// nsTArray_Impl class, to allow extra conversions to be added for specific
// types.
//
template
struct nsTArray_TypedBase : public nsTArray_SafeElementAtHelper
{
};

//
// Specialization of nsTArray_TypedBase for arrays containing JS::Heap
// elements.
//
// These conversions are safe because JS::Heap and E share the same
// representation, and since the result of the conversions are const references
// we won't miss any barriers.
//
// The static_cast is necessary to obtain the correct address for the derived
// class since we are a base class used in multiple inheritance.
//
template
struct nsTArray_TypedBase, Derived>
  : public nsTArray_SafeElementAtHelper, Derived>
{
  operator const nsTArray&()
  {
    static_assert(sizeof(E) == sizeof(JS::Heap),
                  "JS::Heap must be binary compatible with E.");
    Derived* self = static_cast(this);
    return *reinterpret_cast *>(self);
  }

  operator const FallibleTArray&()
  {
    Derived* self = static_cast(this);
    return *reinterpret_cast *>(self);
  }
};

namespace detail {

// These helpers allow us to differentiate between tri-state comparator
// functions and classes with LessThan() and Equal() methods. If an object, when
// called as a function with two instances of our element type, returns an int,
// we treat it as a tri-state comparator.
//
// T is the type of the comparator object we want to check. U is the array
// element type that we'll be comparing.
//
// V is never passed, and is only used to allow us to specialize on the return
// value of the comparator function.
template 
struct IsCompareMethod : mozilla::FalseType {};

template 
struct IsCompareMethod()(mozilla::DeclVal(), mozilla::DeclVal()))>
  : mozilla::TrueType {};

// These two wrappers allow us to use either a tri-state comparator, or an
// object with Equals() and LessThan() methods interchangeably. They provide a
// tri-state Compare() method, and Equals() method, and a LessThan() method.
//
// Depending on the type of the underlying comparator, they either pass these
// through directly, or synthesize them from the methods available on the
// comparator.
//
// Callers should always use the most-specific of these methods that match their
// purpose.

// Comparator wrapper for a tri-state comparator function
template ::value>
struct CompareWrapper
{
#ifdef _MSC_VER
#pragma warning(push)
#pragma warning(disable:4180) /* Silence "qualifier applied to function type has no meaning" warning */
#endif
  MOZ_IMPLICIT CompareWrapper(const T& aComparator)
    : mComparator(aComparator)
  {}

  template 
  int Compare(A& aLeft, B& aRight) const
  {
    return mComparator(aLeft, aRight);
  }

  template 
  bool Equals(A& aLeft, B& aRight) const
  {
    return Compare(aLeft, aRight) == 0;
  }

  template 
  bool LessThan(A& aLeft, B& aRight) const
  {
    return Compare(aLeft, aRight) < 0;
  }

  const T& mComparator;
#ifdef _MSC_VER
#pragma warning(pop)
#endif
};

// Comparator wrapper for a class with Equals() and LessThan() methods.
template 
struct CompareWrapper
{
  MOZ_IMPLICIT CompareWrapper(const T& aComparator)
    : mComparator(aComparator)
  {}

  template 
  int Compare(A& aLeft, B& aRight) const
  {
    if (Equals(aLeft, aRight)) {
      return 0;
    }
    return LessThan(aLeft, aRight) ? -1 : 1;
  }

  template 
  bool Equals(A& aLeft, B& aRight) const
  {
    return mComparator.Equals(aLeft, aRight);
  }

  template 
  bool LessThan(A& aLeft, B& aRight) const
  {
    return mComparator.LessThan(aLeft, aRight);
  }

  const T& mComparator;
};

} // namespace detail

//
// nsTArray_Impl contains most of the guts supporting nsTArray, FallibleTArray,
// AutoTArray.
//
// The only situation in which you might need to use nsTArray_Impl in your code
// is if you're writing code which mutates a TArray which may or may not be
// infallible.
//
// Code which merely reads from a TArray which may or may not be infallible can
// simply cast the TArray to |const nsTArray&|; both fallible and infallible
// TArrays can be cast to |const nsTArray&|.
//
template
class nsTArray_Impl
  : public nsTArray_base::Type>
  , public nsTArray_TypedBase>
{
private:
  typedef nsTArrayFallibleAllocator FallibleAlloc;
  typedef nsTArrayInfallibleAllocator InfallibleAlloc;

public:
  typedef typename nsTArray_CopyChooser::Type     copy_type;
  typedef nsTArray_base            base_type;
  typedef typename base_type::size_type              size_type;
  typedef typename base_type::index_type             index_type;
  typedef E                                          elem_type;
  typedef nsTArray_Impl                    self_type;
  typedef nsTArrayElementTraits                   elem_traits;
  typedef nsTArray_SafeElementAtHelper safeelementat_helper_type;
  typedef mozilla::ArrayIterator>       iterator;
  typedef mozilla::ArrayIterator> const_iterator;
  typedef mozilla::ReverseIterator         reverse_iterator;
  typedef mozilla::ReverseIterator   const_reverse_iterator;

  using safeelementat_helper_type::SafeElementAt;
  using base_type::EmptyHdr;

  // A special value that is used to indicate an invalid or unknown index
  // into the array.
  static const index_type NoIndex = index_type(-1);

  using base_type::Length;

  //
  // Finalization method
  //

  ~nsTArray_Impl()
  {
    if (!base_type::IsEmpty()) {
      ClearAndRetainStorage();
    }
    // mHdr cleanup will be handled by base destructor
  }

  //
  // Initialization methods
  //

  nsTArray_Impl() {}

  // Initialize this array and pre-allocate some number of elements.
  explicit nsTArray_Impl(size_type aCapacity) { SetCapacity(aCapacity); }

  // Initialize this array with an r-value.
  // Allow different types of allocators, since the allocator doesn't matter.
  template
  explicit nsTArray_Impl(nsTArray_Impl&& aOther)
  {
    SwapElements(aOther);
  }

  // The array's copy-constructor performs a 'deep' copy of the given array.
  // @param aOther The array object to copy.
  //
  // It's very important that we declare this method as taking |const
  // self_type&| as opposed to taking |const nsTArray_Impl| for
  // an arbitrary OtherAlloc.
  //
  // If we don't declare a constructor taking |const self_type&|, C++ generates
  // a copy-constructor for this class which merely copies the object's
  // members, which is obviously wrong.
  //
  // You can pass an nsTArray_Impl to this method because
  // nsTArray_Impl can be cast to const nsTArray_Impl&.  So the
  // effect on the API is the same as if we'd declared this method as taking
  // |const nsTArray_Impl&|.
  explicit nsTArray_Impl(const self_type& aOther) { AppendElements(aOther); }

  explicit nsTArray_Impl(std::initializer_list aIL) { AppendElements(aIL.begin(), aIL.size()); }
  // Allow converting to a const array with a different kind of allocator,
  // Since the allocator doesn't matter for const arrays
  template
  operator const nsTArray_Impl&() const
  {
    return *reinterpret_cast*>(this);
  }
  // And we have to do this for our subclasses too
  operator const nsTArray&() const
  {
    return *reinterpret_cast*>(this);
  }
  operator const FallibleTArray&() const
  {
    return *reinterpret_cast*>(this);
  }

  // The array's assignment operator performs a 'deep' copy of the given
  // array.  It is optimized to reuse existing storage if possible.
  // @param aOther The array object to copy.
  self_type& operator=(const self_type& aOther)
  {
    if (this != &aOther) {
      ReplaceElementsAt(0, Length(), aOther.Elements(), aOther.Length());
    }
    return *this;
  }

  // The array's move assignment operator steals the underlying data from
  // the other array.
  // @param other  The array object to move from.
  self_type& operator=(self_type&& aOther)
  {
    if (this != &aOther) {
      Clear();
      SwapElements(aOther);
    }
    return *this;
  }

  // Return true if this array has the same length and the same
  // elements as |aOther|.
  template
  bool operator==(const nsTArray_Impl& aOther) const
  {
    size_type len = Length();
    if (len != aOther.Length()) {
      return false;
    }

    // XXX std::equal would be as fast or faster here
    for (index_type i = 0; i < len; ++i) {
      if (!(operator[](i) == aOther[i])) {
        return false;
      }
    }

    return true;
  }

  // Return true if this array does not have the same length and the same
  // elements as |aOther|.
  bool operator!=(const self_type& aOther) const { return !operator==(aOther); }

  template
  self_type& operator=(const nsTArray_Impl& aOther)
  {
    ReplaceElementsAt(0, Length(), aOther.Elements(), aOther.Length());
    return *this;
  }

  template
  self_type& operator=(nsTArray_Impl&& aOther)
  {
    Clear();
    SwapElements(aOther);
    return *this;
  }

  // @return The amount of memory used by this nsTArray_Impl, excluding
  // sizeof(*this). If you want to measure anything hanging off the array, you
  // must iterate over the elements and measure them individually; hence the
  // "Shallow" prefix.
  size_t ShallowSizeOfExcludingThis(mozilla::MallocSizeOf aMallocSizeOf) const
  {
    if (this->UsesAutoArrayBuffer() || Hdr() == EmptyHdr()) {
      return 0;
    }
    return aMallocSizeOf(this->Hdr());
  }

  // @return The amount of memory used by this nsTArray_Impl, including
  // sizeof(*this). If you want to measure anything hanging off the array, you
  // must iterate over the elements and measure them individually; hence the
  // "Shallow" prefix.
  size_t ShallowSizeOfIncludingThis(mozilla::MallocSizeOf aMallocSizeOf) const
  {
    return aMallocSizeOf(this) + ShallowSizeOfExcludingThis(aMallocSizeOf);
  }

  //
  // Accessor methods
  //

  // This method provides direct access to the array elements.
  // @return A pointer to the first element of the array.  If the array is
  // empty, then this pointer must not be dereferenced.
  elem_type* Elements() { return reinterpret_cast(Hdr() + 1); }

  // This method provides direct, readonly access to the array elements.
  // @return A pointer to the first element of the array.  If the array is
  // empty, then this pointer must not be dereferenced.
  const elem_type* Elements() const
  {
    return reinterpret_cast(Hdr() + 1);
  }

  // This method provides direct access to an element of the array. The given
  // index must be within the array bounds.
  // @param aIndex The index of an element in the array.
  // @return A reference to the i'th element of the array.
  elem_type& ElementAt(index_type aIndex)
  {
    if (MOZ_UNLIKELY(aIndex >= Length())) {
      InvalidArrayIndex_CRASH(aIndex, Length());
    }
    return Elements()[aIndex];
  }

  // This method provides direct, readonly access to an element of the array
  // The given index must be within the array bounds.
  // @param aIndex The index of an element in the array.
  // @return A const reference to the i'th element of the array.
  const elem_type& ElementAt(index_type aIndex) const
  {
    if (MOZ_UNLIKELY(aIndex >= Length())) {
      InvalidArrayIndex_CRASH(aIndex, Length());
    }
    return Elements()[aIndex];
  }

  // This method provides direct access to an element of the array in a bounds
  // safe manner. If the requested index is out of bounds the provided default
  // value is returned.
  // @param aIndex The index of an element in the array.
  // @param aDef   The value to return if the index is out of bounds.
  elem_type& SafeElementAt(index_type aIndex, elem_type& aDef)
  {
    return aIndex < Length() ? Elements()[aIndex] : aDef;
  }

  // This method provides direct access to an element of the array in a bounds
  // safe manner. If the requested index is out of bounds the provided default
  // value is returned.
  // @param aIndex The index of an element in the array.
  // @param aDef   The value to return if the index is out of bounds.
  const elem_type& SafeElementAt(index_type aIndex, const elem_type& aDef) const
  {
    return aIndex < Length() ? Elements()[aIndex] : aDef;
  }

  // Shorthand for ElementAt(aIndex)
  elem_type& operator[](index_type aIndex) { return ElementAt(aIndex); }

  // Shorthand for ElementAt(aIndex)
  const elem_type& operator[](index_type aIndex) const { return ElementAt(aIndex); }

  // Shorthand for ElementAt(length - 1)
  elem_type& LastElement() { return ElementAt(Length() - 1); }

  // Shorthand for ElementAt(length - 1)
  const elem_type& LastElement() const { return ElementAt(Length() - 1); }

  // Shorthand for SafeElementAt(length - 1, def)
  elem_type& SafeLastElement(elem_type& aDef)
  {
    return SafeElementAt(Length() - 1, aDef);
  }

  // Shorthand for SafeElementAt(length - 1, def)
  const elem_type& SafeLastElement(const elem_type& aDef) const
  {
    return SafeElementAt(Length() - 1, aDef);
  }

  // Methods for range-based for loops.
  iterator begin() { return iterator(*this, 0); }
  const_iterator begin() const { return const_iterator(*this, 0); }
  const_iterator cbegin() const { return begin(); }
  iterator end() { return iterator(*this, Length()); }
  const_iterator end() const { return const_iterator(*this, Length()); }
  const_iterator cend() const { return end(); }

  // Methods for reverse iterating.
  reverse_iterator rbegin() { return reverse_iterator(end()); }
  const_reverse_iterator rbegin() const { return const_reverse_iterator(end()); }
  const_reverse_iterator crbegin() const { return rbegin(); }
  reverse_iterator rend() { return reverse_iterator(begin()); }
  const_reverse_iterator rend() const { return const_reverse_iterator(begin()); }
  const_reverse_iterator crend() const { return rend(); }

  // Span integration

  operator mozilla::Span()
  {
    return mozilla::Span(Elements(), Length());
  }

  operator mozilla::Span() const
  {
    return mozilla::Span(Elements(), Length());
  }

  //
  // Search methods
  //

  // This method searches for the first element in this array that is equal
  // to the given element.
  // @param aItem  The item to search for.
  // @param aComp  The Comparator used to determine element equality.
  // @return       true if the element was found.
  template
  bool Contains(const Item& aItem, const Comparator& aComp) const
  {
    return ApplyIf(aItem, 0, aComp,
                   []() { return true; },
                   []() { return false; });
  }

  // Like Contains(), but assumes a sorted array.
  template
  bool ContainsSorted(const Item& aItem, const Comparator& aComp) const
  {
    return BinaryIndexOf(aItem, aComp) != NoIndex;
  }

  // This method searches for the first element in this array that is equal
  // to the given element.  This method assumes that 'operator==' is defined
  // for elem_type.
  // @param aItem  The item to search for.
  // @return       true if the element was found.
  template
  bool Contains(const Item& aItem) const
  {
    return Contains(aItem, nsDefaultComparator());
  }

  // Like Contains(), but assumes a sorted array.
  template
  bool ContainsSorted(const Item& aItem) const
  {
    return BinaryIndexOf(aItem) != NoIndex;
  }

  // This method searches for the offset of the first element in this
  // array that is equal to the given element.
  // @param aItem  The item to search for.
  // @param aStart The index to start from.
  // @param aComp  The Comparator used to determine element equality.
  // @return       The index of the found element or NoIndex if not found.
  template
  index_type IndexOf(const Item& aItem, index_type aStart,
                     const Comparator& aComp) const
  {
    ::detail::CompareWrapper comp(aComp);

    const elem_type* iter = Elements() + aStart;
    const elem_type* iend = Elements() + Length();
    for (; iter != iend; ++iter) {
      if (comp.Equals(*iter, aItem)) {
        return index_type(iter - Elements());
      }
    }
    return NoIndex;
  }

  // This method searches for the offset of the first element in this
  // array that is equal to the given element.  This method assumes
  // that 'operator==' is defined for elem_type.
  // @param aItem  The item to search for.
  // @param aStart The index to start from.
  // @return       The index of the found element or NoIndex if not found.
  template
  index_type IndexOf(const Item& aItem, index_type aStart = 0) const
  {
    return IndexOf(aItem, aStart, nsDefaultComparator());
  }

  // This method searches for the offset of the last element in this
  // array that is equal to the given element.
  // @param aItem  The item to search for.
  // @param aStart The index to start from.  If greater than or equal to the
  //               length of the array, then the entire array is searched.
  // @param aComp  The Comparator used to determine element equality.
  // @return       The index of the found element or NoIndex if not found.
  template
  index_type LastIndexOf(const Item& aItem, index_type aStart,
                         const Comparator& aComp) const
  {
    ::detail::CompareWrapper comp(aComp);

    size_type endOffset = aStart >= Length() ? Length() : aStart + 1;
    const elem_type* iend = Elements() - 1;
    const elem_type* iter = iend + endOffset;
    for (; iter != iend; --iter) {
      if (comp.Equals(*iter, aItem)) {
        return index_type(iter - Elements());
      }
    }
    return NoIndex;
  }

  // This method searches for the offset of the last element in this
  // array that is equal to the given element.  This method assumes
  // that 'operator==' is defined for elem_type.
  // @param aItem  The item to search for.
  // @param aStart The index to start from.  If greater than or equal to the
  //               length of the array, then the entire array is searched.
  // @return       The index of the found element or NoIndex if not found.
  template
  index_type LastIndexOf(const Item& aItem,
                         index_type aStart = NoIndex) const
  {
    return LastIndexOf(aItem, aStart, nsDefaultComparator());
  }

  // This method searches for the offset for the element in this array
  // that is equal to the given element. The array is assumed to be sorted.
  // If there is more than one equivalent element, there is no guarantee
  // on which one will be returned.
  // @param aItem  The item to search for.
  // @param aComp  The Comparator used.
  // @return       The index of the found element or NoIndex if not found.
  template
  index_type BinaryIndexOf(const Item& aItem, const Comparator& aComp) const
  {
    using mozilla::BinarySearchIf;
    ::detail::CompareWrapper comp(aComp);

    size_t index;
    bool found = BinarySearchIf(
      *this, 0, Length(),
      // Note: We pass the Compare() args here in reverse order and negate the
      // results for compatibility reasons. Some existing callers use Equals()
      // functions with first arguments which match aElement but not aItem, or
      // second arguments that match aItem but not aElement. To accommodate
      // those callers, we preserve the argument order of the older version of
      // this API. These callers, however, should be fixed, and this special
      // case removed.
      [&] (const elem_type& aElement) { return -comp.Compare(aElement, aItem); },
      &index);
    return found ? index : NoIndex;
  }

  // This method searches for the offset for the element in this array
  // that is equal to the given element. The array is assumed to be sorted.
  // This method assumes that 'operator==' and 'operator
  index_type BinaryIndexOf(const Item& aItem) const
  {
    return BinaryIndexOf(aItem, nsDefaultComparator());
  }

  //
  // Mutation methods
  //

  template
  typename ActualAlloc::ResultType Assign(
      const nsTArray_Impl& aOther)
  {
    return ActualAlloc::ConvertBoolToResultType(
      !!ReplaceElementsAt(0, Length(),
                                          aOther.Elements(), aOther.Length()));
  }

  template
  MOZ_MUST_USE
  bool Assign(const nsTArray_Impl& aOther,
              const mozilla::fallible_t&)
  {
    return Assign(aOther);
  }

  template
  void Assign(nsTArray_Impl&& aOther)
  {
    Clear();
    SwapElements(aOther);
  }

  // This method call the destructor on each element of the array, empties it,
  // but does not shrink the array's capacity.
  // See also SetLengthAndRetainStorage.
  // Make sure to call Compact() if needed to avoid keeping a huge array
  // around.
  void ClearAndRetainStorage()
  {
    if (base_type::mHdr == EmptyHdr()) {
      return;
    }

    DestructRange(0, Length());
    base_type::mHdr->mLength = 0;
  }

  // This method modifies the length of the array, but unlike SetLength
  // it doesn't deallocate/reallocate the current internal storage.
  // The new length MUST be shorter than or equal to the current capacity.
  // If the new length is larger than the existing length of the array,
  // then new elements will be constructed using elem_type's default
  // constructor.  If shorter, elements will be destructed and removed.
  // See also ClearAndRetainStorage.
  // @param aNewLen  The desired length of this array.
  void SetLengthAndRetainStorage(size_type aNewLen)
  {
    MOZ_ASSERT(aNewLen <= base_type::Capacity());
    size_type oldLen = Length();
    if (aNewLen > oldLen) {
      InsertElementsAt(oldLen, aNewLen - oldLen);
      return;
    }
    if (aNewLen < oldLen) {
      DestructRange(aNewLen, oldLen - aNewLen);
      base_type::mHdr->mLength = aNewLen;
    }
  }

  // This method replaces a range of elements in this array.
  // @param aStart    The starting index of the elements to replace.
  // @param aCount    The number of elements to replace.  This may be zero to
  //                  insert elements without removing any existing elements.
  // @param aArray    The values to copy into this array.  Must be non-null,
  //                  and these elements must not already exist in the array
  //                  being modified.
  // @param aArrayLen The number of values to copy into this array.
  // @return          A pointer to the new elements in the array, or null if
  //                  the operation failed due to insufficient memory.
protected:
  template
  elem_type* ReplaceElementsAt(index_type aStart, size_type aCount,
                               const Item* aArray, size_type aArrayLen);

public:

  template
  MOZ_MUST_USE
  elem_type* ReplaceElementsAt(index_type aStart, size_type aCount,
                               const Item* aArray, size_type aArrayLen,
                               const mozilla::fallible_t&)
  {
    return ReplaceElementsAt(aStart, aCount,
                                                  aArray, aArrayLen);
  }

  // A variation on the ReplaceElementsAt method defined above.
protected:
  template
  elem_type* ReplaceElementsAt(index_type aStart, size_type aCount,
                               const nsTArray& aArray)
  {
    return ReplaceElementsAt(
      aStart, aCount, aArray.Elements(), aArray.Length());
  }

  template
  elem_type* ReplaceElementsAt(index_type aStart,
                               size_type aCount,
                               mozilla::Span aSpan)
  {
    return ReplaceElementsAt(
      aStart, aCount, aSpan.Elements(), aSpan.Length());
  }

public:

  template
  MOZ_MUST_USE
  elem_type* ReplaceElementsAt(index_type aStart, size_type aCount,
                               const nsTArray& aArray,
                               const mozilla::fallible_t&)
  {
    return ReplaceElementsAt(aStart, aCount, aArray);
  }

  template
  MOZ_MUST_USE elem_type* ReplaceElementsAt(index_type aStart,
                                            size_type aCount,
                                            mozilla::Span aSpan,
                                            const mozilla::fallible_t&)
  {
    return ReplaceElementsAt(aStart, aCount, aSpan);
  }

  // A variation on the ReplaceElementsAt method defined above.
protected:
  template
  elem_type* ReplaceElementsAt(index_type aStart, size_type aCount,
                               const Item& aItem)
  {
    return ReplaceElementsAt(aStart, aCount, &aItem, 1);
  }
public:

  template
  MOZ_MUST_USE
  elem_type* ReplaceElementsAt(index_type aStart, size_type aCount,
                               const Item& aItem, const mozilla::fallible_t&)
  {
    return ReplaceElementsAt(aStart, aCount, aItem);
  }

  // A variation on the ReplaceElementsAt method defined above.
  template
  elem_type* ReplaceElementAt(index_type aIndex, const Item& aItem)
  {
    return ReplaceElementsAt(aIndex, 1, &aItem, 1);
  }

  // A variation on the ReplaceElementsAt method defined above.
protected:
  template
  elem_type* InsertElementsAt(index_type aIndex, const Item* aArray,
                              size_type aArrayLen)
  {
    return ReplaceElementsAt(aIndex, 0, aArray, aArrayLen);
  }
public:

  template
  MOZ_MUST_USE
  elem_type* InsertElementsAt(index_type aIndex, const Item* aArray,
                              size_type aArrayLen, const mozilla::fallible_t&)
  {
    return InsertElementsAt(aIndex, aArray, aArrayLen);
  }

  // A variation on the ReplaceElementsAt method defined above.
protected:
  template
  elem_type* InsertElementsAt(index_type aIndex,
                              const nsTArray_Impl& aArray)
  {
    return ReplaceElementsAt(
      aIndex, 0, aArray.Elements(), aArray.Length());
  }

  template
  elem_type* InsertElementsAt(index_type aIndex,
                              mozilla::Span aSpan)
  {
    return ReplaceElementsAt(
      aIndex, 0, aSpan.Elements(), aSpan.Length());
  }

public:

  template
  MOZ_MUST_USE
  elem_type* InsertElementsAt(index_type aIndex,
                              const nsTArray_Impl& aArray,
                              const mozilla::fallible_t&)
  {
    return InsertElementsAt(aIndex, aArray);
  }

  template
  MOZ_MUST_USE elem_type* InsertElementsAt(index_type aIndex,
                                           mozilla::Span aSpan,
                                           const mozilla::fallible_t&)
  {
    return InsertElementsAt(aIndex, aSpan);
  }

  // Insert a new element without copy-constructing. This is useful to avoid
  // temporaries.
  // @return A pointer to the newly inserted element, or null on OOM.
protected:
  template
  elem_type* InsertElementAt(index_type aIndex);

public:

  MOZ_MUST_USE
  elem_type* InsertElementAt(index_type aIndex, const mozilla::fallible_t&)
  {
    return InsertElementAt(aIndex);
  }

  // Insert a new element, move constructing if possible.
protected:
  template
  elem_type* InsertElementAt(index_type aIndex, Item&& aItem);

public:

  template
  MOZ_MUST_USE
  elem_type* InsertElementAt(index_type aIndex, Item&& aItem,
                             const mozilla::fallible_t&)
  {
    return InsertElementAt(aIndex,
                                                std::forward(aItem));
  }

  // Reconstruct the element at the given index, and return a pointer to the
  // reconstructed element.  This will destroy the existing element and
  // default-construct a new one, giving you a state much like what single-arg
  // InsertElementAt(), or no-arg AppendElement() does, but without changing the
  // length of the array.
  //
  // array[idx] = T()
  //
  // would accomplish the same thing as long as T has the appropriate moving
  // operator=, but some types don't for various reasons.
  elem_type* ReconstructElementAt(index_type aIndex)
  {
    elem_type* elem = &ElementAt(aIndex);
    elem_traits::Destruct(elem);
    elem_traits::Construct(elem);
    return elem;
  }

  // This method searches for the smallest index of an element that is strictly
  // greater than |aItem|. If |aItem| is inserted at this index, the array will
  // remain sorted and |aItem| would come after all elements that are equal to
  // it. If |aItem| is greater than or equal to all elements in the array, the
  // array length is returned.
  //
  // Note that consumers who want to know whether there are existing items equal
  // to |aItem| in the array can just check that the return value here is > 0
  // and indexing into the previous slot gives something equal to |aItem|.
  //
  //
  // @param aItem  The item to search for.
  // @param aComp  The Comparator used.
  // @return        The index of greatest element <= to |aItem|
  // @precondition The array is sorted
  template
  index_type IndexOfFirstElementGt(const Item& aItem,
                                   const Comparator& aComp) const
  {
    using mozilla::BinarySearchIf;
    ::detail::CompareWrapper comp(aComp);

    size_t index;
    BinarySearchIf(*this, 0, Length(),
                   [&] (const elem_type& aElement) { return comp.Compare(aElement, aItem) <= 0 ? 1 : -1; },
                   &index);
    return index;
  }

  // A variation on the IndexOfFirstElementGt method defined above.
  template
  index_type
  IndexOfFirstElementGt(const Item& aItem) const
  {
    return IndexOfFirstElementGt(aItem, nsDefaultComparator());
  }

  // Inserts |aItem| at such an index to guarantee that if the array
  // was previously sorted, it will remain sorted after this
  // insertion.
protected:
  template
  elem_type* InsertElementSorted(Item&& aItem, const Comparator& aComp)
  {
    index_type index = IndexOfFirstElementGt(aItem, aComp);
    return InsertElementAt(
      index, std::forward(aItem));
  }
public:

  template
  MOZ_MUST_USE
  elem_type* InsertElementSorted(Item&& aItem, const Comparator& aComp,
                                 const mozilla::fallible_t&)
  {
    return InsertElementSorted(
      std::forward(aItem), aComp);
  }

  // A variation on the InsertElementSorted method defined above.
protected:
  template
  elem_type* InsertElementSorted(Item&& aItem)
  {
    nsDefaultComparator comp;
    return InsertElementSorted(
      std::forward(aItem), comp);
  }
public:

  template
  MOZ_MUST_USE
  elem_type* InsertElementSorted(Item&& aItem, const mozilla::fallible_t&)
  {
    return InsertElementSorted(
      std::forward(aItem));
  }

  // This method appends elements to the end of this array.
  // @param aArray    The elements to append to this array.
  // @param aArrayLen The number of elements to append to this array.
  // @return          A pointer to the new elements in the array, or null if
  //                  the operation failed due to insufficient memory.
protected:
  template
  elem_type* AppendElements(const Item* aArray, size_type aArrayLen);

  template
  elem_type* AppendElements(mozilla::Span aSpan)
  {
    return AppendElements(aSpan.Elements(),
                                               aSpan.Length());
  }

  template
  elem_type* AppendElements(const mozilla::Array& aArray)
  {
    return AppendElements(&aArray[0], Length);
  }

public:

  template
  /* MOZ_MUST_USE */
  elem_type* AppendElements(const Item* aArray, size_type aArrayLen,
                            const mozilla::fallible_t&)
  {
    return AppendElements(aArray, aArrayLen);
  }

  template
  /* MOZ_MUST_USE */
  elem_type* AppendElements(mozilla::Span aSpan,
                            const mozilla::fallible_t&)
  {
    return AppendElements(aSpan.Elements(),
                                               aSpan.Length());
  }

  // A variation on the AppendElements method defined above.
protected:
  template
  elem_type* AppendElements(const nsTArray_Impl& aArray)
  {
    return AppendElements(aArray.Elements(), aArray.Length());
  }
public:

  template
  /* MOZ_MUST_USE */
  elem_type* AppendElements(const nsTArray_Impl& aArray,
                            const mozilla::fallible_t&)
  {
    return AppendElements(aArray);
  }

  // Move all elements from another array to the end of this array.
  // @return A pointer to the newly appended elements, or null on OOM.
protected:
  template
  elem_type* AppendElements(nsTArray_Impl&& aArray);

public:

  template
  /* MOZ_MUST_USE */
  elem_type* AppendElements(nsTArray_Impl&& aArray,
                            const mozilla::fallible_t&)
  {
    return AppendElements(std::move(aArray));
  }

  // Append a new element, move constructing if possible.
protected:
  template
  elem_type* AppendElement(Item&& aItem);

public:

  template
  /* MOZ_MUST_USE */
  elem_type* AppendElement(Item&& aItem,
                           const mozilla::fallible_t&)
  {
    return AppendElement(std::forward(aItem));
  }

  // Append new elements without copy-constructing. This is useful to avoid
  // temporaries.
  // @return A pointer to the newly appended elements, or null on OOM.
protected:
  template
  elem_type* AppendElements(size_type aCount) {
    if (!ActualAlloc::Successful(this->template ExtendCapacity(
          Length(), aCount, sizeof(elem_type)))) {
      return nullptr;
    }
    elem_type* elems = Elements() + Length();
    size_type i;
    for (i = 0; i < aCount; ++i) {
      elem_traits::Construct(elems + i);
    }
    this->IncrementLength(aCount);
    return elems;
  }
public:

  /* MOZ_MUST_USE */
  elem_type* AppendElements(size_type aCount,
                            const mozilla::fallible_t&)
  {
    return AppendElements(aCount);
  }

  // Append a new element without copy-constructing. This is useful to avoid
  // temporaries.
  // @return A pointer to the newly appended element, or null on OOM.
protected:
  template
  elem_type* AppendElement()
  {
    return AppendElements(1);
  }
public:

  /* MOZ_MUST_USE */
  elem_type* AppendElement(const mozilla::fallible_t&)
  {
    return AppendElement();
  }

  // This method removes a range of elements from this array.
  // @param aStart The starting index of the elements to remove.
  // @param aCount The number of elements to remove.
  void RemoveElementsAt(index_type aStart, size_type aCount);

private:
  // Remove a range of elements from this array, but do not check that
  // the range is in bounds.
  // @param aStart The starting index of the elements to remove.
  // @param aCount The number of elements to remove.
  void RemoveElementsAtUnsafe(index_type aStart, size_type aCount);

public:
  // A variation on the RemoveElementsAt method defined above.
  void RemoveElementAt(index_type aIndex) { RemoveElementsAt(aIndex, 1); }

  // A variation on the RemoveElementAt that removes the last element.
  void RemoveLastElement() { RemoveElementAt(Length() - 1); }

  // Removes the last element of the array and returns a copy of it.
  MOZ_MUST_USE
  elem_type PopLastElement()
  {
    elem_type elem = std::move(LastElement());
    RemoveLastElement();
    return elem;
  }

  // This method performs index-based removals from an array without preserving
  // the order of the array. This is useful if you are using the array as a
  // set-like data structure.
  //
  // These removals are efficient, as they move as few elements as possible. At
  // most N elements, where N is the number of removed elements, will have to
  // be relocated.
  //
  // ## Examples
  //
  // When removing an element from the end of the array, it can be removed in
  // place, by destroying it and decrementing the length.
  //
  // [ 1, 2, 3 ] => [ 1, 2 ]
  //         ^
  //
  // When removing any other single element, it is removed by swapping it with
  // the last element, and then decrementing the length as before.
  //
  // [ 1, 2, 3, 4, 5, 6 ]  => [ 1, 6, 3, 4, 5 ]
  //      ^
  //
  // This method also supports efficiently removing a range of elements. If they
  // are at the end, then they can all be removed like in the one element case.
  //
  // [ 1, 2, 3, 4, 5, 6 ] => [ 1, 2 ]
  //         ^--------^
  //
  // If more elements are removed than exist after the removed section, the
  // remaining elements will be shifted down like in a normal removal.
  //
  // [ 1, 2, 3, 4, 5, 6, 7, 8 ] => [ 1, 2, 7, 8 ]
  //         ^--------^
  //
  // And if fewer elements are removed than exist after the removed section,
  // elements will be moved from the end of the array to fill the vacated space.
  //
  // [ 1, 2, 3, 4, 5, 6, 7, 8 ] => [ 1, 7, 8, 4, 5, 6 ]
  //      ^--^
  //
  // @param aStart The starting index of the elements to remove. @param aCount
  // The number of elements to remove.
  void UnorderedRemoveElementsAt(index_type aStart, size_type aCount);

  // A variation on the UnorderedRemoveElementsAt method defined above to remove
  // a single element. This operation is sometimes called `SwapRemove`.
  //
  // This method is O(1), but does not preserve the order of the elements.
  void UnorderedRemoveElementAt(index_type aIndex) {
    UnorderedRemoveElementsAt(aIndex, 1);
  }

  void Clear() {
    ClearAndRetainStorage();
    Compact();
  }

  // This method removes elements based on the return value of the
  // callback function aPredicate. If the function returns true for
  // an element, the element is removed. aPredicate will be called
  // for each element in order. It is not safe to access the array
  // inside aPredicate.
  template
  void RemoveElementsBy(Predicate aPredicate);

  // This helper function combines IndexOf with RemoveElementAt to "search
  // and destroy" the first element that is equal to the given element.
  // @param aItem The item to search for.
  // @param aComp The Comparator used to determine element equality.
  // @return true if the element was found
  template
  bool RemoveElement(const Item& aItem, const Comparator& aComp)
  {
    index_type i = IndexOf(aItem, 0, aComp);
    if (i == NoIndex) {
      return false;
    }

    RemoveElementsAtUnsafe(i, 1);
    return true;
  }

  // A variation on the RemoveElement method defined above that assumes
  // that 'operator==' is defined for elem_type.
  template
  bool RemoveElement(const Item& aItem)
  {
    return RemoveElement(aItem, nsDefaultComparator());
  }

  // This helper function combines IndexOfFirstElementGt with
  // RemoveElementAt to "search and destroy" the last element that
  // is equal to the given element.
  // @param aItem The item to search for.
  // @param aComp The Comparator used to determine element equality.
  // @return true if the element was found
  template
  bool RemoveElementSorted(const Item& aItem, const Comparator& aComp)
  {
    index_type index = IndexOfFirstElementGt(aItem, aComp);
    if (index > 0 && aComp.Equals(ElementAt(index - 1), aItem)) {
      RemoveElementsAtUnsafe(index - 1, 1);
      return true;
    }
    return false;
  }

  // A variation on the RemoveElementSorted method defined above.
  template
  bool RemoveElementSorted(const Item& aItem)
  {
    return RemoveElementSorted(aItem, nsDefaultComparator());
  }

  // This method causes the elements contained in this array and the given
  // array to be swapped.
  template
  typename Alloc::ResultType SwapElements(nsTArray_Impl& aOther)
  {
    return Alloc::Result(this->template SwapArrayElements(
      aOther, sizeof(elem_type), MOZ_ALIGNOF(elem_type)));
  }

private:
  // Used by ApplyIf functions to invoke a callable that takes either:
  // - Nothing: F(void)
  // - Index only: F(size_t)
  // - Reference to element only: F(maybe-const elem_type&)
  // - Both index and reference: F(size_t, maybe-const elem_type&)
  // `elem_type` must be const when called from const method.
  template
  struct InvokeWithIndexAndOrReferenceHelper
  {
    static constexpr bool valid = false;
  };
  template
  struct InvokeWithIndexAndOrReferenceHelper
  {
    static constexpr bool valid = true;
    template
    static auto Invoke(F&& f, size_t, T&) { return f(); }
  };
  template
  struct InvokeWithIndexAndOrReferenceHelper
  {
    static constexpr bool valid = true;
    template
    static auto Invoke(F&& f, size_t i, T&) { return f(i); }
  };
  template
  struct InvokeWithIndexAndOrReferenceHelper
  {
    static constexpr bool valid = true;
    template
    static auto Invoke(F&& f, size_t, T& e) { return f(e); }
  };
  template
  struct InvokeWithIndexAndOrReferenceHelper
  {
    static constexpr bool valid = true;
    template
    static auto Invoke(F&& f, size_t, T& e) { return f(e); }
  };
  template
  struct InvokeWithIndexAndOrReferenceHelper
  {
    static constexpr bool valid = true;
    template
    static auto Invoke(F&& f, size_t i, T& e) { return f(i, e); }
  };
  template
  struct InvokeWithIndexAndOrReferenceHelper
  {
    static constexpr bool valid = true;
    template
    static auto Invoke(F&& f, size_t i, T& e) { return f(i, e); }
  };
  template
  static auto InvokeWithIndexAndOrReference(F&& f, size_t i, T& e)
  {
    using Invoker =
      InvokeWithIndexAndOrReferenceHelper<
        T,
        typename mozilla::FunctionTypeTraits::template ParameterType<0>,
        typename mozilla::FunctionTypeTraits::template ParameterType<1>>;
    static_assert(Invoker::valid,
                  "ApplyIf's Function parameters must match either: (void), "
                  "(size_t), (maybe-const elem_type&), or "
                  "(size_t, maybe-const elem_type&)");
    return Invoker::Invoke(std::forward(f), i, e);
  }

public:
  // 'Apply' family of methods.
  //
  // The advantages of using Apply methods with lambdas include:
  // - Safety of accessing elements from within the call, when the array cannot
  //   have been modified between the iteration and the subsequent access.
  // - Avoiding moot conversions: pointer->index during a search, followed by
  //   index->pointer after the search when accessing the element.
  // - Embedding your code into the algorithm, giving the compiler more chances
  //   to optimize.

  // Search for the first element comparing equal to aItem with the given
  // comparator (`==` by default).
  // If such an element exists, return the result of evaluating either:
  // - `aFunction()`
  // - `aFunction(index_type)`
  // - `aFunction(maybe-const? elem_type&)`
  // - `aFunction(index_type, maybe-const? elem_type&)`
  // (`aFunction` must have one of the above signatures with these exact types,
  //  including references; implicit conversions or generic types not allowed.
  //  If `this` array is const, the referenced `elem_type` must be const too;
  //  otherwise it may be either const or non-const.)
  // But if the element is not found, return the result of evaluating
  // `aFunctionElse()`.
  template
  auto ApplyIf(const Item& aItem, index_type aStart,
               const Comparator& aComp,
               Function&& aFunction, FunctionElse&& aFunctionElse) const
  {
    static_assert(
      mozilla::IsSame<
        typename mozilla::FunctionTypeTraits::ReturnType,
        typename mozilla::FunctionTypeTraits::ReturnType>::value,
      "ApplyIf's `Function` and `FunctionElse` must return the same type.");

    ::detail::CompareWrapper comp(aComp);

    const elem_type* const elements = Elements();
    const elem_type* const iend = elements + Length();
    for (const elem_type* iter = elements + aStart; iter != iend; ++iter) {
      if (comp.Equals(*iter, aItem)) {
        return InvokeWithIndexAndOrReference(
                 std::forward(aFunction), iter - elements, *iter);
      }
    }
    return aFunctionElse();
  }
  template
  auto ApplyIf(const Item& aItem, index_type aStart,
               const Comparator& aComp,
               Function&& aFunction, FunctionElse&& aFunctionElse)
  {
    static_assert(
      mozilla::IsSame<
        typename mozilla::FunctionTypeTraits::ReturnType,
        typename mozilla::FunctionTypeTraits::ReturnType>::value,
      "ApplyIf's `Function` and `FunctionElse` must return the same type.");

    ::detail::CompareWrapper comp(aComp);

    elem_type* const elements = Elements();
    elem_type* const iend = elements + Length();
    for (elem_type* iter = elements + aStart; iter != iend; ++iter) {
      if (comp.Equals(*iter, aItem)) {
        return InvokeWithIndexAndOrReference(
                 std::forward(aFunction), iter - elements, *iter);
      }
    }
    return aFunctionElse();
  }
  template
  auto ApplyIf(const Item& aItem, index_type aStart,
               Function&& aFunction, FunctionElse&& aFunctionElse) const
  {
    return ApplyIf(aItem,
                   aStart,
                   nsDefaultComparator(),
                   std::forward(aFunction),
                   std::forward(aFunctionElse));
  }
  template
  auto ApplyIf(const Item& aItem, index_type aStart,
               Function&& aFunction, FunctionElse&& aFunctionElse)
  {
    return ApplyIf(aItem,
                   aStart,
                   nsDefaultComparator(),
                   std::forward(aFunction),
                   std::forward(aFunctionElse));
  }
  template
  auto ApplyIf(const Item& aItem,
               Function&& aFunction, FunctionElse&& aFunctionElse) const
  {
    return ApplyIf(aItem,
                   0,
                   std::forward(aFunction),
                   std::forward(aFunctionElse));
  }
  template
  auto ApplyIf(const Item& aItem,
               Function&& aFunction, FunctionElse&& aFunctionElse)
  {
    return ApplyIf(aItem,
                   0,
                   std::forward(aFunction),
                   std::forward(aFunctionElse));
  }

  //
  // Allocation
  //

  // This method may increase the capacity of this array object to the
  // specified amount.  This method may be called in advance of several
  // AppendElement operations to minimize heap re-allocations.  This method
  // will not reduce the number of elements in this array.
  // @param aCapacity The desired capacity of this array.
  // @return True if the operation succeeded; false if we ran out of memory
protected:
  template
  typename ActualAlloc::ResultType SetCapacity(size_type aCapacity)
  {
    return ActualAlloc::Result(this->template EnsureCapacity(
      aCapacity, sizeof(elem_type)));
  }
public:

  MOZ_MUST_USE
  bool SetCapacity(size_type aCapacity, const mozilla::fallible_t&)
  {
    return SetCapacity(aCapacity);
  }

  // This method modifies the length of the array.  If the new length is
  // larger than the existing length of the array, then new elements will be
  // constructed using elem_type's default constructor.  Otherwise, this call
  // removes elements from the array (see also RemoveElementsAt).
  // @param aNewLen The desired length of this array.
  // @return True if the operation succeeded; false otherwise.
  // See also TruncateLength if the new length is guaranteed to be smaller than
  // the old.
protected:
  template
  typename ActualAlloc::ResultType SetLength(size_type aNewLen)
  {
    size_type oldLen = Length();
    if (aNewLen > oldLen) {
      return ActualAlloc::ConvertBoolToResultType(
        InsertElementsAt(oldLen, aNewLen - oldLen) != nullptr);
    }

    TruncateLength(aNewLen);
    return ActualAlloc::ConvertBoolToResultType(true);
  }
public:

  MOZ_MUST_USE
  bool SetLength(size_type aNewLen, const mozilla::fallible_t&)
  {
    return SetLength(aNewLen);
  }

  // This method modifies the length of the array, but may only be
  // called when the new length is shorter than the old.  It can
  // therefore be called when elem_type has no default constructor,
  // unlike SetLength.  It removes elements from the array (see also
  // RemoveElementsAt).
  // @param aNewLen The desired length of this array.
  void TruncateLength(size_type aNewLen)
  {
    size_type oldLen = Length();
    MOZ_ASSERT(aNewLen <= oldLen,
               "caller should use SetLength instead");
    RemoveElementsAt(aNewLen, oldLen - aNewLen);
  }

  // This method ensures that the array has length at least the given
  // length.  If the current length is shorter than the given length,
  // then new elements will be constructed using elem_type's default
  // constructor.
  // @param aMinLen The desired minimum length of this array.
  // @return True if the operation succeeded; false otherwise.
protected:
  template
  typename ActualAlloc::ResultType EnsureLengthAtLeast(size_type aMinLen)
  {
    size_type oldLen = Length();
    if (aMinLen > oldLen) {
      return ActualAlloc::ConvertBoolToResultType(
        !!InsertElementsAt(oldLen, aMinLen - oldLen));
    }
    return ActualAlloc::ConvertBoolToResultType(true);
  }
public:

  MOZ_MUST_USE
  bool EnsureLengthAtLeast(size_type aMinLen, const mozilla::fallible_t&)
  {
    return EnsureLengthAtLeast(aMinLen);
  }

  // This method inserts elements into the array, constructing
  // them using elem_type's default constructor.
  // @param aIndex the place to insert the new elements. This must be no
  //               greater than the current length of the array.
  // @param aCount the number of elements to insert
protected:
  template
  elem_type* InsertElementsAt(index_type aIndex, size_type aCount)
  {
    if (!base_type::template InsertSlotsAt(aIndex, aCount,
                                                        sizeof(elem_type),
                                                        MOZ_ALIGNOF(elem_type))) {
      return nullptr;
    }

    // Initialize the extra array elements
    elem_type* iter = Elements() + aIndex;
    elem_type* iend = iter + aCount;
    for (; iter != iend; ++iter) {
      elem_traits::Construct(iter);
    }

    return Elements() + aIndex;
  }
public:

  MOZ_MUST_USE
  elem_type* InsertElementsAt(index_type aIndex, size_type aCount,
                              const mozilla::fallible_t&)
  {
    return InsertElementsAt(aIndex, aCount);
  }

  // This method inserts elements into the array, constructing them
  // elem_type's copy constructor (or whatever one-arg constructor
  // happens to match the Item type).
  // @param aIndex the place to insert the new elements. This must be no
  //               greater than the current length of the array.
  // @param aCount the number of elements to insert.
  // @param aItem the value to use when constructing the new elements.
protected:
  template
  elem_type* InsertElementsAt(index_type aIndex, size_type aCount,
                              const Item& aItem);

public:

  template
  MOZ_MUST_USE
  elem_type* InsertElementsAt(index_type aIndex, size_type aCount,
                              const Item& aItem, const mozilla::fallible_t&)
  {
    return InsertElementsAt(aIndex, aCount, aItem);
  }

  // This method may be called to minimize the memory used by this array.
  void Compact()
  {
    ShrinkCapacity(sizeof(elem_type), MOZ_ALIGNOF(elem_type));
  }

  //
  // Sorting
  //

  // This function is meant to be used with the NS_QuickSort function.  It
  // maps the callback API expected by NS_QuickSort to the Comparator API
  // used by nsTArray_Impl.  See nsTArray_Impl::Sort.
  template
  static int Compare(const void* aE1, const void* aE2, void* aData)
  {
    const Comparator* c = reinterpret_cast(aData);
    const elem_type* a = static_cast(aE1);
    const elem_type* b = static_cast(aE2);
    return c->Compare(*a, *b);
  }

  // This method sorts the elements of the array.  It uses the LessThan
  // method defined on the given Comparator object to collate elements.
  // @param aComp The Comparator used to collate elements.
  template
  void Sort(const Comparator& aComp)
  {
    ::detail::CompareWrapper comp(aComp);

    NS_QuickSort(Elements(), Length(), sizeof(elem_type),
                 Compare, &comp);
  }

  // A variation on the Sort method defined above that assumes that
  // 'operator()); }

  // This method reverses the array in place.
  void Reverse()
  {
    elem_type* elements = Elements();
    const size_type len = Length();
    for (index_type i = 0, iend = len / 2; i < iend; ++i) {
      mozilla::Swap(elements[i], elements[len - i - 1]);
    }
  }

protected:
  using base_type::Hdr;
  using base_type::ShrinkCapacity;

  // This method invokes elem_type's destructor on a range of elements.
  // @param aStart The index of the first element to destroy.
  // @param aCount The number of elements to destroy.
  void DestructRange(index_type aStart, size_type aCount)
  {
    elem_type* iter = Elements() + aStart;
    elem_type *iend = iter + aCount;
    for (; iter != iend; ++iter) {
      elem_traits::Destruct(iter);
    }
  }

  // This method invokes elem_type's copy-constructor on a range of elements.
  // @param aStart  The index of the first element to construct.
  // @param aCount  The number of elements to construct.
  // @param aValues The array of elements to copy.
  template
  void AssignRange(index_type aStart, size_type aCount, const Item* aValues)
  {
    AssignRangeAlgorithm::value,
                         mozilla::IsSame::value>
                         ::implementation(Elements(), aStart, aCount, aValues);
  }
};

template
template
auto
nsTArray_Impl::ReplaceElementsAt(index_type aStart, size_type aCount,
                                           const Item* aArray, size_type aArrayLen) -> elem_type*
{
  if (MOZ_UNLIKELY(aStart > Length())) {
    InvalidArrayIndex_CRASH(aStart, Length());
  }

  // Adjust memory allocation up-front to catch errors.
  if (!ActualAlloc::Successful(this->template EnsureCapacity(
        Length() + aArrayLen - aCount, sizeof(elem_type)))) {
    return nullptr;
  }
  DestructRange(aStart, aCount);
  this->template ShiftData(aStart, aCount, aArrayLen,
                                        sizeof(elem_type),
                                        MOZ_ALIGNOF(elem_type));
  AssignRange(aStart, aArrayLen, aArray);
  return Elements() + aStart;
}

template
void
nsTArray_Impl::RemoveElementsAt(index_type aStart, size_type aCount)
{
  MOZ_ASSERT(aCount == 0 || aStart < Length(), "Invalid aStart index");

  mozilla::CheckedInt rangeEnd = aStart;
  rangeEnd += aCount;

  if (MOZ_UNLIKELY(!rangeEnd.isValid() || rangeEnd.value() > Length())) {
    InvalidArrayIndex_CRASH(aStart, Length());
  }

  RemoveElementsAtUnsafe(aStart, aCount);
}

template
void
nsTArray_Impl::RemoveElementsAtUnsafe(index_type aStart, size_type aCount)
{
  DestructRange(aStart, aCount);
  this->template ShiftData(aStart, aCount, 0,
                                            sizeof(elem_type),
                                            MOZ_ALIGNOF(elem_type));
}

template
void
nsTArray_Impl::UnorderedRemoveElementsAt(index_type aStart, size_type aCount)
{
  MOZ_ASSERT(aCount == 0 || aStart < Length(), "Invalid aStart index");

  mozilla::CheckedInt rangeEnd = aStart;
  rangeEnd += aCount;

  if (MOZ_UNLIKELY(!rangeEnd.isValid() || rangeEnd.value() > Length())) {
    InvalidArrayIndex_CRASH(aStart, Length());
  }

  // Destroy the elements which are being removed, and then swap elements in to
  // replace them from the end. See the docs on the declaration of this
  // function.
  DestructRange(aStart, aCount);
  this->template SwapFromEnd(aStart, aCount,
                                              sizeof(elem_type),
                                              MOZ_ALIGNOF(elem_type));
}

template
template
void
nsTArray_Impl::RemoveElementsBy(Predicate aPredicate)
{
  if (base_type::mHdr == EmptyHdr()) {
    return;
  }

  index_type j = 0;
  index_type len = Length();
  for (index_type i = 0; i < len; ++i) {
    if (aPredicate(Elements()[i])) {
      elem_traits::Destruct(Elements() + i);
    } else {
      if (j < i) {
        copy_type::MoveNonOverlappingRegion(Elements() + j, Elements() + i,
                                            1, sizeof(elem_type));
      }
      ++j;
    }
  }
  base_type::mHdr->mLength = j;
}

template
template
auto
nsTArray_Impl::InsertElementsAt(index_type aIndex, size_type aCount,
                                          const Item& aItem) -> elem_type*
{
  if (!base_type::template InsertSlotsAt(aIndex, aCount,
                                                      sizeof(elem_type),
                                                      MOZ_ALIGNOF(elem_type))) {
    return nullptr;
  }

  // Initialize the extra array elements
  elem_type* iter = Elements() + aIndex;
  elem_type* iend = iter + aCount;
  for (; iter != iend; ++iter) {
    elem_traits::Construct(iter, aItem);
  }

  return Elements() + aIndex;
}

template
template
auto
nsTArray_Impl::InsertElementAt(index_type aIndex) -> elem_type*
{
  if (MOZ_UNLIKELY(aIndex > Length())) {
    InvalidArrayIndex_CRASH(aIndex, Length());
  }

  // Length() + 1 is guaranteed to not overflow, so EnsureCapacity is OK.
  if (!ActualAlloc::Successful(this->template EnsureCapacity(
        Length() + 1, sizeof(elem_type)))) {
    return nullptr;
  }
  this->template ShiftData(aIndex, 0, 1, sizeof(elem_type),
                                        MOZ_ALIGNOF(elem_type));
  elem_type* elem = Elements() + aIndex;
  elem_traits::Construct(elem);
  return elem;
}

template
template
auto
nsTArray_Impl::InsertElementAt(index_type aIndex, Item&& aItem) -> elem_type*
{
  if (MOZ_UNLIKELY(aIndex > Length())) {
    InvalidArrayIndex_CRASH(aIndex, Length());
  }

  // Length() + 1 is guaranteed to not overflow, so EnsureCapacity is OK.
  if (!ActualAlloc::Successful(this->template EnsureCapacity(
         Length() + 1, sizeof(elem_type)))) {
    return nullptr;
  }
  this->template ShiftData(aIndex, 0, 1, sizeof(elem_type),
                                        MOZ_ALIGNOF(elem_type));
  elem_type* elem = Elements() + aIndex;
  elem_traits::Construct(elem, std::forward(aItem));
  return elem;
}

template
template
auto
nsTArray_Impl::AppendElements(const Item* aArray, size_type aArrayLen) -> elem_type*
{
  if (!ActualAlloc::Successful(this->template ExtendCapacity(
        Length(), aArrayLen, sizeof(elem_type)))) {
    return nullptr;
  }
  index_type len = Length();
  AssignRange(len, aArrayLen, aArray);
  this->IncrementLength(aArrayLen);
  return Elements() + len;
}

template
template
auto
nsTArray_Impl::AppendElements(nsTArray_Impl&& aArray) -> elem_type*
{
  MOZ_ASSERT(&aArray != this, "argument must be different aArray");
  if (Length() == 0) {
    SwapElements(aArray);
    return Elements();
  }

  index_type len = Length();
  index_type otherLen = aArray.Length();
  if (!Alloc::Successful(this->template ExtendCapacity(
        len, otherLen, sizeof(elem_type)))) {
    return nullptr;
  }
  copy_type::MoveNonOverlappingRegion(Elements() + len, aArray.Elements(), otherLen,
                                      sizeof(elem_type));
  this->IncrementLength(otherLen);
  aArray.template ShiftData(0, otherLen, 0, sizeof(elem_type),
                                   MOZ_ALIGNOF(elem_type));
  return Elements() + len;
}

template
template
auto
nsTArray_Impl::AppendElement(Item&& aItem) -> elem_type*
{
  // Length() + 1 is guaranteed to not overflow, so EnsureCapacity is OK.
  if (!ActualAlloc::Successful(this->template EnsureCapacity(
         Length() + 1, sizeof(elem_type)))) {
    return nullptr;
  }
  elem_type* elem = Elements() + Length();
  elem_traits::Construct(elem, std::forward(aItem));
  this->mHdr->mLength += 1;
  return elem;
}

template
inline void
ImplCycleCollectionUnlink(nsTArray_Impl& aField)
{
  aField.Clear();
}

template
inline void
ImplCycleCollectionTraverse(nsCycleCollectionTraversalCallback& aCallback,
                            nsTArray_Impl& aField,
                            const char* aName,
                            uint32_t aFlags = 0)
{
  aFlags |= CycleCollectionEdgeNameArrayFlag;
  size_t length = aField.Length();
  for (size_t i = 0; i < length; ++i) {
    ImplCycleCollectionTraverse(aCallback, aField[i], aName, aFlags);
  }
}

//
// nsTArray is an infallible vector class.  See the comment at the top of this
// file for more details.
//
template
class nsTArray : public nsTArray_Impl
{
public:
  typedef nsTArray_Impl base_type;
  typedef nsTArray                                   self_type;
  typedef typename base_type::size_type                 size_type;

  nsTArray() {}
  explicit nsTArray(size_type aCapacity) : base_type(aCapacity) {}
  explicit nsTArray(const nsTArray& aOther) : base_type(aOther) {}
  MOZ_IMPLICIT nsTArray(nsTArray&& aOther) : base_type(std::move(aOther)) {}
  MOZ_IMPLICIT nsTArray(std::initializer_list aIL) : base_type(aIL) {}

  template
  explicit nsTArray(const nsTArray_Impl& aOther)
    : base_type(aOther)
  {
  }
  template
  MOZ_IMPLICIT nsTArray(nsTArray_Impl&& aOther)
    : base_type(std::move(aOther))
  {
  }

  self_type& operator=(const self_type& aOther)
  {
    base_type::operator=(aOther);
    return *this;
  }
  template
  self_type& operator=(const nsTArray_Impl& aOther)
  {
    base_type::operator=(aOther);
    return *this;
  }
  self_type& operator=(self_type&& aOther)
  {
    base_type::operator=(std::move(aOther));
    return *this;
  }
  template
  self_type& operator=(nsTArray_Impl&& aOther)
  {
    base_type::operator=(std::move(aOther));
    return *this;
  }

  using base_type::AppendElement;
  using base_type::AppendElements;
  using base_type::EnsureLengthAtLeast;
  using base_type::InsertElementAt;
  using base_type::InsertElementsAt;
  using base_type::InsertElementSorted;
  using base_type::ReplaceElementsAt;
  using base_type::SetCapacity;
  using base_type::SetLength;
};

//
// FallibleTArray is a fallible vector class.
//
template
class FallibleTArray : public nsTArray_Impl
{
public:
  typedef nsTArray_Impl   base_type;
  typedef FallibleTArray                             self_type;
  typedef typename base_type::size_type                 size_type;

  FallibleTArray() {}
  explicit FallibleTArray(size_type aCapacity) : base_type(aCapacity) {}
  explicit FallibleTArray(const FallibleTArray& aOther) : base_type(aOther) {}
  FallibleTArray(FallibleTArray&& aOther)
    : base_type(std::move(aOther))
  {
  }

  template
  explicit FallibleTArray(const nsTArray_Impl& aOther)
    : base_type(aOther)
  {
  }
  template
  explicit FallibleTArray(nsTArray_Impl&& aOther)
    : base_type(std::move(aOther))
  {
  }

  self_type& operator=(const self_type& aOther)
  {
    base_type::operator=(aOther);
    return *this;
  }
  template
  self_type& operator=(const nsTArray_Impl& aOther)
  {
    base_type::operator=(aOther);
    return *this;
  }
  self_type& operator=(self_type&& aOther)
  {
    base_type::operator=(std::move(aOther));
    return *this;
  }
  template
  self_type& operator=(nsTArray_Impl&& aOther)
  {
    base_type::operator=(std::move(aOther));
    return *this;
  }
};

//
// AutoTArray is like nsTArray, but with N elements of inline storage.
// Storing more than N elements is fine, but it will cause a heap allocation.
//
template
class MOZ_NON_MEMMOVABLE AutoTArray : public nsTArray
{
  static_assert(N != 0, "AutoTArray should be specialized");
public:
  typedef AutoTArray self_type;
  typedef nsTArray base_type;
  typedef typename base_type::Header Header;
  typedef typename base_type::elem_type elem_type;

  AutoTArray()
    : mAlign()
  {
    Init();
  }

  AutoTArray(const self_type& aOther)
    : nsTArray()
  {
    Init();
    this->AppendElements(aOther);
  }

  AutoTArray(self_type&& aOther)
    : nsTArray()
  {
    Init();
    this->SwapElements(aOther);
  }

  explicit AutoTArray(const base_type& aOther)
    : mAlign()
  {
    Init();
    this->AppendElements(aOther);
  }

  explicit AutoTArray(base_type&& aOther)
    : mAlign()
  {
    Init();
    this->SwapElements(aOther);
  }

  template
  explicit AutoTArray(nsTArray_Impl&& aOther)
  {
    Init();
    this->SwapElements(aOther);
  }

  MOZ_IMPLICIT AutoTArray(std::initializer_list aIL)
    : mAlign()
  {
    Init();
    this->AppendElements(aIL.begin(), aIL.size());
  }

  self_type& operator=(const self_type& aOther)
  {
    base_type::operator=(aOther);
    return *this;
  }

  self_type& operator=(self_type&& aOther)
  {
    base_type::operator=(std::move(aOther));
    return *this;
  }

  template
  self_type& operator=(const nsTArray_Impl& aOther)
  {
    base_type::operator=(aOther);
    return *this;
  }

private:
  // nsTArray_base casts itself as an nsAutoArrayBase in order to get a pointer
  // to mAutoBuf.
  template
  friend class nsTArray_base;

  void Init()
  {
    static_assert(MOZ_ALIGNOF(elem_type) <= 8,
                  "can't handle alignments greater than 8, "
                  "see nsTArray_base::UsesAutoArrayBuffer()");
    // Temporary work around for VS2012 RC compiler crash
    Header** phdr = base_type::PtrToHdr();
    *phdr = reinterpret_cast(&mAutoBuf);
    (*phdr)->mLength = 0;
    (*phdr)->mCapacity = N;
    (*phdr)->mIsAutoArray = 1;

    MOZ_ASSERT(base_type::GetAutoArrayBuffer(MOZ_ALIGNOF(elem_type)) ==
               reinterpret_cast(&mAutoBuf),
               "GetAutoArrayBuffer needs to be fixed");
  }

  // Declare mAutoBuf aligned to the maximum of the header's alignment and
  // elem_type's alignment.  We need to use a union rather than
  // MOZ_ALIGNED_DECL because GCC is picky about what goes into
  // __attribute__((aligned(foo))).
  union
  {
    char mAutoBuf[sizeof(nsTArrayHeader) + N * sizeof(elem_type)];
    // Do the max operation inline to ensure that it is a compile-time constant.
    mozilla::AlignedElem MOZ_ALIGNOF(elem_type)) ?
                         MOZ_ALIGNOF(Header) : MOZ_ALIGNOF(elem_type)> mAlign;
  };
};

//
// Specialization of AutoTArray for the case where N == 0.
// AutoTArray behaves exactly like nsTArray, but without this
// specialization, it stores a useless inline header.
//
// We do have many AutoTArray objects in memory: about 2,000 per tab as
// of May 2014. These are typically not explicitly AutoTArray but rather
// AutoTArray for some value N depending on template parameters, in
// generic code.
//
// For that reason, we optimize this case with the below partial specialization,
// which ensures that AutoTArray is just like nsTArray, without any
// inline header overhead.
//
template
class AutoTArray : public nsTArray
{
};

template
struct nsTArray_CopyChooser>
{
  typedef nsTArray_CopyWithConstructors> Type;
};

// Span integration
namespace mozilla {

template
Span
MakeSpan(nsTArray_Impl& aTArray)
{
  return aTArray;
}

template
Span
MakeSpan(const nsTArray_Impl& aTArray)
{
  return aTArray;
}

} // namespace mozilla

// Assert that AutoTArray doesn't have any extra padding inside.
//
// It's important that the data stored in this auto array takes up a multiple of
// 8 bytes; e.g. AutoTArray wouldn't work.  Since AutoTArray
// contains a pointer, its size must be a multiple of alignof(void*).  (This is
// because any type may be placed into an array, and there's no padding between
// elements of an array.)  The compiler pads the end of the structure to
// enforce this rule.
//
// If we used AutoTArray below, this assertion would fail on a
// 64-bit system, where the compiler inserts 4 bytes of padding at the end of
// the auto array to make its size a multiple of alignof(void*) == 8 bytes.

static_assert(sizeof(AutoTArray) ==
              sizeof(void*) + sizeof(nsTArrayHeader) + sizeof(uint32_t) * 2,
              "AutoTArray shouldn't contain any extra padding, "
              "see the comment");

// Definitions of nsTArray_Impl methods
#include "nsTArray-inl.h"

#endif  // nsTArray_h__
