/* -*- Mode: C++; tab-width: 2; indent-tabs-mode: nil; c-basic-offset: 2 -*- */
/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this file,
 * You can obtain one at http://mozilla.org/MPL/2.0/.
 */

#ifndef TestBindingHeader_h
#define TestBindingHeader_h

#include "mozilla/dom/BindingUtils.h"
#include "mozilla/dom/Date.h"
#include "mozilla/dom/MozMap.h"
#include "mozilla/dom/TypedArray.h"
#include "mozilla/dom/UnionTypes.h"
#include "mozilla/ErrorResult.h"
#include "nsCOMPtr.h"
#include "nsGenericHTMLElement.h"
#include "nsWrapperCache.h"

// Forward declare this before we include TestCodeGenBinding.h, because that header relies on including
// this one for it, for ParentDict. Hopefully it won't begin to rely on it in more fundamental ways.
namespace mozilla {
namespace dom {
class TestExternalInterface;
} // namespace dom
} // namespace mozilla

// We don't export TestCodeGenBinding.h, but it's right in our parent dir.
#include "../TestCodeGenBinding.h"

extern bool TestFuncControlledMember(JSContext*, JSObject*);

namespace mozilla {
namespace dom {

// IID for nsRenamedInterface
#define NS_RENAMED_INTERFACE_IID \
{ 0xd4b19ef3, 0xe68b, 0x4e3f, \
 { 0x94, 0xbc, 0xc9, 0xde, 0x3a, 0x69, 0xb0, 0xe8 } }

class nsRenamedInterface : public nsISupports,
                           public nsWrapperCache
{
public:
  NS_DECLARE_STATIC_IID_ACCESSOR(NS_RENAMED_INTERFACE_IID)
  NS_DECL_ISUPPORTS

  // We need a GetParentObject to make binding codegen happy
  virtual nsISupports* GetParentObject();
};

NS_DEFINE_STATIC_IID_ACCESSOR(nsRenamedInterface, NS_RENAMED_INTERFACE_IID)

// IID for the IndirectlyImplementedInterface
#define NS_INDIRECTLY_IMPLEMENTED_INTERFACE_IID \
{ 0xfed55b69, 0x7012, 0x4849, \
 { 0xaf, 0x56, 0x4b, 0xa9, 0xee, 0x41, 0x30, 0x89 } }

class IndirectlyImplementedInterface : public nsISupports,
                                       public nsWrapperCache
{
public:
  NS_DECLARE_STATIC_IID_ACCESSOR(NS_INDIRECTLY_IMPLEMENTED_INTERFACE_IID)
  NS_DECL_ISUPPORTS

  // We need a GetParentObject to make binding codegen happy
  virtual nsISupports* GetParentObject();

  bool IndirectlyImplementedProperty();
  void IndirectlyImplementedProperty(bool);
  void IndirectlyImplementedMethod();
};

NS_DEFINE_STATIC_IID_ACCESSOR(IndirectlyImplementedInterface, NS_INDIRECTLY_IMPLEMENTED_INTERFACE_IID)

// IID for the TestExternalInterface
#define NS_TEST_EXTERNAL_INTERFACE_IID \
{ 0xd5ba0c99, 0x9b1d, 0x4e71, \
 { 0x8a, 0x94, 0x56, 0x38, 0x6c, 0xa3, 0xda, 0x3d } }
class TestExternalInterface : public nsISupports
{
public:
  NS_DECLARE_STATIC_IID_ACCESSOR(NS_TEST_EXTERNAL_INTERFACE_IID)
  NS_DECL_ISUPPORTS
};

NS_DEFINE_STATIC_IID_ACCESSOR(TestExternalInterface, NS_TEST_EXTERNAL_INTERFACE_IID)

class TestNonWrapperCacheInterface : public nsISupports
{
public:
  NS_DECL_ISUPPORTS

  virtual JSObject* WrapObject(JSContext* cx);
};

class OnlyForUseInConstructor : public nsISupports,
                                public nsWrapperCache
{
public:
  NS_DECL_ISUPPORTS
  // We need a GetParentObject to make binding codegen happy
  virtual nsISupports* GetParentObject();
};

class TestInterface : public nsISupports,
                      public nsWrapperCache
{
public:
  NS_DECL_ISUPPORTS

  // We need a GetParentObject to make binding codegen happy
  virtual nsISupports* GetParentObject();

  // And now our actual WebIDL API
  // Constructors
  static
  already_AddRefed
    Constructor(const GlobalObject&, ErrorResult&);
  static
  already_AddRefed
    Constructor(const GlobalObject&, const nsAString&, ErrorResult&);
  static
  already_AddRefed
    Constructor(const GlobalObject&, uint32_t, const Nullable&,
                ErrorResult&);
  static
  already_AddRefed
    Constructor(const GlobalObject&, TestInterface*, ErrorResult&);
  static
  already_AddRefed
    Constructor(const GlobalObject&, uint32_t, IndirectlyImplementedInterface&, ErrorResult&);

  static
  already_AddRefed
    Constructor(const GlobalObject&, Date&, ErrorResult&);
  /*  static
  already_AddRefed
    Constructor(const GlobalObject&, uint32_t, uint32_t,
                const TestInterfaceOrOnlyForUseInConstructor&, ErrorResult&);
  */

  static
  already_AddRefed Test(const GlobalObject&, ErrorResult&);
  static
  already_AddRefed Test(const GlobalObject&, const nsAString&,
                                       ErrorResult&);
  static
  already_AddRefed Test(const GlobalObject&, const nsACString&,
                                       ErrorResult&);

  static
  already_AddRefed Test2(const GlobalObject&,
                                        JSContext*,
                                        const DictForConstructor&,
                                        JS::Handle,
                                        JS::Handle,
                                        JS::Handle,
                                        const Sequence&,
                                        JS::Handle,
                                        const Optional >&,
                                        const Optional >&,
                                        ErrorResult&);

  // Integer types
  int8_t ReadonlyByte();
  int8_t WritableByte();
  void SetWritableByte(int8_t);
  void PassByte(int8_t);
  int8_t ReceiveByte();
  void PassOptionalByte(const Optional&);
  void PassOptionalByteBeforeRequired(const Optional&, int8_t);
  void PassOptionalByteWithDefault(int8_t);
  void PassOptionalByteWithDefaultBeforeRequired(int8_t, int8_t);
  void PassNullableByte(const Nullable&);
  void PassOptionalNullableByte(const Optional< Nullable >&);
  void PassVariadicByte(const Sequence&);
  int8_t CachedByte();
  int8_t CachedConstantByte();
  int8_t CachedWritableByte();
  void SetCachedWritableByte(int8_t);

  int16_t ReadonlyShort();
  int16_t WritableShort();
  void SetWritableShort(int16_t);
  void PassShort(int16_t);
  int16_t ReceiveShort();
  void PassOptionalShort(const Optional&);
  void PassOptionalShortWithDefault(int16_t);

  int32_t ReadonlyLong();
  int32_t WritableLong();
  void SetWritableLong(int32_t);
  void PassLong(int32_t);
  int16_t ReceiveLong();
  void PassOptionalLong(const Optional&);
  void PassOptionalLongWithDefault(int32_t);

  int64_t ReadonlyLongLong();
  int64_t WritableLongLong();
  void SetWritableLongLong(int64_t);
  void PassLongLong(int64_t);
  int64_t ReceiveLongLong();
  void PassOptionalLongLong(const Optional&);
  void PassOptionalLongLongWithDefault(int64_t);

  uint8_t ReadonlyOctet();
  uint8_t WritableOctet();
  void SetWritableOctet(uint8_t);
  void PassOctet(uint8_t);
  uint8_t ReceiveOctet();
  void PassOptionalOctet(const Optional&);
  void PassOptionalOctetWithDefault(uint8_t);

  uint16_t ReadonlyUnsignedShort();
  uint16_t WritableUnsignedShort();
  void SetWritableUnsignedShort(uint16_t);
  void PassUnsignedShort(uint16_t);
  uint16_t ReceiveUnsignedShort();
  void PassOptionalUnsignedShort(const Optional&);
  void PassOptionalUnsignedShortWithDefault(uint16_t);

  uint32_t ReadonlyUnsignedLong();
  uint32_t WritableUnsignedLong();
  void SetWritableUnsignedLong(uint32_t);
  void PassUnsignedLong(uint32_t);
  uint32_t ReceiveUnsignedLong();
  void PassOptionalUnsignedLong(const Optional&);
  void PassOptionalUnsignedLongWithDefault(uint32_t);

  uint64_t ReadonlyUnsignedLongLong();
  uint64_t WritableUnsignedLongLong();
  void SetWritableUnsignedLongLong(uint64_t);
  void PassUnsignedLongLong(uint64_t);
  uint64_t ReceiveUnsignedLongLong();
  void PassOptionalUnsignedLongLong(const Optional&);
  void PassOptionalUnsignedLongLongWithDefault(uint64_t);

  float WritableFloat() const;
  void SetWritableFloat(float);
  float WritableUnrestrictedFloat() const;
  void SetWritableUnrestrictedFloat(float);
  Nullable GetWritableNullableFloat() const;
  void SetWritableNullableFloat(Nullable);
  Nullable GetWritableNullableUnrestrictedFloat() const;
  void SetWritableNullableUnrestrictedFloat(Nullable);
  double WritableDouble() const;
  void SetWritableDouble(double);
  double WritableUnrestrictedDouble() const;
  void SetWritableUnrestrictedDouble(double);
  Nullable GetWritableNullableDouble() const;
  void SetWritableNullableDouble(Nullable);
  Nullable GetWritableNullableUnrestrictedDouble() const;
  void SetWritableNullableUnrestrictedDouble(Nullable);
  void PassFloat(float, float, Nullable, Nullable,
                 double, double, Nullable, Nullable,
                 const Sequence&, const Sequence&,
                 const Sequence >&,
                 const Sequence >&,
                 const Sequence&, const Sequence&,
                 const Sequence >&,
                 const Sequence >&);
  void PassLenientFloat(float, float, Nullable, Nullable,
                        double, double, Nullable, Nullable,
                        const Sequence&, const Sequence&,
                        const Sequence >&,
                        const Sequence >&,
                        const Sequence&, const Sequence&,
                        const Sequence >&,
                        const Sequence >&);
  float LenientFloatAttr() const;
  void SetLenientFloatAttr(float);
  double LenientDoubleAttr() const;
  void SetLenientDoubleAttr(double);

  void PassUnrestricted(float arg1,
                        float arg2,
                        float arg3,
                        float arg4,
                        double arg5,
                        double arg6,
                        double arg7,
                        double arg8);

  // Interface types
  already_AddRefed ReceiveSelf();
  already_AddRefed ReceiveNullableSelf();
  TestInterface* ReceiveWeakSelf();
  TestInterface* ReceiveWeakNullableSelf();
  void PassSelf(TestInterface&);
  void PassNullableSelf(TestInterface*);
  already_AddRefed NonNullSelf();
  void SetNonNullSelf(TestInterface&);
  already_AddRefed GetNullableSelf();
  already_AddRefed CachedSelf();
  void SetNullableSelf(TestInterface*);
  void PassOptionalSelf(const Optional &);
  void PassOptionalNonNullSelf(const Optional >&);
  void PassOptionalSelfWithDefault(TestInterface*);

  already_AddRefed ReceiveNonWrapperCacheInterface();
  already_AddRefed ReceiveNullableNonWrapperCacheInterface();
  void ReceiveNonWrapperCacheInterfaceSequence(nsTArray >&);
  void ReceiveNullableNonWrapperCacheInterfaceSequence(nsTArray >&);
  void ReceiveNonWrapperCacheInterfaceNullableSequence(Nullable > >&);
  void ReceiveNullableNonWrapperCacheInterfaceNullableSequence(Nullable > >&);

  already_AddRefed ReceiveOther();
  already_AddRefed ReceiveNullableOther();
  IndirectlyImplementedInterface* ReceiveWeakOther();
  IndirectlyImplementedInterface* ReceiveWeakNullableOther();
  void PassOther(IndirectlyImplementedInterface&);
  void PassNullableOther(IndirectlyImplementedInterface*);
  already_AddRefed NonNullOther();
  void SetNonNullOther(IndirectlyImplementedInterface&);
  already_AddRefed GetNullableOther();
  void SetNullableOther(IndirectlyImplementedInterface*);
  void PassOptionalOther(const Optional&);
  void PassOptionalNonNullOther(const Optional >&);
  void PassOptionalOtherWithDefault(IndirectlyImplementedInterface*);

  already_AddRefed ReceiveExternal();
  already_AddRefed ReceiveNullableExternal();
  TestExternalInterface* ReceiveWeakExternal();
  TestExternalInterface* ReceiveWeakNullableExternal();
  void PassExternal(TestExternalInterface*);
  void PassNullableExternal(TestExternalInterface*);
  already_AddRefed NonNullExternal();
  void SetNonNullExternal(TestExternalInterface*);
  already_AddRefed GetNullableExternal();
  void SetNullableExternal(TestExternalInterface*);
  void PassOptionalExternal(const Optional&);
  void PassOptionalNonNullExternal(const Optional&);
  void PassOptionalExternalWithDefault(TestExternalInterface*);

  already_AddRefed ReceiveCallbackInterface();
  already_AddRefed ReceiveNullableCallbackInterface();
  TestCallbackInterface* ReceiveWeakCallbackInterface();
  TestCallbackInterface* ReceiveWeakNullableCallbackInterface();
  void PassCallbackInterface(TestCallbackInterface&);
  void PassNullableCallbackInterface(TestCallbackInterface*);
  already_AddRefed NonNullCallbackInterface();
  void SetNonNullCallbackInterface(TestCallbackInterface&);
  already_AddRefed GetNullableCallbackInterface();
  void SetNullableCallbackInterface(TestCallbackInterface*);
  void PassOptionalCallbackInterface(const Optional >&);
  void PassOptionalNonNullCallbackInterface(const Optional >&);
  void PassOptionalCallbackInterfaceWithDefault(TestCallbackInterface*);

  already_AddRefed ReceiveConsequentialInterface();
  void PassConsequentialInterface(IndirectlyImplementedInterface&);

  // Sequence types
  void GetReadonlySequence(nsTArray&);
  void GetReadonlySequenceOfDictionaries(JSContext*, nsTArray&);
  void GetReadonlyNullableSequenceOfDictionaries(JSContext*, Nullable >&);
  void GetReadonlyFrozenSequence(JSContext*, nsTArray&);
  void GetReadonlyFrozenNullableSequence(JSContext*, Nullable>&);
  void ReceiveSequence(nsTArray&);
  void ReceiveNullableSequence(Nullable< nsTArray >&);
  void ReceiveSequenceOfNullableInts(nsTArray< Nullable >&);
  void ReceiveNullableSequenceOfNullableInts(Nullable< nsTArray< Nullable > >&);
  void PassSequence(const Sequence &);
  void PassNullableSequence(const Nullable< Sequence >&);
  void PassSequenceOfNullableInts(const Sequence >&);
  void PassOptionalSequenceOfNullableInts(const Optional > > &);
  void PassOptionalNullableSequenceOfNullableInts(const Optional > > > &);
  void ReceiveCastableObjectSequence(nsTArray< nsRefPtr > &);
  void ReceiveCallbackObjectSequence(nsTArray< nsRefPtr > &);
  void ReceiveNullableCastableObjectSequence(nsTArray< nsRefPtr > &);
  void ReceiveNullableCallbackObjectSequence(nsTArray< nsRefPtr > &);
  void ReceiveCastableObjectNullableSequence(Nullable< nsTArray< nsRefPtr > >&);
  void ReceiveNullableCastableObjectNullableSequence(Nullable< nsTArray< nsRefPtr > >&);
  void ReceiveWeakCastableObjectSequence(nsTArray &);
  void ReceiveWeakNullableCastableObjectSequence(nsTArray &);
  void ReceiveWeakCastableObjectNullableSequence(Nullable< nsTArray >&);
  void ReceiveWeakNullableCastableObjectNullableSequence(Nullable< nsTArray >&);
  void PassCastableObjectSequence(const Sequence< OwningNonNull >&);
  void PassNullableCastableObjectSequence(const Sequence< nsRefPtr > &);
  void PassCastableObjectNullableSequence(const Nullable< Sequence< OwningNonNull > >&);
  void PassNullableCastableObjectNullableSequence(const Nullable< Sequence< nsRefPtr > >&);
  void PassOptionalSequence(const Optional >&);
  void PassOptionalNullableSequence(const Optional > >&);
  void PassOptionalNullableSequenceWithDefaultValue(const Nullable< Sequence >&);
  void PassOptionalObjectSequence(const Optional > >&);
  void PassExternalInterfaceSequence(const Sequence >&);
  void PassNullableExternalInterfaceSequence(const Sequence >&);

  void ReceiveStringSequence(nsTArray&);
  void PassStringSequence(const Sequence&);

  void ReceiveByteStringSequence(nsTArray&);
  void PassByteStringSequence(const Sequence&);

  void ReceiveAnySequence(JSContext*, nsTArray&);
  void ReceiveNullableAnySequence(JSContext*, Nullable >&);
  void ReceiveAnySequenceSequence(JSContext*, nsTArray >&);

  void ReceiveObjectSequence(JSContext*, nsTArray&);
  void ReceiveNullableObjectSequence(JSContext*, nsTArray&);

  void PassSequenceOfSequences(const Sequence< Sequence >&);
  void ReceiveSequenceOfSequences(nsTArray< nsTArray >&);

  // MozMap types
  void PassMozMap(const MozMap &);
  void PassNullableMozMap(const Nullable< MozMap >&);
  void PassMozMapOfNullableInts(const MozMap >&);
  void PassOptionalMozMapOfNullableInts(const Optional > > &);
  void PassOptionalNullableMozMapOfNullableInts(const Optional > > > &);
  void PassCastableObjectMozMap(const MozMap< OwningNonNull >&);
  void PassNullableCastableObjectMozMap(const MozMap< nsRefPtr > &);
  void PassCastableObjectNullableMozMap(const Nullable< MozMap< OwningNonNull > >&);
  void PassNullableCastableObjectNullableMozMap(const Nullable< MozMap< nsRefPtr > >&);
  void PassOptionalMozMap(const Optional >&);
  void PassOptionalNullableMozMap(const Optional > >&);
  void PassOptionalNullableMozMapWithDefaultValue(const Nullable< MozMap >&);
  void PassOptionalObjectMozMap(const Optional > >&);
  void PassExternalInterfaceMozMap(const MozMap >&);
  void PassNullableExternalInterfaceMozMap(const MozMap >&);
  void PassStringMozMap(const MozMap&);
  void PassByteStringMozMap(const MozMap&);
  void PassMozMapOfMozMaps(const MozMap< MozMap >&);
  void ReceiveMozMap(MozMap&);
  void ReceiveNullableMozMap(Nullable>&);
  void ReceiveMozMapOfNullableInts(MozMap>&);
  void ReceiveNullableMozMapOfNullableInts(Nullable>>&);
  void ReceiveMozMapOfMozMaps(MozMap>&);
  void ReceiveAnyMozMap(JSContext*, MozMap&);

  // Typed array types
  void PassArrayBuffer(const ArrayBuffer&);
  void PassNullableArrayBuffer(const Nullable&);
  void PassOptionalArrayBuffer(const Optional&);
  void PassOptionalNullableArrayBuffer(const Optional >&);
  void PassOptionalNullableArrayBufferWithDefaultValue(const Nullable&);
  void PassArrayBufferView(const ArrayBufferView&);
  void PassInt8Array(const Int8Array&);
  void PassInt16Array(const Int16Array&);
  void PassInt32Array(const Int32Array&);
  void PassUint8Array(const Uint8Array&);
  void PassUint16Array(const Uint16Array&);
  void PassUint32Array(const Uint32Array&);
  void PassUint8ClampedArray(const Uint8ClampedArray&);
  void PassFloat32Array(const Float32Array&);
  void PassFloat64Array(const Float64Array&);
  void PassSequenceOfArrayBuffers(const Sequence&);
  void PassSequenceOfNullableArrayBuffers(const Sequence >&);
  void PassMozMapOfArrayBuffers(const MozMap&);
  void PassMozMapOfNullableArrayBuffers(const MozMap >&);
  void PassVariadicTypedArray(const Sequence&);
  void PassVariadicNullableTypedArray(const Sequence >&);
  JSObject* ReceiveUint8Array(JSContext*);

  // DOMString types
  void PassString(const nsAString&);
  void PassNullableString(const nsAString&);
  void PassOptionalString(const Optional&);
  void PassOptionalStringWithDefaultValue(const nsAString&);
  void PassOptionalNullableString(const Optional&);
  void PassOptionalNullableStringWithDefaultValue(const nsAString&);
  void PassVariadicString(const Sequence&);

  // ByteString types
  void PassByteString(const nsCString&);
  void PassNullableByteString(const nsCString&);
  void PassOptionalByteString(const Optional&);
  void PassOptionalNullableByteString(const Optional&);
  void PassVariadicByteString(const Sequence&);

  // Enumerated types
  void PassEnum(TestEnum);
  void PassNullableEnum(const Nullable&);
  void PassOptionalEnum(const Optional&);
  void PassEnumWithDefault(TestEnum);
  void PassOptionalNullableEnum(const Optional >&);
  void PassOptionalNullableEnumWithDefaultValue(const Nullable&);
  void PassOptionalNullableEnumWithDefaultValue2(const Nullable&);
  TestEnum ReceiveEnum();
  Nullable ReceiveNullableEnum();
  TestEnum EnumAttribute();
  TestEnum ReadonlyEnumAttribute();
  void SetEnumAttribute(TestEnum);

  // Callback types
  void PassCallback(TestCallback&);
  void PassNullableCallback(TestCallback*);
  void PassOptionalCallback(const Optional >&);
  void PassOptionalNullableCallback(const Optional >&);
  void PassOptionalNullableCallbackWithDefaultValue(TestCallback*);
  already_AddRefed ReceiveCallback();
  already_AddRefed ReceiveNullableCallback();
  void PassNullableTreatAsNullCallback(TestTreatAsNullCallback*);
  void PassOptionalNullableTreatAsNullCallback(const Optional >&);
  void PassOptionalNullableTreatAsNullCallbackWithDefaultValue(TestTreatAsNullCallback*);
  void SetTreatAsNullCallback(TestTreatAsNullCallback&);
  already_AddRefed TreatAsNullCallback();
  void SetNullableTreatAsNullCallback(TestTreatAsNullCallback*);
  already_AddRefed GetNullableTreatAsNullCallback();

  // Any types
  void PassAny(JSContext*, JS::Handle);
  void PassVariadicAny(JSContext*, const Sequence&);
  void PassOptionalAny(JSContext*, JS::Handle);
  void PassAnyDefaultNull(JSContext*, JS::Handle);
  void PassSequenceOfAny(JSContext*, const Sequence&);
  void PassNullableSequenceOfAny(JSContext*, const Nullable >&);
  void PassOptionalSequenceOfAny(JSContext*, const Optional >&);
  void PassOptionalNullableSequenceOfAny(JSContext*, const Optional > >&);
  void PassOptionalSequenceOfAnyWithDefaultValue(JSContext*, const Nullable >&);
  void PassSequenceOfSequenceOfAny(JSContext*, const Sequence >&);
  void PassSequenceOfNullableSequenceOfAny(JSContext*, const Sequence > >&);
  void PassNullableSequenceOfNullableSequenceOfAny(JSContext*, const Nullable > > >&);
  void PassOptionalNullableSequenceOfNullableSequenceOfAny(JSContext*, const Optional > > > >&);
  void PassMozMapOfAny(JSContext*, const MozMap&);
  void PassNullableMozMapOfAny(JSContext*, const Nullable >&);
  void PassOptionalMozMapOfAny(JSContext*, const Optional >&);
  void PassOptionalNullableMozMapOfAny(JSContext*, const Optional > >&);
  void PassOptionalMozMapOfAnyWithDefaultValue(JSContext*, const Nullable >&);
  void PassMozMapOfMozMapOfAny(JSContext*, const MozMap >&);
  void PassMozMapOfNullableMozMapOfAny(JSContext*, const MozMap > >&);
  void PassNullableMozMapOfNullableMozMapOfAny(JSContext*, const Nullable > > >&);
  void PassOptionalNullableMozMapOfNullableMozMapOfAny(JSContext*, const Optional>>>>&);
  void PassOptionalNullableMozMapOfNullableSequenceOfAny(JSContext*, const Optional>>>>&);
  void PassOptionalNullableSequenceOfNullableMozMapOfAny(JSContext*, const Optional>>>>&);
  void ReceiveAny(JSContext*, JS::MutableHandle);

  // object types
  void PassObject(JSContext*, JS::Handle);
  void PassVariadicObject(JSContext*, const Sequence&);
  void PassNullableObject(JSContext*, JS::Handle);
  void PassVariadicNullableObject(JSContext*, const Sequence&);
  void PassOptionalObject(JSContext*, const Optional >&);
  void PassOptionalNullableObject(JSContext*, const Optional >&);
  void PassOptionalNullableObjectWithDefaultValue(JSContext*, JS::Handle);
  void PassSequenceOfObject(JSContext*, const Sequence&);
  void PassSequenceOfNullableObject(JSContext*, const Sequence&);
  void PassNullableSequenceOfObject(JSContext*, const Nullable >&);
  void PassOptionalNullableSequenceOfNullableSequenceOfObject(JSContext*, const Optional > > > >&);
  void PassOptionalNullableSequenceOfNullableSequenceOfNullableObject(JSContext*, const Optional > > > >&);
  void PassMozMapOfObject(JSContext*, const MozMap&);
  JSObject* ReceiveObject(JSContext*);
  JSObject* ReceiveNullableObject(JSContext*);

  // Union types
  void PassUnion(JSContext*, const ObjectOrLong& arg);
  void PassUnionWithNullable(JSContext* cx, const ObjectOrNullOrLong& arg)
  {
    OwningObjectOrLong returnValue;
    if (arg.IsNull()) {
    } else if (arg.IsObject()) {
      JS::Rooted obj(cx, arg.GetAsObject());
      JS_GetClass(obj);
      returnValue.SetAsObject() = obj;
    } else {
      int32_t i = arg.GetAsLong();
      i += 1;
      returnValue.SetAsLong() = i;
    }
  }
#ifdef DEBUG
  void PassUnion2(const LongOrBoolean& arg);
  void PassUnion3(JSContext*, const ObjectOrLongOrBoolean& arg);
  void PassUnion4(const NodeOrLongOrBoolean& arg);
  void PassUnion5(JSContext*, const ObjectOrBoolean& arg);
  void PassUnion6(JSContext*, const ObjectOrString& arg);
  void PassUnion7(JSContext*, const ObjectOrStringOrLong& arg);
  void PassUnion8(JSContext*, const ObjectOrStringOrBoolean& arg);
  void PassUnion9(JSContext*, const ObjectOrStringOrLongOrBoolean& arg);
  void PassUnion10(const EventInitOrLong& arg);
  void PassUnion11(JSContext*, const CustomEventInitOrLong& arg);
  void PassUnion12(const EventInitOrLong& arg);
  void PassUnion13(JSContext*, const ObjectOrLongOrNull& arg);
  void PassUnion14(JSContext*, const ObjectOrLongOrNull& arg);
  void PassUnionWithCallback(const EventHandlerNonNullOrNullOrLong& arg);
#endif
  void PassNullableUnion(JSContext*, const Nullable&);
  void PassOptionalUnion(JSContext*, const Optional&);
  void PassOptionalNullableUnion(JSContext*, const Optional >&);
  void PassOptionalNullableUnionWithDefaultValue(JSContext*, const Nullable&);
  //void PassUnionWithInterfaces(const TestInterfaceOrTestExternalInterface& arg);
  //void PassUnionWithInterfacesAndNullable(const TestInterfaceOrNullOrTestExternalInterface& arg);
  void PassUnionWithArrayBuffer(const ArrayBufferOrLong&);
  void PassUnionWithString(JSContext*, const StringOrObject&);
  //void PassUnionWithEnum(JSContext*, const TestEnumOrObject&);
  //void PassUnionWithCallback(JSContext*, const TestCallbackOrLong&);
  void PassUnionWithObject(JSContext*, const ObjectOrLong&);

  void PassUnionWithDefaultValue1(const DoubleOrString& arg);
  void PassUnionWithDefaultValue2(const DoubleOrString& arg);
  void PassUnionWithDefaultValue3(const DoubleOrString& arg);
  void PassUnionWithDefaultValue4(const FloatOrString& arg);
  void PassUnionWithDefaultValue5(const FloatOrString& arg);
  void PassUnionWithDefaultValue6(const FloatOrString& arg);
  void PassUnionWithDefaultValue7(const UnrestrictedDoubleOrString& arg);
  void PassUnionWithDefaultValue8(const UnrestrictedDoubleOrString& arg);
  void PassUnionWithDefaultValue9(const UnrestrictedDoubleOrString& arg);
  void PassUnionWithDefaultValue10(const UnrestrictedDoubleOrString& arg);
  void PassUnionWithDefaultValue11(const UnrestrictedFloatOrString& arg);
  void PassUnionWithDefaultValue12(const UnrestrictedFloatOrString& arg);
  void PassUnionWithDefaultValue13(const UnrestrictedFloatOrString& arg);
  void PassUnionWithDefaultValue14(const UnrestrictedFloatOrString& arg);

  void PassNullableUnionWithDefaultValue1(const Nullable& arg);
  void PassNullableUnionWithDefaultValue2(const Nullable& arg);
  void PassNullableUnionWithDefaultValue3(const Nullable& arg);
  void PassNullableUnionWithDefaultValue4(const Nullable& arg);
  void PassNullableUnionWithDefaultValue5(const Nullable& arg);
  void PassNullableUnionWithDefaultValue6(const Nullable& arg);
  void PassNullableUnionWithDefaultValue7(const Nullable& arg);
  void PassNullableUnionWithDefaultValue8(const Nullable& arg);
  void PassNullableUnionWithDefaultValue9(const Nullable& arg);
  void PassNullableUnionWithDefaultValue10(const Nullable& arg);
  void PassNullableUnionWithDefaultValue11(const Nullable& arg);
  void PassNullableUnionWithDefaultValue12(const Nullable& arg);

  void PassSequenceOfUnions(const Sequence&);
  void PassSequenceOfUnions2(JSContext*, const Sequence&);
  void PassVariadicUnion(const Sequence&);

  void PassSequenceOfNullableUnions(const Sequence>&);
  void PassVariadicNullableUnion(const Sequence>&);
  void PassMozMapOfUnions(const MozMap&);
  void PassMozMapOfUnions2(JSContext*, const MozMap&);

  void ReceiveUnion(OwningCanvasPatternOrCanvasGradient&);
  void ReceiveUnion2(JSContext*, OwningObjectOrLong&);
  void ReceiveUnionContainingNull(OwningCanvasPatternOrNullOrCanvasGradient&);
  void ReceiveNullableUnion(Nullable&);
  void ReceiveNullableUnion2(JSContext*, Nullable&);
  void GetWritableUnion(OwningCanvasPatternOrCanvasGradient&);
  void SetWritableUnion(const CanvasPatternOrCanvasGradient&);
  void GetWritableUnionContainingNull(OwningCanvasPatternOrNullOrCanvasGradient&);
  void SetWritableUnionContainingNull(const CanvasPatternOrNullOrCanvasGradient&);
  void GetWritableNullableUnion(Nullable&);
  void SetWritableNullableUnion(const Nullable&);

  // Date types
  void PassDate(Date);
  void PassNullableDate(const Nullable&);
  void PassOptionalDate(const Optional&);
  void PassOptionalNullableDate(const Optional >&);
  void PassOptionalNullableDateWithDefaultValue(const Nullable&);
  void PassDateSequence(const Sequence&);
  void PassDateMozMap(const MozMap&);
  void PassNullableDateSequence(const Sequence >&);
  Date ReceiveDate();
  Nullable ReceiveNullableDate();

  // binaryNames tests
  void MethodRenamedTo();
  void MethodRenamedTo(int8_t);
  int8_t AttributeGetterRenamedTo();
  int8_t AttributeRenamedTo();
  void SetAttributeRenamedTo(int8_t);

  // Dictionary tests
  void PassDictionary(JSContext*, const Dict&);
  void GetReadonlyDictionary(JSContext*, Dict&);
  void GetReadonlyNullableDictionary(JSContext*, Nullable&);
  void GetWritableDictionary(JSContext*, Dict&);
  void SetWritableDictionary(JSContext*, const Dict&);
  void GetReadonlyFrozenDictionary(JSContext*, Dict&);
  void GetReadonlyFrozenNullableDictionary(JSContext*, Nullable&);
  void GetWritableFrozenDictionary(JSContext*, Dict&);
  void SetWritableFrozenDictionary(JSContext*, const Dict&);
  void ReceiveDictionary(JSContext*, Dict&);
  void ReceiveNullableDictionary(JSContext*, Nullable&);
  void PassOtherDictionary(const GrandparentDict&);
  void PassSequenceOfDictionaries(JSContext*, const Sequence&);
  void PassMozMapOfDictionaries(const MozMap&);
  void PassDictionaryOrLong(JSContext*, const Dict&);
  void PassDictionaryOrLong(int32_t);
  void PassDictContainingDict(JSContext*, const DictContainingDict&);
  void PassDictContainingSequence(JSContext*, const DictContainingSequence&);
  void ReceiveDictContainingSequence(JSContext*, DictContainingSequence&);

  // Typedefs
  void ExerciseTypedefInterfaces1(TestInterface&);
  already_AddRefed ExerciseTypedefInterfaces2(TestInterface*);
  void ExerciseTypedefInterfaces3(TestInterface&);

  // Static methods and attributes
  static void StaticMethod(const GlobalObject&, bool);
  static void StaticMethodWithContext(const GlobalObject&, JSContext*,
                                      JS::Value);
  static bool StaticAttribute(const GlobalObject&);
  static void SetStaticAttribute(const GlobalObject&, bool);

  // Overload resolution tests
  bool Overload1(TestInterface&);
  TestInterface* Overload1(const nsAString&, TestInterface&);
  void Overload2(TestInterface&);
  void Overload2(JSContext*, const Dict&);
  void Overload2(bool);
  void Overload2(const nsAString&);
  void Overload2(Date);
  void Overload3(TestInterface&);
  void Overload3(const TestCallback&);
  void Overload3(bool);
  void Overload4(TestInterface&);
  void Overload4(TestCallbackInterface&);
  void Overload4(const nsAString&);
  void Overload5(int32_t);
  void Overload5(TestEnum);
  void Overload6(int32_t);
  void Overload6(bool);
  void Overload7(int32_t);
  void Overload7(bool);
  void Overload7(const nsCString&);
  void Overload8(int32_t);
  void Overload8(TestInterface&);
  void Overload9(const Nullable&);
  void Overload9(const nsAString&);
  void Overload10(const Nullable&);
  void Overload10(JSContext*, JS::Handle);
  void Overload11(int32_t);
  void Overload11(const nsAString&);
  void Overload12(int32_t);
  void Overload12(const Nullable&);
  void Overload13(const Nullable&);
  void Overload13(bool);
  void Overload14(const Optional&);
  void Overload14(TestInterface&);
  void Overload15(int32_t);
  void Overload15(const Optional >&);
  void Overload16(int32_t);
  void Overload16(const Optional&);

  // Variadic handling
  void PassVariadicThirdArg(const nsAString&, int32_t,
                            const Sequence >&);

  // Conditionally exposed methods/attributes
  bool Prefable1();
  bool Prefable2();
  bool Prefable3();
  bool Prefable4();
  bool Prefable5();
  bool Prefable6();
  bool Prefable7();
  bool Prefable8();
  bool Prefable9();
  void Prefable10();
  void Prefable11();
  bool Prefable12();
  void Prefable13();
  bool Prefable14();
  bool Prefable15();
  bool Prefable16();
  void Prefable17();
  void Prefable18();
  void Prefable19();
  void Prefable20();
  void Prefable21();
  void Prefable22();
  void Prefable23();
  void Prefable24();

  // Miscellania
  int32_t AttrWithLenientThis();
  void SetAttrWithLenientThis(int32_t);
  uint32_t UnforgeableAttr();
  uint32_t UnforgeableAttr2();
  void Stringify(nsString&);
  void PassRenamedInterface(nsRenamedInterface&);
  TestInterface* PutForwardsAttr();
  TestInterface* PutForwardsAttr2();
  TestInterface* PutForwardsAttr3();
  void GetJsonifierShouldSkipThis(JSContext*, JS::MutableHandle);
  void SetJsonifierShouldSkipThis(JSContext*, JS::Rooted&);
  TestParentInterface* JsonifierShouldSkipThis2();
  void SetJsonifierShouldSkipThis2(TestParentInterface&);
  TestCallbackInterface* JsonifierShouldSkipThis3();
  void SetJsonifierShouldSkipThis3(TestCallbackInterface&);
  void ThrowingMethod(ErrorResult& aRv);
  bool GetThrowingAttr(ErrorResult& aRv) const;
  void SetThrowingAttr(bool arg, ErrorResult& aRv);
  bool GetThrowingGetterAttr(ErrorResult& aRv) const;
  void SetThrowingGetterAttr(bool arg);
  bool ThrowingSetterAttr() const;
  void SetThrowingSetterAttr(bool arg, ErrorResult& aRv);
  int16_t LegacyCall(JS::Value, uint32_t, TestInterface&);
  void PassArgsWithDefaults(JSContext*, const Optional&,
                            TestInterface*, const Dict&, double,
                            const Optional&);

  // Methods and properties imported via "implements"
  bool ImplementedProperty();
  void SetImplementedProperty(bool);
  void ImplementedMethod();
  bool ImplementedParentProperty();
  void SetImplementedParentProperty(bool);
  void ImplementedParentMethod();
  bool IndirectlyImplementedProperty();
  void SetIndirectlyImplementedProperty(bool);
  void IndirectlyImplementedMethod();
  uint32_t DiamondImplementedProperty();

  // Test EnforceRange/Clamp
  void DontEnforceRangeOrClamp(int8_t);
  void DoEnforceRange(int8_t);
  void DoClamp(int8_t);
  void SetEnforcedByte(int8_t);
  int8_t EnforcedByte();
  void SetClampedByte(int8_t);
  int8_t ClampedByte();

private:
  // We add signatures here that _could_ start matching if the codegen
  // got data types wrong.  That way if it ever does we'll have a call
  // to these private deleted methods and compilation will fail.
  void SetReadonlyByte(int8_t) MOZ_DELETE;
  template
  void SetWritableByte(T) MOZ_DELETE;
  template
  void PassByte(T) MOZ_DELETE;
  void PassNullableByte(Nullable&) MOZ_DELETE;
  template
  void PassOptionalByte(const Optional&) MOZ_DELETE;
  template
  void PassOptionalByteWithDefault(T) MOZ_DELETE;
  void PassVariadicByte(Sequence&) MOZ_DELETE;

  void SetReadonlyShort(int16_t) MOZ_DELETE;
  template
  void SetWritableShort(T) MOZ_DELETE;
  template
  void PassShort(T) MOZ_DELETE;
  template
  void PassOptionalShort(const Optional&) MOZ_DELETE;
  template
  void PassOptionalShortWithDefault(T) MOZ_DELETE;

  void SetReadonlyLong(int32_t) MOZ_DELETE;
  template
  void SetWritableLong(T) MOZ_DELETE;
  template
  void PassLong(T) MOZ_DELETE;
  template
  void PassOptionalLong(const Optional&) MOZ_DELETE;
  template
  void PassOptionalLongWithDefault(T) MOZ_DELETE;

  void SetReadonlyLongLong(int64_t) MOZ_DELETE;
  template
  void SetWritableLongLong(T) MOZ_DELETE;
  template
  void PassLongLong(T) MOZ_DELETE;
  template
  void PassOptionalLongLong(const Optional&) MOZ_DELETE;
  template
  void PassOptionalLongLongWithDefault(T) MOZ_DELETE;

  void SetReadonlyOctet(uint8_t) MOZ_DELETE;
  template
  void SetWritableOctet(T) MOZ_DELETE;
  template
  void PassOctet(T) MOZ_DELETE;
  template
  void PassOptionalOctet(const Optional&) MOZ_DELETE;
  template
  void PassOptionalOctetWithDefault(T) MOZ_DELETE;

  void SetReadonlyUnsignedShort(uint16_t) MOZ_DELETE;
  template
  void SetWritableUnsignedShort(T) MOZ_DELETE;
  template
  void PassUnsignedShort(T) MOZ_DELETE;
  template
  void PassOptionalUnsignedShort(const Optional&) MOZ_DELETE;
  template
  void PassOptionalUnsignedShortWithDefault(T) MOZ_DELETE;

  void SetReadonlyUnsignedLong(uint32_t) MOZ_DELETE;
  template
  void SetWritableUnsignedLong(T) MOZ_DELETE;
  template
  void PassUnsignedLong(T) MOZ_DELETE;
  template
  void PassOptionalUnsignedLong(const Optional&) MOZ_DELETE;
  template
  void PassOptionalUnsignedLongWithDefault(T) MOZ_DELETE;

  void SetReadonlyUnsignedLongLong(uint64_t) MOZ_DELETE;
  template
  void SetWritableUnsignedLongLong(T) MOZ_DELETE;
  template
  void PassUnsignedLongLong(T) MOZ_DELETE;
  template
  void PassOptionalUnsignedLongLong(const Optional&) MOZ_DELETE;
  template
  void PassOptionalUnsignedLongLongWithDefault(T) MOZ_DELETE;

  // Enforce that only const things are passed for sequences
  void PassSequence(Sequence &) MOZ_DELETE;
  void PassNullableSequence(Nullable< Sequence >&) MOZ_DELETE;
  void PassOptionalNullableSequenceWithDefaultValue(Nullable< Sequence >&) MOZ_DELETE;
  void PassSequenceOfAny(JSContext*, Sequence&) MOZ_DELETE;
  void PassNullableSequenceOfAny(JSContext*, Nullable >&) MOZ_DELETE;
  void PassOptionalSequenceOfAny(JSContext*, Optional >&) MOZ_DELETE;
  void PassOptionalNullableSequenceOfAny(JSContext*, Optional > >&) MOZ_DELETE;
  void PassOptionalSequenceOfAnyWithDefaultValue(JSContext*, Nullable >&) MOZ_DELETE;
  void PassSequenceOfSequenceOfAny(JSContext*, Sequence >&) MOZ_DELETE;
  void PassSequenceOfNullableSequenceOfAny(JSContext*, Sequence > >&) MOZ_DELETE;
  void PassNullableSequenceOfNullableSequenceOfAny(JSContext*, Nullable > > >&) MOZ_DELETE;
  void PassOptionalNullableSequenceOfNullableSequenceOfAny(JSContext*, Optional > > > >&) MOZ_DELETE;
  void PassSequenceOfObject(JSContext*, Sequence&) MOZ_DELETE;
  void PassSequenceOfNullableObject(JSContext*, Sequence&) MOZ_DELETE;
  void PassOptionalNullableSequenceOfNullableSequenceOfObject(JSContext*, Optional > > > >&) MOZ_DELETE;
  void PassOptionalNullableSequenceOfNullableSequenceOfNullableObject(JSContext*, Optional > > > >&) MOZ_DELETE;

  // Enforce that only const things are passed for optional
  void PassOptionalByte(Optional&) MOZ_DELETE;
  void PassOptionalNullableByte(Optional >&) MOZ_DELETE;
  void PassOptionalShort(Optional&) MOZ_DELETE;
  void PassOptionalLong(Optional&) MOZ_DELETE;
  void PassOptionalLongLong(Optional&) MOZ_DELETE;
  void PassOptionalOctet(Optional&) MOZ_DELETE;
  void PassOptionalUnsignedShort(Optional&) MOZ_DELETE;
  void PassOptionalUnsignedLong(Optional&) MOZ_DELETE;
  void PassOptionalUnsignedLongLong(Optional&) MOZ_DELETE;
  void PassOptionalSelf(Optional &) MOZ_DELETE;
  void PassOptionalNonNullSelf(Optional >&) MOZ_DELETE;
  void PassOptionalOther(Optional&);
  void PassOptionalNonNullOther(Optional >&);
  void PassOptionalExternal(Optional&) MOZ_DELETE;
  void PassOptionalNonNullExternal(Optional&) MOZ_DELETE;
  void PassOptionalSequence(Optional >&) MOZ_DELETE;
  void PassOptionalNullableSequence(Optional > >&) MOZ_DELETE;
  void PassOptionalObjectSequence(Optional > >&) MOZ_DELETE;
  void PassOptionalArrayBuffer(Optional&) MOZ_DELETE;
  void PassOptionalNullableArrayBuffer(Optional&) MOZ_DELETE;
  void PassOptionalEnum(Optional&) MOZ_DELETE;
  void PassOptionalCallback(JSContext*, Optional >&) MOZ_DELETE;
  void PassOptionalNullableCallback(JSContext*, Optional >&) MOZ_DELETE;
  void PassOptionalAny(Optional >&) MOZ_DELETE;

  // And test that string stuff is always const
  void PassString(nsAString&) MOZ_DELETE;
  void PassNullableString(nsAString&) MOZ_DELETE;
  void PassOptionalString(Optional&) MOZ_DELETE;
  void PassOptionalStringWithDefaultValue(nsAString&) MOZ_DELETE;
  void PassOptionalNullableString(Optional&) MOZ_DELETE;
  void PassOptionalNullableStringWithDefaultValue(nsAString&) MOZ_DELETE;
  void PassVariadicString(Sequence&) MOZ_DELETE;

  // cstrings should be const as well
  void PassByteString(nsCString&) MOZ_DELETE;
  void PassNullableByteString(nsCString&) MOZ_DELETE;
  void PassOptionalByteString(Optional&) MOZ_DELETE;
  void PassOptionalNullableByteString(Optional&) MOZ_DELETE;
  void PassVariadicByteString(Sequence&) MOZ_DELETE;

  // Make sure dictionary arguments are always const
  void PassDictionary(JSContext*, Dict&) MOZ_DELETE;
  void PassOtherDictionary(GrandparentDict&) MOZ_DELETE;
  void PassSequenceOfDictionaries(JSContext*, Sequence&) MOZ_DELETE;
  void PassDictionaryOrLong(JSContext*, Dict&) MOZ_DELETE;
  void PassDictContainingDict(JSContext*, DictContainingDict&) MOZ_DELETE;
  void PassDictContainingSequence(DictContainingSequence&) MOZ_DELETE;

  // Make sure various nullable things are always const
  void PassNullableEnum(Nullable&) MOZ_DELETE;

  // Make sure unions are always const
  void PassUnion(JSContext*, ObjectOrLong& arg) MOZ_DELETE;
  void PassUnionWithNullable(JSContext*, ObjectOrNullOrLong& arg) MOZ_DELETE;
  void PassNullableUnion(JSContext*, Nullable&) MOZ_DELETE;
  void PassOptionalUnion(JSContext*, Optional&) MOZ_DELETE;
  void PassOptionalNullableUnion(JSContext*, Optional >&) MOZ_DELETE;
  void PassOptionalNullableUnionWithDefaultValue(JSContext*, Nullable&) MOZ_DELETE;

  // Make sure various date stuff is const as needed
  void PassNullableDate(Nullable&) MOZ_DELETE;
  void PassOptionalDate(Optional&) MOZ_DELETE;
  void PassOptionalNullableDate(Optional >&) MOZ_DELETE;
  void PassOptionalNullableDateWithDefaultValue(Nullable&) MOZ_DELETE;
  void PassDateSequence(Sequence&) MOZ_DELETE;
  void PassNullableDateSequence(Sequence >&) MOZ_DELETE;

  // Make sure variadics are const as needed
  void PassVariadicAny(JSContext*, Sequence&) MOZ_DELETE;
  void PassVariadicObject(JSContext*, Sequence&) MOZ_DELETE;
  void PassVariadicNullableObject(JSContext*, Sequence&) MOZ_DELETE;

  // Ensure NonNull does not leak in
  void PassSelf(NonNull&) MOZ_DELETE;
  void PassSelf(OwningNonNull&) MOZ_DELETE;
  void PassSelf(const NonNull&) MOZ_DELETE;
  void PassSelf(const OwningNonNull&) MOZ_DELETE;
  void PassOther(NonNull&) MOZ_DELETE;
  void PassOther(const NonNull&) MOZ_DELETE;
  void PassOther(OwningNonNull&) MOZ_DELETE;
  void PassOther(const OwningNonNull&) MOZ_DELETE;
  void PassCallbackInterface(OwningNonNull&) MOZ_DELETE;
  void PassCallbackInterface(const OwningNonNull&) MOZ_DELETE;
  void PassCallbackInterface(NonNull&) MOZ_DELETE;
  void PassCallbackInterface(const NonNull&) MOZ_DELETE;
  void PassCallback(OwningNonNull&) MOZ_DELETE;
  void PassCallback(const OwningNonNull&) MOZ_DELETE;
  void PassCallback(NonNull&) MOZ_DELETE;
  void PassCallback(const NonNull&) MOZ_DELETE;
  void PassString(const NonNull&) MOZ_DELETE;
  void PassString(NonNull&) MOZ_DELETE;
  void PassString(const OwningNonNull&) MOZ_DELETE;
  void PassString(OwningNonNull&) MOZ_DELETE;
};

class TestIndexedGetterInterface : public nsISupports,
                                   public nsWrapperCache
{
public:
  NS_DECL_ISUPPORTS

  // We need a GetParentObject to make binding codegen happy
  virtual nsISupports* GetParentObject();

  uint32_t IndexedGetter(uint32_t, bool&);
  uint32_t IndexedGetter(uint32_t&) MOZ_DELETE;
  uint32_t Item(uint32_t&);
  uint32_t Item(uint32_t, bool&) MOZ_DELETE;
  uint32_t Length();
  void LegacyCall(JS::Handle);
};

class TestNamedGetterInterface : public nsISupports,
                                 public nsWrapperCache
{
public:
  NS_DECL_ISUPPORTS

  // We need a GetParentObject to make binding codegen happy
  virtual nsISupports* GetParentObject();

  void NamedGetter(const nsAString&, bool&, nsAString&);
  bool NameIsEnumerable(const nsAString&);
  void GetSupportedNames(unsigned, nsTArray&);
};

class TestIndexedGetterAndSetterAndNamedGetterInterface : public nsISupports,
                                                          public nsWrapperCache
{
public:
  NS_DECL_ISUPPORTS

  // We need a GetParentObject to make binding codegen happy
  virtual nsISupports* GetParentObject();

  void NamedGetter(const nsAString&, bool&, nsAString&);
  bool NameIsEnumerable(const nsAString&);
  void GetSupportedNames(unsigned, nsTArray&);
  int32_t IndexedGetter(uint32_t, bool&);
  void IndexedSetter(uint32_t, int32_t);
  uint32_t Length();
};

class TestIndexedAndNamedGetterInterface : public nsISupports,
                                           public nsWrapperCache
{
public:
  NS_DECL_ISUPPORTS

  // We need a GetParentObject to make binding codegen happy
  virtual nsISupports* GetParentObject();

  uint32_t IndexedGetter(uint32_t, bool&);
  void NamedGetter(const nsAString&, bool&, nsAString&);
  bool NameIsEnumerable(const nsAString&);
  void NamedItem(const nsAString&, nsAString&);
  uint32_t Length();
  void GetSupportedNames(unsigned, nsTArray&);
};

class TestIndexedSetterInterface : public nsISupports,
                                   public nsWrapperCache
{
public:
  NS_DECL_ISUPPORTS

  // We need a GetParentObject to make binding codegen happy
  virtual nsISupports* GetParentObject();

  void IndexedSetter(uint32_t, const nsAString&);
  void IndexedGetter(uint32_t, bool&, nsString&);
  uint32_t Length();
  void SetItem(uint32_t, const nsAString&);
};

class TestNamedSetterInterface : public nsISupports,
                                 public nsWrapperCache
{
public:
  NS_DECL_ISUPPORTS

  // We need a GetParentObject to make binding codegen happy
  virtual nsISupports* GetParentObject();

  void NamedSetter(const nsAString&, TestIndexedSetterInterface&);
  TestIndexedSetterInterface* NamedGetter(const nsAString&, bool&);
  bool NameIsEnumerable(const nsAString&);
  void GetSupportedNames(unsigned, nsTArray&);
};

class TestIndexedAndNamedSetterInterface : public nsISupports,
                                           public nsWrapperCache
{
public:
  NS_DECL_ISUPPORTS

  // We need a GetParentObject to make binding codegen happy
  virtual nsISupports* GetParentObject();

  void IndexedSetter(uint32_t, TestIndexedSetterInterface&);
  TestIndexedSetterInterface* IndexedGetter(uint32_t, bool&);
  uint32_t Length();
  void NamedSetter(const nsAString&, TestIndexedSetterInterface&);
  TestIndexedSetterInterface* NamedGetter(const nsAString&, bool&);
  bool NameIsEnumerable(const nsAString&);
  void SetNamedItem(const nsAString&, TestIndexedSetterInterface&);
  void GetSupportedNames(unsigned, nsTArray&);
};

class TestIndexedAndNamedGetterAndSetterInterface : public TestIndexedSetterInterface
{
public:
  uint32_t IndexedGetter(uint32_t, bool&);
  uint32_t Item(uint32_t);
  void NamedGetter(const nsAString&, bool&, nsAString&);
  bool NameIsEnumerable(const nsAString&);
  void NamedItem(const nsAString&, nsAString&);
  void IndexedSetter(uint32_t, int32_t&);
  void IndexedSetter(uint32_t, const nsAString&) MOZ_DELETE;
  void NamedSetter(const nsAString&, const nsAString&);
  void Stringify(nsAString&);
  uint32_t Length();
  void GetSupportedNames(unsigned, nsTArray&);
};

class TestCppKeywordNamedMethodsInterface : public nsISupports,
                                            public nsWrapperCache
{
public:
  NS_DECL_ISUPPORTS

  // We need a GetParentObject to make binding codegen happy
  virtual nsISupports* GetParentObject();

  bool Continue();
  bool Delete();
  int32_t Volatile();
};

class TestIndexedDeleterInterface : public nsISupports,
                                    public nsWrapperCache
{
public:
  NS_DECL_ISUPPORTS

  // We need a GetParentObject to make binding codegen happy
  virtual nsISupports* GetParentObject();

  void IndexedDeleter(uint32_t, bool&);
  void IndexedDeleter(uint32_t) MOZ_DELETE;
  long IndexedGetter(uint32_t, bool&);
  uint32_t Length();
  void DelItem(uint32_t);
  void DelItem(uint32_t, bool&) MOZ_DELETE;
};

class TestIndexedDeleterWithRetvalInterface : public nsISupports,
                                              public nsWrapperCache
{
public:
  NS_DECL_ISUPPORTS

  // We need a GetParentObject to make binding codegen happy
  virtual nsISupports* GetParentObject();

  bool IndexedDeleter(uint32_t, bool&);
  bool IndexedDeleter(uint32_t) MOZ_DELETE;
  long IndexedGetter(uint32_t, bool&);
  uint32_t Length();
  bool DelItem(uint32_t);
  bool DelItem(uint32_t, bool&) MOZ_DELETE;
};

class TestNamedDeleterInterface : public nsISupports,
                                  public nsWrapperCache
{
public:
  NS_DECL_ISUPPORTS

  // We need a GetParentObject to make binding codegen happy
  virtual nsISupports* GetParentObject();

  void NamedDeleter(const nsAString&, bool&);
  long NamedGetter(const nsAString&, bool&);
  bool NameIsEnumerable(const nsAString&);
  void GetSupportedNames(unsigned, nsTArray&);
};

class TestNamedDeleterWithRetvalInterface : public nsISupports,
                                            public nsWrapperCache
{
public:
  NS_DECL_ISUPPORTS

  // We need a GetParentObject to make binding codegen happy
  virtual nsISupports* GetParentObject();

  bool NamedDeleter(const nsAString&, bool&);
  bool NamedDeleter(const nsAString&) MOZ_DELETE;
  long NamedGetter(const nsAString&, bool&);
  bool NameIsEnumerable(const nsAString&);
  bool DelNamedItem(const nsAString&);
  bool DelNamedItem(const nsAString&, bool&) MOZ_DELETE;
  void GetSupportedNames(unsigned, nsTArray&);
};

class TestIndexedAndNamedDeleterInterface : public nsISupports,
                                            public nsWrapperCache
{
public:
  NS_DECL_ISUPPORTS

  // We need a GetParentObject to make binding codegen happy
  virtual nsISupports* GetParentObject();

  void IndexedDeleter(uint32_t, bool&);
  long IndexedGetter(uint32_t, bool&);
  uint32_t Length();

  void NamedDeleter(const nsAString&, bool&);
  void NamedDeleter(const nsAString&) MOZ_DELETE;
  long NamedGetter(const nsAString&, bool&);
  bool NameIsEnumerable(const nsAString&);
  void DelNamedItem(const nsAString&);
  void DelNamedItem(const nsAString&, bool&) MOZ_DELETE;
  void GetSupportedNames(unsigned, nsTArray&);
};

class TestParentInterface : public nsISupports,
                            public nsWrapperCache
{
public:
  NS_DECL_ISUPPORTS

  // We need a GetParentObject to make binding codegen happy
  virtual nsISupports* GetParentObject();
};

class TestChildInterface : public TestParentInterface
{
};

} // namespace dom
} // namespace mozilla

#endif /* TestBindingHeader_h */
