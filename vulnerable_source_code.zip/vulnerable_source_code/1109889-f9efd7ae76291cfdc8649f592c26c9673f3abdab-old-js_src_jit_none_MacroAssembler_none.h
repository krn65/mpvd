/* -*- Mode: C++; tab-width: 8; indent-tabs-mode: nil; c-basic-offset: 4 -*-
 * vim: set ts=8 sts=4 et sw=4 tw=99:
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

#ifndef jit_none_MacroAssembler_none_h
#define jit_none_MacroAssembler_none_h

#include "jit/JitCompartment.h"
#include "jit/MoveResolver.h"
#include "jit/shared/Assembler-shared.h"


namespace js {
namespace jit {

class MDefinition;

static MOZ_CONSTEXPR_VAR Register StackPointer = { 0 };
static MOZ_CONSTEXPR_VAR Register FramePointer = { 0 };
static MOZ_CONSTEXPR_VAR Register ReturnReg = { 0 };
static MOZ_CONSTEXPR_VAR FloatRegister ReturnFloat32Reg = { 0 };
static MOZ_CONSTEXPR_VAR FloatRegister ReturnDoubleReg = { 0 };
static MOZ_CONSTEXPR_VAR FloatRegister ReturnSimdReg = { 0 };
static MOZ_CONSTEXPR_VAR FloatRegister ScratchFloat32Reg = { 0 };
static MOZ_CONSTEXPR_VAR FloatRegister ScratchDoubleReg = { 0 };
static MOZ_CONSTEXPR_VAR FloatRegister ScratchSimdReg = { 0 };
static MOZ_CONSTEXPR_VAR FloatRegister InvalidFloatReg = { 0 };

static MOZ_CONSTEXPR_VAR Register OsrFrameReg = { 0 };
static MOZ_CONSTEXPR_VAR Register ArgumentsRectifierReg = { 0 };
static MOZ_CONSTEXPR_VAR Register PreBarrierReg = { 0 };
static MOZ_CONSTEXPR_VAR Register CallTempReg0 = { 0 };
static MOZ_CONSTEXPR_VAR Register CallTempReg1 = { 0 };
static MOZ_CONSTEXPR_VAR Register CallTempReg2 = { 0 };
static MOZ_CONSTEXPR_VAR Register CallTempReg3 = { 0 };
static MOZ_CONSTEXPR_VAR Register CallTempReg4 = { 0 };
static MOZ_CONSTEXPR_VAR Register CallTempReg5 = { 0 };
static MOZ_CONSTEXPR_VAR Register InvalidReg = { 0 };

static MOZ_CONSTEXPR_VAR Register IntArgReg0 = { 0 };
static MOZ_CONSTEXPR_VAR Register IntArgReg1 = { 0 };
static MOZ_CONSTEXPR_VAR Register IntArgReg2 = { 0 };
static MOZ_CONSTEXPR_VAR Register IntArgReg3 = { 0 };
static MOZ_CONSTEXPR_VAR Register GlobalReg = { 0 };
static MOZ_CONSTEXPR_VAR Register HeapReg = { 0 };

static MOZ_CONSTEXPR_VAR Register AsmJSIonExitRegCallee = { 0 };
static MOZ_CONSTEXPR_VAR Register AsmJSIonExitRegE0 = { 0 };
static MOZ_CONSTEXPR_VAR Register AsmJSIonExitRegE1 = { 0 };
static MOZ_CONSTEXPR_VAR Register AsmJSIonExitRegE2 = { 0 };
static MOZ_CONSTEXPR_VAR Register AsmJSIonExitRegE3 = { 0 };

static MOZ_CONSTEXPR_VAR Register AsmJSIonExitRegReturnData = { 0 };
static MOZ_CONSTEXPR_VAR Register AsmJSIonExitRegReturnType = { 0 };
static MOZ_CONSTEXPR_VAR Register AsmJSIonExitRegD0 = { 0 };
static MOZ_CONSTEXPR_VAR Register AsmJSIonExitRegD1 = { 0 };
static MOZ_CONSTEXPR_VAR Register AsmJSIonExitRegD2 = { 0 };

static MOZ_CONSTEXPR_VAR Register JSReturnReg_Type = { 0 };
static MOZ_CONSTEXPR_VAR Register JSReturnReg_Data = { 0 };
static MOZ_CONSTEXPR_VAR Register JSReturnReg = { 0 };

#if defined(JS_NUNBOX32)
static MOZ_CONSTEXPR_VAR ValueOperand JSReturnOperand(InvalidReg, InvalidReg);
#elif defined(JS_PUNBOX64)
static MOZ_CONSTEXPR_VAR ValueOperand JSReturnOperand(InvalidReg);
#else
#error "Bad architecture"
#endif

static const uint32_t ABIStackAlignment = 4;
static const uint32_t CodeAlignment = 4;

static const Scale ScalePointer = TimesOne;

class Assembler : public AssemblerShared
{
  public:
    enum Condition {
        Equal,
        NotEqual,
        Above,
        AboveOrEqual,
        Below,
        BelowOrEqual,
        GreaterThan,
        GreaterThanOrEqual,
        LessThan,
        LessThanOrEqual,
        Overflow,
        Signed,
        NotSigned,
        Zero,
        NonZero,
        Always,
    };

    enum DoubleCondition {
        DoubleOrdered,
        DoubleEqual,
        DoubleNotEqual,
        DoubleGreaterThan,
        DoubleGreaterThanOrEqual,
        DoubleLessThan,
        DoubleLessThanOrEqual,
        DoubleUnordered,
        DoubleEqualOrUnordered,
        DoubleNotEqualOrUnordered,
        DoubleGreaterThanOrUnordered,
        DoubleGreaterThanOrEqualOrUnordered,
        DoubleLessThanOrUnordered,
        DoubleLessThanOrEqualOrUnordered
    };

    static Condition InvertCondition(Condition) { MOZ_CRASH(); }

    template 
    static void PatchDataWithValueCheck(CodeLocationLabel, T, S) { MOZ_CRASH(); }
    static void PatchWrite_Imm32(CodeLocationLabel, Imm32) { MOZ_CRASH(); }

    static void PatchWrite_NearCall(CodeLocationLabel, CodeLocationLabel) { MOZ_CRASH(); }
    static uint32_t PatchWrite_NearCallSize() { MOZ_CRASH(); }
    static void PatchInstructionImmediate(uint8_t *, PatchedImmPtr) { MOZ_CRASH(); }
    static int32_t ExtractCodeLabelOffset(uint8_t *) { MOZ_CRASH(); }

    static void ToggleToJmp(CodeLocationLabel) { MOZ_CRASH(); }
    static void ToggleToCmp(CodeLocationLabel) { MOZ_CRASH(); }
    static void ToggleCall(CodeLocationLabel, bool) { MOZ_CRASH(); }

    static uintptr_t GetPointer(uint8_t *) { MOZ_CRASH(); }
};

class MacroAssemblerNone : public Assembler
{
  public:
    MacroAssemblerNone() { MOZ_CRASH(); }

    MoveResolver moveResolver_;
    size_t framePushed_;

    uint32_t framePushed() const { MOZ_CRASH(); }
    void setFramePushed(uint32_t) { MOZ_CRASH(); }

    size_t size() const { MOZ_CRASH(); }
    size_t bytesNeeded() const { MOZ_CRASH(); }
    size_t jumpRelocationTableBytes() const { MOZ_CRASH(); }
    size_t dataRelocationTableBytes() const { MOZ_CRASH(); }
    size_t preBarrierTableBytes() const { MOZ_CRASH(); }

    size_t numCodeLabels() const { MOZ_CRASH(); }
    CodeLabel codeLabel(size_t) { MOZ_CRASH(); }

    void trace(JSTracer *) { MOZ_CRASH(); }
    static void TraceJumpRelocations(JSTracer *, JitCode *, CompactBufferReader &) { MOZ_CRASH(); }
    static void TraceDataRelocations(JSTracer *, JitCode *, CompactBufferReader &) { MOZ_CRASH(); }

    static bool SupportsFloatingPoint() { return false; }
    static bool SupportsSimd() { return false; }

    void executableCopy(void *) { MOZ_CRASH(); }
    void copyJumpRelocationTable(uint8_t *) { MOZ_CRASH(); }
    void copyDataRelocationTable(uint8_t *) { MOZ_CRASH(); }
    void copyPreBarrierTable(uint8_t *) { MOZ_CRASH(); }
    void processCodeLabels(uint8_t *) { MOZ_CRASH(); }

    void flushBuffer() { MOZ_CRASH(); }

    template  void bind(T) { MOZ_CRASH(); }
    template  void j(Condition, T) { MOZ_CRASH(); }
    template  void jump(T) { MOZ_CRASH(); }
    void align(size_t) { MOZ_CRASH(); }
    void checkStackAlignment() { MOZ_CRASH(); }
    uint32_t currentOffset() { MOZ_CRASH(); }
    uint32_t actualOffset(uint32_t) { MOZ_CRASH(); }
    uint32_t labelOffsetToPatchOffset(uint32_t) { MOZ_CRASH(); }
    CodeOffsetLabel labelForPatch() { MOZ_CRASH(); }

    template  void call(T) { MOZ_CRASH(); }
    template  void call(T, S) { MOZ_CRASH(); }
    template  void callWithABI(T, MoveOp::Type v = MoveOp::GENERAL) { MOZ_CRASH(); }
    void callAndPushReturnAddress(Label *label) { MOZ_CRASH(); }

    void setupAlignedABICall(uint32_t) { MOZ_CRASH(); }
    void setupUnalignedABICall(uint32_t, Register) { MOZ_CRASH(); }
    template  void passABIArg(T, MoveOp::Type v = MoveOp::GENERAL) { MOZ_CRASH(); }

    void callWithExitFrame(Label *) { MOZ_CRASH(); }
    void callWithExitFrame(JitCode *) { MOZ_CRASH(); }
    void callWithExitFrame(JitCode *, Register) { MOZ_CRASH(); }

    void callJit(Register callee) { MOZ_CRASH(); }
    void callJitFromAsmJS(Register callee) { MOZ_CRASH(); }

    void nop() { MOZ_CRASH(); }
    void breakpoint() { MOZ_CRASH(); }
    void abiret() { MOZ_CRASH(); }
    void ret() { MOZ_CRASH(); }

    CodeOffsetLabel toggledJump(Label *) { MOZ_CRASH(); }
    CodeOffsetLabel toggledCall(JitCode *, bool) { MOZ_CRASH(); }
    static size_t ToggledCallSize(uint8_t *) { MOZ_CRASH(); }

    void writePrebarrierOffset(CodeOffsetLabel) { MOZ_CRASH(); }

    void finish() { MOZ_CRASH(); }

    template  void moveValue(T, S) { MOZ_CRASH(); }
    template  void moveValue(T, S, U) { MOZ_CRASH(); }
    template  void storeValue(T, S) { MOZ_CRASH(); }
    template  void storeValue(T, S, U) { MOZ_CRASH(); }
    template  void loadValue(T, S) { MOZ_CRASH(); }
    template  void pushValue(T) { MOZ_CRASH(); }
    template  void pushValue(T, S) { MOZ_CRASH(); }
    void popValue(ValueOperand) { MOZ_CRASH(); }
    void tagValue(JSValueType, Register, ValueOperand) { MOZ_CRASH(); }
    void retn(Imm32 n) { MOZ_CRASH(); }
    template  void push(T) { MOZ_CRASH(); }
    template  void Push(T) { MOZ_CRASH(); }
    template  void pop(T) { MOZ_CRASH(); }
    template  void Pop(T) { MOZ_CRASH(); }
    template  CodeOffsetLabel PushWithPatch(T) { MOZ_CRASH(); }
    void implicitPop(uint32_t) { MOZ_CRASH(); }

    CodeOffsetJump jumpWithPatch(RepatchLabel *) { MOZ_CRASH(); }
    CodeOffsetJump jumpWithPatch(RepatchLabel *, Condition) { MOZ_CRASH(); }
    CodeOffsetJump backedgeJump(RepatchLabel *label) { MOZ_CRASH(); }
    template 
    CodeOffsetJump branchPtrWithPatch(Condition, T, S, RepatchLabel *) { MOZ_CRASH(); }

    template  void branchTestValue(Condition, T, S, Label *) { MOZ_CRASH(); }
    void testNullSet(Condition, ValueOperand, Register) { MOZ_CRASH(); }
    void testObjectSet(Condition, ValueOperand, Register) { MOZ_CRASH(); }
    void testUndefinedSet(Condition, ValueOperand, Register) { MOZ_CRASH(); }

    template  void cmpPtrSet(Condition, T, S, Register) { MOZ_CRASH(); }
    template  void cmp32Set(Condition, T, S, Register) { MOZ_CRASH(); }

    void reserveStack(uint32_t) { MOZ_CRASH(); }
    template  void freeStack(T) { MOZ_CRASH(); }
    template  void add32(T, S) { MOZ_CRASH(); }
    template  void addPtr(T, S) { MOZ_CRASH(); }
    template  void sub32(T, S) { MOZ_CRASH(); }
    template  void subPtr(T, S) { MOZ_CRASH(); }
    void neg32(Register) { MOZ_CRASH(); }
    void mulBy3(Register, Register) { MOZ_CRASH(); }

    void negateDouble(FloatRegister) { MOZ_CRASH(); }
    void addDouble(FloatRegister, FloatRegister) { MOZ_CRASH(); }
    void subDouble(FloatRegister, FloatRegister) { MOZ_CRASH(); }
    void mulDouble(FloatRegister, FloatRegister) { MOZ_CRASH(); }
    void divDouble(FloatRegister, FloatRegister) { MOZ_CRASH(); }

    template  void branch32(Condition, T, S, Label *) { MOZ_CRASH(); }
    template  void branchTest32(Condition, T, S, Label *) { MOZ_CRASH(); }
    template  void branchAdd32(Condition, T, S, Label *) { MOZ_CRASH(); }
    template  void branchSub32(Condition, T, S, Label *) { MOZ_CRASH(); }
    template  void branchPtr(Condition, T, S, Label *) { MOZ_CRASH(); }
    template  void branchTestPtr(Condition, T, S, Label *) { MOZ_CRASH(); }
    template  void branchDouble(DoubleCondition, T, S, Label *) { MOZ_CRASH(); }
    template  void branchFloat(DoubleCondition, T, S, Label *) { MOZ_CRASH(); }
    template  void branchPrivatePtr(Condition, T, S, Label *) { MOZ_CRASH(); }
    template  void decBranchPtr(Condition, T, S, Label *) { MOZ_CRASH(); }
    template  void mov(T, S) { MOZ_CRASH(); }
    template  void movq(T, S) { MOZ_CRASH(); }
    template  void movePtr(T, S) { MOZ_CRASH(); }
    template  void move32(T, S) { MOZ_CRASH(); }
    template  void moveFloat32(T, S) { MOZ_CRASH(); }
    template  void moveDouble(T, S) { MOZ_CRASH(); }
    template  CodeOffsetLabel movWithPatch(T, Register) { MOZ_CRASH(); }

    template  void loadPtr(T, Register) { MOZ_CRASH(); }
    template  void load32(T, Register) { MOZ_CRASH(); }
    template  void loadFloat32(T, FloatRegister) { MOZ_CRASH(); }
    template  void loadDouble(T, FloatRegister) { MOZ_CRASH(); }
    template  void loadAlignedInt32x4(T, FloatRegister) { MOZ_CRASH(); }
    template  void loadUnalignedInt32x4(T, FloatRegister) { MOZ_CRASH(); }
    template  void loadAlignedFloat32x4(T, FloatRegister) { MOZ_CRASH(); }
    template  void loadUnalignedFloat32x4(T, FloatRegister) { MOZ_CRASH(); }
    template  void loadPrivate(T, Register) { MOZ_CRASH(); }
    template  void load8SignExtend(T, Register) { MOZ_CRASH(); }
    template  void load8ZeroExtend(T, Register) { MOZ_CRASH(); }
    template  void load16SignExtend(T, Register) { MOZ_CRASH(); }
    template  void load16ZeroExtend(T, Register) { MOZ_CRASH(); }

    template  void storePtr(T, S) { MOZ_CRASH(); }
    template  void store32(T, S) { MOZ_CRASH(); }
    template  void store32_NoSecondScratch(T, S) { MOZ_CRASH(); }
    template  void storeFloat32(T, S) { MOZ_CRASH(); }
    template  void storeDouble(T, S) { MOZ_CRASH(); }
    template  void storeAlignedInt32x4(T, S) { MOZ_CRASH(); }
    template  void storeUnalignedInt32x4(T, S) { MOZ_CRASH(); }
    template  void storeAlignedFloat32x4(T, S) { MOZ_CRASH(); }
    template  void storeUnalignedFloat32x4(T, S) { MOZ_CRASH(); }
    template  void store8(T, S) { MOZ_CRASH(); }
    template  void store16(T, S) { MOZ_CRASH(); }

    template  void computeEffectiveAddress(T, Register) { MOZ_CRASH(); }

    template  void compareExchange8SignExtend(const T &mem, Register oldval, Register newval, Register output) { MOZ_CRASH(); }
    template  void compareExchange8ZeroExtend(const T &mem, Register oldval, Register newval, Register output) { MOZ_CRASH(); }
    template  void compareExchange16SignExtend(const T &mem, Register oldval, Register newval, Register output) { MOZ_CRASH(); }
    template  void compareExchange16ZeroExtend(const T &mem, Register oldval, Register newval, Register output) { MOZ_CRASH(); }
    template  void compareExchange32(const T &mem, Register oldval, Register newval, Register output) { MOZ_CRASH(); }
    template  void atomicFetchAdd8SignExtend(const T &value, const S &mem, Register temp, Register output) { MOZ_CRASH(); }
    template  void atomicFetchAdd8ZeroExtend(const T &value, const S &mem, Register temp, Register output) { MOZ_CRASH(); }
    template  void atomicFetchAdd16SignExtend(const T &value, const S &mem, Register temp, Register output) { MOZ_CRASH(); }
    template  void atomicFetchAdd16ZeroExtend(const T &value, const S &mem, Register temp, Register output) { MOZ_CRASH(); }
    template  void atomicFetchAdd32(const T &value, const S &mem, Register temp, Register output) { MOZ_CRASH(); }
    template  void atomicFetchSub8SignExtend(const T &value, const S &mem, Register temp, Register output) { MOZ_CRASH(); }
    template  void atomicFetchSub8ZeroExtend(const T &value, const S &mem, Register temp, Register output) { MOZ_CRASH(); }
    template  void atomicFetchSub16SignExtend(const T &value, const S &mem, Register temp, Register output) { MOZ_CRASH(); }
    template  void atomicFetchSub16ZeroExtend(const T &value, const S &mem, Register temp, Register output) { MOZ_CRASH(); }
    template  void atomicFetchSub32(const T &value, const S &mem, Register temp, Register output) { MOZ_CRASH(); }
    template  void atomicFetchAnd8SignExtend(const T &value, const S &mem, Register temp, Register output) { MOZ_CRASH(); }
    template  void atomicFetchAnd8ZeroExtend(const T &value, const S &mem, Register temp, Register output) { MOZ_CRASH(); }
    template  void atomicFetchAnd16SignExtend(const T &value, const S &mem, Register temp, Register output) { MOZ_CRASH(); }
    template  void atomicFetchAnd16ZeroExtend(const T &value, const S &mem, Register temp, Register output) { MOZ_CRASH(); }
    template  void atomicFetchAnd32(const T &value, const S &mem, Register temp, Register output) { MOZ_CRASH(); }
    template  void atomicFetchOr8SignExtend(const T &value, const S &mem, Register temp, Register output) { MOZ_CRASH(); }
    template  void atomicFetchOr8ZeroExtend(const T &value, const S &mem, Register temp, Register output) { MOZ_CRASH(); }
    template  void atomicFetchOr16SignExtend(const T &value, const S &mem, Register temp, Register output) { MOZ_CRASH(); }
    template  void atomicFetchOr16ZeroExtend(const T &value, const S &mem, Register temp, Register output) { MOZ_CRASH(); }
    template  void atomicFetchOr32(const T &value, const S &mem, Register temp, Register output) { MOZ_CRASH(); }
    template  void atomicFetchXor8SignExtend(const T &value, const S &mem, Register temp, Register output) { MOZ_CRASH(); }
    template  void atomicFetchXor8ZeroExtend(const T &value, const S &mem, Register temp, Register output) { MOZ_CRASH(); }
    template  void atomicFetchXor16SignExtend(const T &value, const S &mem, Register temp, Register output) { MOZ_CRASH(); }
    template  void atomicFetchXor16ZeroExtend(const T &value, const S &mem, Register temp, Register output) { MOZ_CRASH(); }
    template  void atomicFetchXor32(const T &value, const S &mem, Register temp, Register output) { MOZ_CRASH(); }

    void clampIntToUint8(Register) { MOZ_CRASH(); }

    Register splitTagForTest(ValueOperand) { MOZ_CRASH(); }

    template  void branchTestUndefined(Condition, T, Label *) { MOZ_CRASH(); }
    template  void branchTestInt32(Condition, T, Label *) { MOZ_CRASH(); }
    template  void branchTestBoolean(Condition, T, Label *) { MOZ_CRASH(); }
    template  void branchTestDouble(Condition, T, Label *) { MOZ_CRASH(); }
    template  void branchTestNull(Condition, T, Label *) { MOZ_CRASH(); }
    template  void branchTestString(Condition, T, Label *) { MOZ_CRASH(); }
    template  void branchTestSymbol(Condition, T, Label *) { MOZ_CRASH(); }
    template  void branchTestObject(Condition, T, Label *) { MOZ_CRASH(); }
    template  void branchTestNumber(Condition, T, Label *) { MOZ_CRASH(); }
    template  void branchTestGCThing(Condition, T, Label *) { MOZ_CRASH(); }
    template  void branchTestPrimitive(Condition, T, Label *) { MOZ_CRASH(); }
    template  void branchTestMagic(Condition, T, Label *) { MOZ_CRASH(); }
    template  void branchTestMagicValue(Condition, T, JSWhyMagic, Label *) { MOZ_CRASH(); }
    void boxDouble(FloatRegister, ValueOperand) { MOZ_CRASH(); }
    void boxNonDouble(JSValueType, Register, ValueOperand) { MOZ_CRASH(); }
    template  void unboxInt32(T, Register) { MOZ_CRASH(); }
    template  void unboxBoolean(T, Register) { MOZ_CRASH(); }
    template  void unboxString(T, Register) { MOZ_CRASH(); }
    template  void unboxSymbol(T, Register) { MOZ_CRASH(); }
    template  void unboxObject(T, Register) { MOZ_CRASH(); }
    template  void unboxDouble(T, FloatRegister) { MOZ_CRASH(); }
    void unboxValue(const ValueOperand &, AnyRegister) { MOZ_CRASH(); }
    void unboxNonDouble(const ValueOperand &, Register ) { MOZ_CRASH();}
    void notBoolean(ValueOperand) { MOZ_CRASH(); }
    Register extractObject(Address, Register) { MOZ_CRASH(); }
    Register extractObject(ValueOperand, Register) { MOZ_CRASH(); }
    Register extractInt32(ValueOperand, Register) { MOZ_CRASH(); }
    Register extractBoolean(ValueOperand, Register) { MOZ_CRASH(); }
    template  Register extractTag(T, Register) { MOZ_CRASH(); }

    void convertFloat32ToInt32(FloatRegister, Register, Label *, bool v = true) { MOZ_CRASH(); }
    void convertDoubleToInt32(FloatRegister, Register, Label *, bool v = true) { MOZ_CRASH(); }
    void convertBoolToInt32(Register, Register) { MOZ_CRASH(); }

    void convertDoubleToFloat32(FloatRegister, FloatRegister) { MOZ_CRASH(); }
    void convertInt32ToFloat32(Register, FloatRegister) { MOZ_CRASH(); }

    template  void convertInt32ToDouble(T, FloatRegister) { MOZ_CRASH(); }
    void convertFloat32ToDouble(FloatRegister, FloatRegister) { MOZ_CRASH(); }

    void branchTruncateDouble(FloatRegister, Register, Label *) { MOZ_CRASH(); }
    void branchTruncateFloat32(FloatRegister, Register, Label *) { MOZ_CRASH(); }

    void boolValueToDouble(ValueOperand, FloatRegister) { MOZ_CRASH(); }
    void boolValueToFloat32(ValueOperand, FloatRegister) { MOZ_CRASH(); }
    void int32ValueToDouble(ValueOperand, FloatRegister) { MOZ_CRASH(); }
    void int32ValueToFloat32(ValueOperand, FloatRegister) { MOZ_CRASH(); }

    void loadConstantDouble(double, FloatRegister) { MOZ_CRASH(); }
    void addConstantDouble(double, FloatRegister) { MOZ_CRASH(); }
    void loadConstantFloat32(float, FloatRegister) { MOZ_CRASH(); }
    void addConstantFloat32(float, FloatRegister) { MOZ_CRASH(); }
    Condition testInt32Truthy(bool, ValueOperand) { MOZ_CRASH(); }
    Condition testStringTruthy(bool, ValueOperand) { MOZ_CRASH(); }
    void branchTestInt32Truthy(bool, ValueOperand, Label *) { MOZ_CRASH(); }
    void branchTestBooleanTruthy(bool, ValueOperand, Label *) { MOZ_CRASH(); }
    void branchTestStringTruthy(bool, ValueOperand, Label *) { MOZ_CRASH(); }
    void branchTestDoubleTruthy(bool, FloatRegister, Label *) { MOZ_CRASH(); }

    template  void loadUnboxedValue(T, MIRType, AnyRegister) { MOZ_CRASH(); }
    template  void storeUnboxedValue(ConstantOrRegister, MIRType, T, MIRType) { MOZ_CRASH(); }

    void rshiftPtr(Imm32, Register) { MOZ_CRASH(); }
    void rshiftPtrArithmetic(Imm32, Register) { MOZ_CRASH(); }
    void lshiftPtr(Imm32, Register) { MOZ_CRASH(); }
    template  void xorPtr(T, S) { MOZ_CRASH(); }
    template  void xor32(T, S) { MOZ_CRASH(); }
    template  void orPtr(T, S) { MOZ_CRASH(); }
    template  void or32(T, S) { MOZ_CRASH(); }
    template  void andPtr(T, S) { MOZ_CRASH(); }
    template  void and32(T, S) { MOZ_CRASH(); }
    template  void not32(T) { MOZ_CRASH(); }
    void convertUInt32ToDouble(Register, FloatRegister) { MOZ_CRASH(); }
    void convertUInt32ToFloat32(Register, FloatRegister) { MOZ_CRASH(); }
    void inc64(AbsoluteAddress) { MOZ_CRASH(); }
    void incrementInt32Value(Address) { MOZ_CRASH(); }
    void ensureDouble(ValueOperand, FloatRegister, Label *) { MOZ_CRASH(); }
    void handleFailureWithHandler(void *) { MOZ_CRASH(); }
    void makeFrameDescriptor(Register, FrameType) { MOZ_CRASH(); }

    void branchPtrInNurseryRange(Condition, Register, Register, Label *) { MOZ_CRASH(); }
    void branchValueIsNurseryObject(Condition, ValueOperand, Register, Label *) { MOZ_CRASH(); }

    void buildFakeExitFrame(Register, uint32_t *) { MOZ_CRASH(); }
    bool buildOOLFakeExitFrame(void *) { MOZ_CRASH(); }
    void loadAsmJSActivation(Register) { MOZ_CRASH(); }
    void loadAsmJSHeapRegisterFromGlobalData() { MOZ_CRASH(); }
    void memIntToValue(Address, Address) { MOZ_CRASH(); }

    void setPrinter(Sprinter *) { MOZ_CRASH(); }

#ifdef JS_NUNBOX32
    Address ToPayload(Address) { MOZ_CRASH(); }
    Address ToType(Address) { MOZ_CRASH(); }
#endif
};

typedef MacroAssemblerNone MacroAssemblerSpecific;

class ABIArgGenerator
{
  public:
    ABIArgGenerator() { MOZ_CRASH(); }
    ABIArg next(MIRType) { MOZ_CRASH(); }
    ABIArg &current() { MOZ_CRASH(); }
    uint32_t stackBytesConsumedSoFar() const { MOZ_CRASH(); }

    static const Register NonArgReturnReg0;
    static const Register NonArgReturnReg1;
    static const Register NonArg_VolatileReg;
    static const Register NonReturn_VolatileReg0;
    static const Register NonReturn_VolatileReg1;
};

static inline void PatchJump(CodeLocationJump &, CodeLocationLabel) { MOZ_CRASH(); }
static inline bool GetTempRegForIntArg(uint32_t, uint32_t, Register *) { MOZ_CRASH(); }
static inline
void PatchBackedge(CodeLocationJump &jump_, CodeLocationLabel label, JitRuntime::BackedgeTarget target)
{
    MOZ_CRASH();
}

} // namespace jit
} // namespace js

#endif /* jit_none_MacroAssembler_none_h */
